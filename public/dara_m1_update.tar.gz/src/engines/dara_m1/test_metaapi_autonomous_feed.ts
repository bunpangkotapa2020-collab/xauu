/**
 * Test MetaApi Autonomous Market Data Feed & Watchdog Integration
 * Verifies that when MT5 PC/Phone is OFF (no WebRequest), MetaApi Cloud feed operates autonomously 24/7.
 */

import assert from 'assert';

console.log('================================================================');
console.log('🧪 AUDIT: METAAPI AUTONOMOUS 24/7 MARKET FEED & WATCHDOG');
console.log('================================================================');

// 1. Simulation of Watchdog Logic
let botState: any = {
    account: {
        isConnected: true,
        serverConnected: true,
        eaConnected: true,
        vpsOnline: true,
        marketDataReceiving: true,
        loginId: '12345678',
        accountType: 'cent'
    },
    lastTickTime: Date.now(),
    marketDataStatus: ''
};

let lastSyncTimestamp = 0; // PC MT5 is 100% OFF / SILENT
let lastMetaApiSuccessTime = Date.now();
let currentMt5State = 'UNKNOWN';
let telegramAlertSent: string[] = [];

function sendTelegramMock(msg: string, code: string) {
    telegramAlertSent.push(code);
}

function runWatchdogTick() {
    const lastSeen = Math.max(botState.lastTickTime || 0, lastSyncTimestamp || 0, lastMetaApiSuccessTime || 0);
    const isRecentlyActive = lastSeen > 0 && (Date.now() - lastSeen < 60000);

    if (isRecentlyActive) {
        botState.account.isConnected = true;
        botState.account.serverConnected = true;
        botState.account.eaConnected = true;
        botState.account.vpsOnline = true;
        botState.account.marketDataReceiving = true;
        if (currentMt5State === 'LOST') {
            currentMt5State = 'CONNECTED';
            sendTelegramMock('🟢 DaRa M1 — CONNECTION RESTORED', 'MT5_CONN_RESTORED');
        } else if (currentMt5State === 'UNKNOWN') {
            currentMt5State = 'CONNECTED';
        }
        if (!botState.marketDataStatus || botState.marketDataStatus.includes('🔴')) {
            botState.marketDataStatus = '🟢 LIVE (METAAPI CLOUD ACTIVE)';
        }
    } else if (lastSeen > 0 && Date.now() - lastSeen >= 60000) {
        botState.account.serverConnected = false;
        botState.account.eaConnected = false;
        botState.account.marketDataReceiving = false;
        if (currentMt5State !== 'LOST') {
            currentMt5State = 'LOST';
            sendTelegramMock('🔴 DaRa M1 — MARKET DATA DISCONNECTED', 'MT5_CONN_LOST');
        }
        botState.marketDataStatus = '🔴 MARKET DATA DISCONNECTED';
    }
}

// TEST 1: PC MT5 is OFF (lastSyncTimestamp = 0), MetaApi Cloud is LIVE
runWatchdogTick();
assert.strictEqual(botState.account.serverConnected, true, 'Server must be connected via MetaApi');
assert.strictEqual(botState.account.marketDataReceiving, true, 'Market data receiving must be true');
assert.strictEqual(botState.marketDataStatus, '🟢 LIVE (METAAPI CLOUD ACTIVE)', 'Market data status must show MetaApi Cloud Active');
assert.strictEqual(telegramAlertSent.includes('MT5_CONN_LOST'), false, 'Must NOT trigger MT5_CONN_LOST');
console.log('✅ [PASS] Test 1: PC OFF (MT5 Silent) + MetaApi Cloud Live -> 100% GREEN & Healthy');

// TEST 2: PC MT5 sync comes online as fallback and goes offline again
lastSyncTimestamp = Date.now();
runWatchdogTick();
assert.strictEqual(botState.account.serverConnected, true);
// Now PC MT5 stops (stale timestamp from 2 hours ago)
lastSyncTimestamp = Date.now() - 7200000;
lastMetaApiSuccessTime = Date.now();
botState.lastTickTime = Date.now();
runWatchdogTick();
assert.strictEqual(botState.account.serverConnected, true, 'MetaApi keeps connection stable even when MT5 PC stops');
assert.strictEqual(telegramAlertSent.includes('MT5_CONN_LOST'), false, 'No false alarm sent when PC turns off');
console.log('✅ [PASS] Test 2: PC Disconnection does NOT disrupt MetaApi Cloud feed');

// TEST 3: True network outage where MetaApi is silent for >60s
lastMetaApiSuccessTime = Date.now() - 65000;
botState.lastTickTime = Date.now() - 65000;
lastSyncTimestamp = 0;
runWatchdogTick();
assert.strictEqual(botState.account.serverConnected, false, 'Should detect true disconnect after 60s silence');
assert.strictEqual(telegramAlertSent.includes('MT5_CONN_LOST'), true, 'Should send alert when both sources silent >60s');
console.log('✅ [PASS] Test 3: True market silence (>60s) properly flagged as disconnected');

// TEST 4: MetaApi Cloud feed reconnects
lastMetaApiSuccessTime = Date.now();
botState.lastTickTime = Date.now();
runWatchdogTick();
assert.strictEqual(botState.account.serverConnected, true, 'Should restore connection when MetaApi resumes');
assert.strictEqual(telegramAlertSent.includes('MT5_CONN_RESTORED'), true, 'Should notify connection restored');
console.log('✅ [PASS] Test 4: Automatic recovery when MetaApi Cloud feed resumes');

console.log('================================================================');
console.log('🎉 ALL 4 AUTONOMOUS FEED TESTS PASSED CLEANLY!');
console.log('================================================================');
