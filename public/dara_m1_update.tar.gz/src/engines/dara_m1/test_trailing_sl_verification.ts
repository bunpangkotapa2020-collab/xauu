import { DaRaProfitTrailing } from './DaRaProfitTrailing';
import { DaRaPosition, DaRaUserSettings } from './types';

console.log('================================================================');
console.log('🧪 DARA M1 EA v1.0 — TRAILING SL SPECIFICATION VERIFICATION');
console.log('================================================================');

const trailing = new DaRaProfitTrailing();

const mockSettings: DaRaUserSettings = {
  lotSize: 0.10,
  slDistance: 3.0,
  tpDistance: 6.0,
  dailyLossLimit: 100,
  maxOpenTrades: 1,
  maxConsecutiveSL: 3,
  cooldownMinutes: 15,
  maxSpreadPoints: 25,
  newsFilterEnabled: true,
  newsMinsBefore: 15,
  newsMinsAfter: 15,
  trailingEnabled: true,
  trailingTriggerPips: 1.5,
  trailingDistancePips: 1.0
};

let allPassed = true;
function assert(desc: string, condition: boolean, detail: string) {
  if (condition) {
    console.log(`✅ PASS: ${desc} -> ${detail}`);
  } else {
    console.error(`❌ FAIL: ${desc} -> ${detail}`);
    allPassed = false;
  }
}

// -------------------------------------------------------------------------
// SCENARIO 1: BUY POSITION (TP = 100)
// -------------------------------------------------------------------------
console.log('\n--- SCENARIO 1: BUY POSITION (TP = 100) ---');
const buyPos: DaRaPosition = {
  ticket: 'BUY_TEST_001',
  symbol: 'XAUUSD',
  type: 'BUY',
  lot: 0.10,
  openPrice: 90.0,
  currentPrice: 90.0,
  sl: 87.0,
  tp: 100.0,
  originalTp: 100.0,
  openTime: Date.now()
};

// 1. Price is at 98.0 (below TP 100) -> Must NOT activate
const buyStep1 = trailing.calculateTrailingSL(buyPos, 98.0, 98.2, mockSettings);
assert(
  'BUY Price < TP (Price 98.0 < TP 100.0)',
  !buyStep1.shouldModify,
  `Trailing SL NOT activated. Reason: ${buyStep1.reason}`
);

// 2. Price reaches TP 100.0 -> Must activate SL at 98.5 (TP - 1.5)
const buyStep2 = trailing.calculateTrailingSL(buyPos, 100.0, 100.2, mockSettings);
assert(
  'BUY Price reaches TP 100.0 -> SL starts at 98.5',
  buyStep2.shouldModify && buyStep2.newSl === 98.5,
  `New SL = ${buyStep2.newSl} (Expected 98.5). Not equal to TP.`
);
buyPos.sl = buyStep2.newSl!;

// 3. Price continues to rise to 101.0 -> SL advances to 99.5
const buyStep3 = trailing.calculateTrailingSL(buyPos, 101.0, 101.2, mockSettings);
assert(
  'BUY Price rises to 101.0 -> SL advances to 99.5',
  buyStep3.shouldModify && buyStep3.newSl === 99.5,
  `New SL = ${buyStep3.newSl} (Expected 99.5). Preserves 1.5 distance.`
);
buyPos.sl = buyStep3.newSl!;

// 4. Price rises further to 102.0 -> SL advances to 100.5
const buyStep4 = trailing.calculateTrailingSL(buyPos, 102.0, 102.2, mockSettings);
assert(
  'BUY Price rises to 102.0 -> SL advances to 100.5',
  buyStep4.shouldModify && buyStep4.newSl === 100.5,
  `New SL = ${buyStep4.newSl} (Expected 100.5). Preserves 1.5 distance.`
);
buyPos.sl = buyStep4.newSl!;

// 5. Price retraces back to 100.8 -> SL MUST NOT MOVE DOWN!
const buyStep5 = trailing.calculateTrailingSL(buyPos, 100.8, 101.0, mockSettings);
assert(
  'BUY Price retraces to 100.8 -> SL does NOT move down',
  !buyStep5.shouldModify,
  `Retracement blocked! SL preserved at ${buyPos.sl}. Reason: ${buyStep5.reason}`
);

// -------------------------------------------------------------------------
// SCENARIO 2: SELL POSITION (TP = 100)
// -------------------------------------------------------------------------
console.log('\n--- SCENARIO 2: SELL POSITION (TP = 100) ---');
const sellPos: DaRaPosition = {
  ticket: 'SELL_TEST_001',
  symbol: 'XAUUSD',
  type: 'SELL',
  lot: 0.10,
  openPrice: 110.0,
  currentPrice: 110.0,
  sl: 113.0,
  tp: 100.0,
  originalTp: 100.0,
  openTime: Date.now()
};

// 1. Price is at 102.0 (above TP 100) -> Must NOT activate
const sellStep1 = trailing.calculateTrailingSL(sellPos, 101.8, 102.0, mockSettings);
assert(
  'SELL Price > TP (Price 102.0 > TP 100.0)',
  !sellStep1.shouldModify,
  `Trailing SL NOT activated. Reason: ${sellStep1.reason}`
);

// 2. Price reaches TP 100.0 -> Must activate SL at 101.5 (TP + 1.5)
const sellStep2 = trailing.calculateTrailingSL(sellPos, 99.8, 100.0, mockSettings);
assert(
  'SELL Price reaches TP 100.0 -> SL starts at 101.5',
  sellStep2.shouldModify && sellStep2.newSl === 101.5,
  `New SL = ${sellStep2.newSl} (Expected 101.5). Not equal to TP.`
);
sellPos.sl = sellStep2.newSl!;

// 3. Price continues to drop to 99.0 -> SL advances to 100.5
const sellStep3 = trailing.calculateTrailingSL(sellPos, 98.8, 99.0, mockSettings);
assert(
  'SELL Price drops to 99.0 -> SL advances down to 100.5',
  sellStep3.shouldModify && sellStep3.newSl === 100.5,
  `New SL = ${sellStep3.newSl} (Expected 100.5). Preserves 1.5 distance.`
);
sellPos.sl = sellStep3.newSl!;

// 4. Price drops further to 98.0 -> SL advances down to 99.5
const sellStep4 = trailing.calculateTrailingSL(sellPos, 97.8, 98.0, mockSettings);
assert(
  'SELL Price drops to 98.0 -> SL advances down to 99.5',
  sellStep4.shouldModify && sellStep4.newSl === 99.5,
  `New SL = ${sellStep4.newSl} (Expected 99.5). Preserves 1.5 distance.`
);
sellPos.sl = sellStep4.newSl!;

// 5. Price bounces back to 99.5 -> SL MUST NOT MOVE UP!
const sellStep5 = trailing.calculateTrailingSL(sellPos, 99.3, 99.5, mockSettings);
assert(
  'SELL Price bounces to 99.5 -> SL does NOT move up',
  !sellStep5.shouldModify,
  `Bounce blocked! SL preserved at ${sellPos.sl}. Reason: ${sellStep5.reason}`
);

console.log('\n================================================================');
if (allPassed) {
  console.log('🎉 ALL TRAILING SL SPECIFICATION TESTS PASSED 100%!');
} else {
  console.error('❌ SOME TESTS FAILED');
  process.exit(1);
}
console.log('================================================================');
