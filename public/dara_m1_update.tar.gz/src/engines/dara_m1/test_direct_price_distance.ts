import { DaRaOrderExecution } from './DaRaOrderExecution';
import { DaRaUserSettings, DaRaSetup } from './types';

class MockBroker {
  public lastSentOrder: any = null;

  async getSymbolInfo(symbol: string): Promise<{ pointSize: number }> {
    // Deliberately return 0.01 to verify that pointSize is NOT multiplied into SL/TP
    return { pointSize: 0.01 };
  }

  async sendOrder(order: {
    symbol: string;
    type: 'BUY' | 'SELL';
    lot: number;
    openPrice: number;
    sl: number;
    tp: number;
    comment: string;
  }): Promise<{ success: boolean; ticket?: number; error?: string }> {
    this.lastSentOrder = order;
    return { success: true, ticket: 999999 };
  }

  async getOpenPositions(): Promise<any[]> {
    return [];
  }

  async closePosition(): Promise<any> {
    return { success: true };
  }

  async modifyPosition(): Promise<any> {
    return { success: true };
  }
}

async function runDirectPriceDistanceTests() {
  console.log('================================================================');
  console.log('🧪 VERIFYING DIRECT PRICE DISTANCE REQUIREMENT FOR SL / TP');
  console.log('================================================================');

  const broker = new MockBroker();
  const executor = new DaRaOrderExecution(broker as any);

  // TEST 1: User sets SL = 10, TP = 10 on Entry = 100 (BUY)
  console.log('\n--- TEST 1: BUY (Entry = 100, SL = 10, TP = 10) ---');
  const userSettings10: DaRaUserSettings = {
    lotSize: 0.01,
    slDistance: 10, // Direct price distance
    tpDistance: 10, // Direct price distance
    dailyLossLimit: 2000,
    maxOpenTrades: 1,
    maxConsecutiveSL: 3,
    cooldownMinutes: 15,
    maxSpreadPoints: 20,
    newsFilterEnabled: false,
    newsMinsBefore: 15,
    newsMinsAfter: 15,
    trailingEnabled: false,
    trailingTriggerPips: 10,
    trailingDistancePips: 5,
  };

  const buySetup100: DaRaSetup = {
    id: 'TEST_BUY_100',
    direction: 'BUY',
    sweepLevel: 98,
    sweepTime: 1000,
    displacementConfirmed: true,
    mssLevel: 100,
    mssTime: 1001,
    lockedEntryPrice: 100,
    virtualSLPrice: 90,
    virtualTPPrice: 110,
    userSlDistance: 10,
    userTpDistance: 10,
    status: 'PENDING_ENTRY',
    createdAt: Date.now(),
  };

  const buyResult10 = await executor.executeOrder(buySetup100, 'XAUUSD', 100.0, 100.0, userSettings10);
  if (!buyResult10.success) {
    throw new Error(`BUY failed: ${buyResult10.error}`);
  }

  const sentBuy10 = broker.lastSentOrder;
  console.log(`Sent BUY Order: Entry=${sentBuy10.openPrice}, SL=${sentBuy10.sl}, TP=${sentBuy10.tp}`);
  if (sentBuy10.sl !== 90) {
    throw new Error(`Expected BUY SL to be 90 (100 - 10), but got ${sentBuy10.sl}`);
  }
  if (sentBuy10.tp !== 110) {
    throw new Error(`Expected BUY TP to be 110 (100 + 10), but got ${sentBuy10.tp}`);
  }
  console.log('✅ TEST 1 PASSED: BUY Entry 100 / SL 10 / TP 10 => SL 90, TP 110');

  // Reset executor for next test
  const executor2 = new DaRaOrderExecution(broker as any);

  // TEST 2: User sets SL = 10, TP = 10 on Entry = 100 (SELL)
  console.log('\n--- TEST 2: SELL (Entry = 100, SL = 10, TP = 10) ---');
  const sellSetup100: DaRaSetup = {
    id: 'TEST_SELL_100',
    direction: 'SELL',
    sweepLevel: 102,
    sweepTime: 1000,
    displacementConfirmed: true,
    mssLevel: 100,
    mssTime: 1001,
    lockedEntryPrice: 100,
    virtualSLPrice: 110,
    virtualTPPrice: 90,
    userSlDistance: 10,
    userTpDistance: 10,
    status: 'PENDING_ENTRY',
    createdAt: Date.now(),
  };

  const sellResult10 = await executor2.executeOrder(sellSetup100, 'XAUUSD', 100.0, 100.0, userSettings10);
  if (!sellResult10.success) {
    throw new Error(`SELL failed: ${sellResult10.error}`);
  }

  const sentSell10 = broker.lastSentOrder;
  console.log(`Sent SELL Order: Entry=${sentSell10.openPrice}, SL=${sentSell10.sl}, TP=${sentSell10.tp}`);
  if (sentSell10.sl !== 110) {
    throw new Error(`Expected SELL SL to be 110 (100 + 10), but got ${sentSell10.sl}`);
  }
  if (sentSell10.tp !== 90) {
    throw new Error(`Expected SELL TP to be 90 (100 - 10), but got ${sentSell10.tp}`);
  }
  console.log('✅ TEST 2 PASSED: SELL Entry 100 / SL 10 / TP 10 => SL 110, TP 90');

  // TEST 3: User sets SL = 5, TP = 5 on Entry = 100
  console.log('\n--- TEST 3: User sets SL = 5, TP = 5 ---');
  const userSettings5: DaRaUserSettings = { ...userSettings10, slDistance: 5, tpDistance: 5 };
  
  const exec3Buy = new DaRaOrderExecution(broker as any);
  await exec3Buy.executeOrder({ ...buySetup100, id: 'BUY_5' }, 'XAUUSD', 100.0, 100.0, userSettings5);
  const sentBuy5 = broker.lastSentOrder;
  if (sentBuy5.sl !== 95 || sentBuy5.tp !== 105) {
    throw new Error(`Expected BUY SL 95, TP 105, got SL ${sentBuy5.sl}, TP ${sentBuy5.tp}`);
  }
  console.log(`BUY (SL=5, TP=5): SL=${sentBuy5.sl}, TP=${sentBuy5.tp} ✅`);

  const exec3Sell = new DaRaOrderExecution(broker as any);
  await exec3Sell.executeOrder({ ...sellSetup100, id: 'SELL_5' }, 'XAUUSD', 100.0, 100.0, userSettings5);
  const sentSell5 = broker.lastSentOrder;
  if (sentSell5.sl !== 105 || sentSell5.tp !== 95) {
    throw new Error(`Expected SELL SL 105, TP 95, got SL ${sentSell5.sl}, TP ${sentSell5.tp}`);
  }
  console.log(`SELL (SL=5, TP=5): SL=${sentSell5.sl}, TP=${sentSell5.tp} ✅`);
  console.log('✅ TEST 3 PASSED: Distance 5 is exactly 5 price units from Entry');

  // TEST 4: User sets SL = 1, TP = 1 on Entry = 100
  console.log('\n--- TEST 4: User sets SL = 1, TP = 1 ---');
  const userSettings1: DaRaUserSettings = { ...userSettings10, slDistance: 1, tpDistance: 1 };
  
  const exec4Buy = new DaRaOrderExecution(broker as any);
  await exec4Buy.executeOrder({ ...buySetup100, id: 'BUY_1' }, 'XAUUSD', 100.0, 100.0, userSettings1);
  const sentBuy1 = broker.lastSentOrder;
  if (sentBuy1.sl !== 99 || sentBuy1.tp !== 101) {
    throw new Error(`Expected BUY SL 99, TP 101, got SL ${sentBuy1.sl}, TP ${sentBuy1.tp}`);
  }
  console.log(`BUY (SL=1, TP=1): SL=${sentBuy1.sl}, TP=${sentBuy1.tp} ✅`);

  const exec4Sell = new DaRaOrderExecution(broker as any);
  await exec4Sell.executeOrder({ ...sellSetup100, id: 'SELL_1' }, 'XAUUSD', 100.0, 100.0, userSettings1);
  const sentSell1 = broker.lastSentOrder;
  if (sentSell1.sl !== 101 || sentSell1.tp !== 99) {
    throw new Error(`Expected SELL SL 101, TP 99, got SL ${sentSell1.sl}, TP ${sentSell1.tp}`);
  }
  console.log(`SELL (SL=1, TP=1): SL=${sentSell1.sl}, TP=${sentSell1.tp} ✅`);
  console.log('✅ TEST 4 PASSED: Distance 1 is exactly 1 price unit from Entry');

  // TEST 5: Verify Realistic Gold Prices (e.g. Entry 2700, SL 10, TP 15)
  console.log('\n--- TEST 5: Realistic Gold Price (Entry = 2700, SL = 10, TP = 15) ---');
  const userSettingsGold: DaRaUserSettings = { ...userSettings10, slDistance: 10, tpDistance: 15 };
  const goldBuySetup: DaRaSetup = {
    ...buySetup100,
    id: 'GOLD_BUY',
    lockedEntryPrice: 2700.00,
    mssLevel: 2700.00,
  };
  const exec5Buy = new DaRaOrderExecution(broker as any);
  await exec5Buy.executeOrder(goldBuySetup, 'XAUUSD', 2700.00, 2700.00, userSettingsGold);
  const sentGoldBuy = broker.lastSentOrder;
  if (sentGoldBuy.sl !== 2690 || sentGoldBuy.tp !== 2715) {
    throw new Error(`Expected Gold BUY SL 2690, TP 2715, got SL ${sentGoldBuy.sl}, TP ${sentGoldBuy.tp}`);
  }
  console.log(`Gold BUY: Entry=2700, SL=${sentGoldBuy.sl} (2700 - 10), TP=${sentGoldBuy.tp} (2700 + 15) ✅`);

  const goldSellSetup: DaRaSetup = {
    ...sellSetup100,
    id: 'GOLD_SELL',
    lockedEntryPrice: 2700.00,
    mssLevel: 2700.00,
  };
  const exec5Sell = new DaRaOrderExecution(broker as any);
  await exec5Sell.executeOrder(goldSellSetup, 'XAUUSD', 2700.00, 2700.00, userSettingsGold);
  const sentGoldSell = broker.lastSentOrder;
  if (sentGoldSell.sl !== 2710 || sentGoldSell.tp !== 2685) {
    throw new Error(`Expected Gold SELL SL 2710, TP 2685, got SL ${sentGoldSell.sl}, TP ${sentGoldSell.tp}`);
  }
  console.log(`Gold SELL: Entry=2700, SL=${sentGoldSell.sl} (2700 + 10), TP=${sentGoldSell.tp} (2700 - 15) ✅`);

  console.log('\n================================================================');
  console.log('🎉 ALL DIRECT PRICE DISTANCE TESTS PASSED 100% SUCCESSFULLY!');
  console.log('================================================================');
}

runDirectPriceDistanceTests().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
