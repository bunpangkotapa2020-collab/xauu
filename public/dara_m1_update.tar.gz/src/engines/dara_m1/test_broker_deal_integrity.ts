import { DaRaM1Engine } from './DaRaM1Engine';
import { DaRaBrokerInterface, DaRaTelegramInterface, DaRaUserSettings } from './types';

class MockBroker implements DaRaBrokerInterface {
  public closedDeals: Record<string, any> = {};
  public openPositions: any[] = [];

  async sendOrder() { return { success: true, ticket: '10001' }; }
  async modifyPosition() { return { success: true }; }
  async getOpenPositions() { return this.openPositions; }
  async getClosedDeal(ticket: string | number) {
    return this.closedDeals[String(ticket)] || { found: false };
  }
  async getSymbolInfo() {
    return { pointSize: 0.01 };
  }
}

class MockTelegram implements DaRaTelegramInterface {
  public sentAlerts: { title: string; message: string; dedupeKey?: string }[] = [];
  async notify(title: string, message: string, dedupeKey?: string) {
    this.sentAlerts.push({ title, message, dedupeKey });
  }
}

const testSettings: DaRaUserSettings = {
  lotSize: 0.05,
  slDistance: 10,
  tpDistance: 8,
  dailyLossLimit: 2000,
  maxOpenTrades: 4,
  maxConsecutiveSL: 6,
  cooldownMinutes: 20,
  maxSpreadPoints: 27,
  newsFilterEnabled: true,
  newsMinsBefore: 30,
  newsMinsAfter: 30,
  trailingEnabled: true,
  trailingDistance: 1.5,
  trailingRule: 'Auto at Original TP (1.5 Price Distance)'
};

async function runAudit() {
  console.log('================================================================');
  console.log('🔍 AUDIT: REAL BROKER DEAL HISTORY VS TELEGRAM EXIT REASON');
  console.log('================================================================\n');

  let passed = 0;
  let total = 0;

  function assert(cond: boolean, desc: string) {
    total++;
    if (cond) {
      console.log(`  ✅ [PASS] ${desc}`);
      passed++;
    } else {
      console.error(`  ❌ [FAIL] ${desc}`);
      process.exit(1);
    }
  }

  // SCENARIO 1: The User's exact reported case
  // TP was 4471.121, but exit was 4470.309 with positive profit from Manual Close / API
  console.log('--- SCENARIO 1: Early Exit with Positive Profit (Manual Close / Close By Client) ---');
  const broker1 = new MockBroker();
  const tg1 = new MockTelegram();
  const engine1 = new DaRaM1Engine(broker1, testSettings, tg1);
  engine1.start();

  broker1.openPositions = [{
    ticket: '99001',
    symbol: 'XAUUSD',
    type: 'BUY',
    lot: 0.05,
    openPrice: 4463.121,
    currentPrice: 4470.309,
    sl: 4453.121,
    tp: 4471.121,
    openTime: Date.now() - 60000
  }];

  (engine1 as any).stateMachine.activePosition = {
    ticket: '99001',
    symbol: 'XAUUSD',
    type: 'BUY',
    lot: 0.05,
    openPrice: 4463.121,
    currentPrice: 4470.309,
    sl: 4453.121,
    tp: 4471.121,
    originalTp: 4471.121,
    trailingActivated: false,
    openTime: Date.now() - 60000
  };
  (engine1 as any).stateMachine.state = 'TRADE_ACTIVE';

  // Position closes on broker:
  broker1.openPositions = [];
  broker1.closedDeals['99001'] = {
    found: true,
    price: 4470.309,
    profit: 35.94, // Positive profit in USC
    reason: 'DEAL_REASON_CLIENT',
    comment: 'close by client'
  };

  await engine1.onMarketUpdate({
    symbol: 'XAUUSD',
    bid: 4470.309,
    ask: 4470.509,
    spreadPoints: 20,
    serverTime: Date.now(),
    m1Candles: []
  });

  const alert1 = tg1.sentAlerts.find(a => a.title.includes('បិទ'));
  assert(alert1 !== undefined, 'Trade close Telegram alert was sent');
  assert(!alert1!.title.includes('ប៉ះ TP'), 'Alert is NOT falsely claimed as TP HIT');
  assert(alert1!.title.includes('Manual') || alert1!.title.includes('បិទ BUY'), 'Alert correctly identifies Manual/Client Close');
  assert(alert1!.message.includes('4470.309'), 'Alert contains real exit price 4470.309 from broker');
  assert(alert1!.message.includes('+35.94 USC'), 'Alert contains real profit +35.94 USC');

  // SCENARIO 2: Real Broker TP Hit
  console.log('\n--- SCENARIO 2: Real Broker TP Hit (DEAL_REASON_TP) ---');
  const broker2 = new MockBroker();
  const tg2 = new MockTelegram();
  const engine2 = new DaRaM1Engine(broker2, testSettings, tg2);
  engine2.start();

  broker2.openPositions = [];
  broker2.closedDeals['99002'] = {
    found: true,
    price: 4471.121,
    profit: 40.00,
    reason: 'DEAL_REASON_TP',
    comment: '[tp 4471.121]'
  };

  (engine2 as any).stateMachine.activePosition = {
    ticket: '99002',
    symbol: 'XAUUSD',
    type: 'BUY',
    lot: 0.05,
    openPrice: 4463.121,
    currentPrice: 4471.121,
    sl: 4453.121,
    tp: 4471.121,
    originalTp: 4471.121,
    trailingActivated: false,
    openTime: Date.now() - 60000
  };
  (engine2 as any).stateMachine.state = 'TRADE_ACTIVE';

  await engine2.onMarketUpdate({
    symbol: 'XAUUSD',
    bid: 4471.121,
    ask: 4471.321,
    spreadPoints: 20,
    serverTime: Date.now(),
    m1Candles: []
  });

  const alert2 = tg2.sentAlerts.find(a => a.title.includes('បិទ'));
  assert(alert2 !== undefined, 'Telegram alert was sent');
  assert(alert2!.title.includes('✅ បិទ BUY — ប៉ះ TP'), 'Alert correctly identifies real TP HIT');
  assert(alert2!.message.includes('TP: 4471.121'), 'Alert displays correct TP');
  assert(alert2!.message.includes('ចេញ: 4471.121'), 'Alert displays exact broker fill price');
  assert(alert2!.message.includes('+40.00 USC'), 'Alert displays profit in USC');

  // SCENARIO 3: Real Broker SL Hit
  console.log('\n--- SCENARIO 3: Real Broker SL Hit (DEAL_REASON_SL) ---');
  const broker3 = new MockBroker();
  const tg3 = new MockTelegram();
  const engine3 = new DaRaM1Engine(broker3, testSettings, tg3);
  engine3.start();

  broker3.openPositions = [];
  broker3.closedDeals['99003'] = {
    found: true,
    price: 4460.924,
    profit: -50.00,
    reason: 'DEAL_REASON_SL',
    comment: '[sl 4460.924]'
  };

  (engine3 as any).stateMachine.activePosition = {
    ticket: '99003',
    symbol: 'XAUUSD',
    type: 'BUY',
    lot: 0.05,
    openPrice: 4470.358,
    currentPrice: 4460.924,
    sl: 4460.924,
    tp: 4480.000,
    originalTp: 4480.000,
    trailingActivated: false,
    openTime: Date.now() - 60000
  };
  (engine3 as any).stateMachine.state = 'TRADE_ACTIVE';

  await engine3.onMarketUpdate({
    symbol: 'XAUUSD',
    bid: 4460.924,
    ask: 4461.124,
    spreadPoints: 20,
    serverTime: Date.now(),
    m1Candles: []
  });

  const alert3 = tg3.sentAlerts.find(a => a.title.includes('បិទ'));
  assert(alert3 !== undefined, 'Telegram alert was sent');
  assert(alert3!.title.includes('❌ បិទ BUY — ប៉ះ SL'), 'Alert correctly identifies real SL HIT');
  assert(alert3!.message.includes('SL: 4460.924'), 'Alert displays correct SL');
  assert(alert3!.message.includes('ចេញ: 4460.924'), 'Alert displays broker fill price');
  assert(alert3!.message.includes('ខាត: -50.00 USC'), 'Alert displays loss in USC');

  // SCENARIO 4: Trailing SL Hit
  console.log('\n--- SCENARIO 4: Trailing SL Hit (Profit Protection) ---');
  const broker4 = new MockBroker();
  const tg4 = new MockTelegram();
  const engine4 = new DaRaM1Engine(broker4, testSettings, tg4);
  engine4.start();

  broker4.openPositions = [];
  broker4.closedDeals['99004'] = {
    found: true,
    price: 4470.309,
    profit: 35.94,
    reason: 'DEAL_REASON_SL',
    comment: '[sl 4470.309]'
  };

  (engine4 as any).stateMachine.activePosition = {
    ticket: '99004',
    symbol: 'XAUUSD',
    type: 'BUY',
    lot: 0.05,
    openPrice: 4463.121,
    currentPrice: 4470.309,
    sl: 4470.309,
    tp: 4471.121,
    originalTp: 4471.121,
    trailingActivated: true, // Trailing was active
    openTime: Date.now() - 60000
  };
  (engine4 as any).stateMachine.state = 'TRADE_ACTIVE';

  await engine4.onMarketUpdate({
    symbol: 'XAUUSD',
    bid: 4470.309,
    ask: 4470.509,
    spreadPoints: 20,
    serverTime: Date.now(),
    m1Candles: []
  });

  const alert4 = tg4.sentAlerts.find(a => a.title.includes('បិទ'));
  assert(alert4 !== undefined, 'Telegram alert was sent');
  assert(alert4!.title.includes('🔵 បិទ BUY — Trailing SL'), 'Alert correctly identifies TRAILING SL HIT');
  assert(alert4!.message.includes('SL: 4470.309'), 'Alert displays trailing SL');
  assert(alert4.message.includes('ចំណេញ: +35.94 USC'), 'Alert displays profit in USC');

  console.log(`\n================================================================`);
  console.log(`🎉 AUDIT COMPLETE: ${passed} / ${total} TESTS PASSED!`);
  console.log(`================================================================`);
}

runAudit().catch(err => {
  console.error(err);
  process.exit(1);
});
