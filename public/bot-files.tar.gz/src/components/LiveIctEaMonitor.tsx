import { IctPipelineFlow } from "./IctPipelineFlow";
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Clock, 
  TrendingUp, 
  TrendingDown, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  Terminal, 
  Search, 
  Server, 
  Wifi, 
  Radio, 
  Zap,
  Copy,
  Check,
  Power,
  ShieldAlert,
  Cpu,
  RefreshCw
} from 'lucide-react';
import { BotState, ICTAnalysisMonitor } from '../types';

interface Props {
  state: BotState;
}

export const LiveIctEaMonitor: React.FC<Props> = ({ state }) => {
  const [filterText, setFilterText] = useState('');
  const [selectedTab, setSelectedTab] = useState<'all' | 'h4' | 'm15' | 'm1' | 'system'>('all');
  const [copiedLogs, setCopiedLogs] = useState(false);
  const [timeAgo, setTimeAgo] = useState('ទើបតែវិភាគ (Just now)');
  const [heartbeatAgo, setHeartbeatAgo] = useState('0s ago');
  const [durationStr, setDurationStr] = useState('0m 00s');

  const telemetry: ICTAnalysisMonitor | undefined = state.ictAnalysis;
  const startConf = state.startConfirmation;

  // Realtime ticker for start confirmed state and heartbeats
  useEffect(() => {
    const updateTick = () => {
      // 1. Heartbeat relative
      if (startConf?.eaHeartbeatTime) {
        const hbSecs = Math.max(0, Math.floor((Date.now() - startConf.eaHeartbeatTime) / 1000));
        setHeartbeatAgo(`${hbSecs} វិនាទីមុន (${hbSecs}s ago)`);
      } else {
        setHeartbeatAgo('កំពុងភ្ជាប់... (Syncing)');
      }

      // 2. Running Duration
      const isDesiredRunning = state.status === 'running' || state.desiredBotState === 'RUNNING' || Boolean(startConf?.isStartRequested);
      if (isDesiredRunning && startConf?.runningDurationSeconds !== undefined) {
        const totalSecs = startConf.runningDurationSeconds;
        const hours = Math.floor(totalSecs / 3600);
        const mins = Math.floor((totalSecs % 3600) / 60);
        const secs = totalSecs % 60;
        if (hours > 0) {
          setDurationStr(`${hours} ម៉ោង ${mins} នាទី ${secs} វិនាទី (${hours}h ${mins}m)`);
        } else {
          setDurationStr(`${mins} នាទី ${secs} វិនាទី (${mins}m ${secs}s)`);
        }
      } else {
        setDurationStr('មិនទាន់ដំណើរការ (Offline)');
      }
    };

    updateTick();
    const interval = setInterval(updateTick, 1000);
    return () => clearInterval(interval);
  }, [startConf, state.status]);

  // Calculate relative time since last analysis in Khmer
  useEffect(() => {
    const updateAgo = () => {
      if (!telemetry?.lastAnalysisTime) {
        setTimeAgo('កំពុងរង់ចាំទិន្នន័យ (Waiting)...');
        return;
      }
      const seconds = Math.floor((Date.now() - telemetry.lastAnalysisTime) / 1000);
      if (seconds < 2) {
        setTimeAgo('ទើបតែវិភាគ (Just now)');
      } else if (seconds < 60) {
        setTimeAgo(`${seconds} វិនាទីមុន (${seconds}s ago)`);
      } else {
        const mins = Math.floor(seconds / 60);
        setTimeAgo(`${mins} នាទី ${seconds % 60} វិនាទីមុន (${mins}m ago)`);
      }
    };

    updateAgo();
    const interval = setInterval(updateAgo, 1000);
    return () => clearInterval(interval);
  }, [telemetry?.lastAnalysisTime]);

  const fallbackH4 = useMemo(() => {
    return telemetry?.h4 || {
      bias: 'NEUTRAL' as const,
      structure: 'WAITING' as const,
      candleCount: 0
    };
  }, [telemetry]);

  const fallbackM15 = useMemo(() => {
    return telemetry?.m15 || {
      liquiditySweep: 'WAITING' as const,
      cisd: 'WAITING' as const,
      swingHigh: 0,
      swingLow: 0,
      targetHigh: 0,
      targetLow: 0,
      candleCount: 0
    };
  }, [telemetry]);

  const fallbackM1 = useMemo(() => {
    return telemetry?.m1 || {
      displacement: 'WAITING' as const,
      orderBlock: 'WAITING' as const,
      fvg: 'WAITING' as const,
      retracement: 'WAITING' as const,
      obZone: null,
      fvgZone: null,
      candleCount: 0
    };
  }, [telemetry]);

  const fallbackHealth = useMemo(() => {
    return telemetry?.systemHealth || {
      mt5Connection: Boolean(state.account?.isConnected),
      eaBridge: Boolean(state.account?.eaConnected),
      vps: Boolean(state.account?.vpsOnline),
      liveMarketData: Boolean(state.marketDataStatus?.includes('LIVE')),
      dataFreshness: true,
      newsFilter: state.newsProviderStatus !== 'UNAVAILABLE',
      riskGuard: !state.dailyLossLimitHit
    };
  }, [telemetry, state]);

  // Translate waiting reason into clear, intuitive Khmer
  const khmerWaitingReason = useMemo(() => {
    const raw = telemetry?.waitingReason || '⏳ WAITING FOR M15 LIQUIDITY SWEEP';
    
    if (raw.includes('WAITING FOR M15 LIQUIDITY SWEEP')) {
      return '⏳ កំពុងរង់ចាំការបោសយកសាច់ប្រាក់លើ M15 (WAITING FOR M15 LIQUIDITY SWEEP)';
    }
    if (raw.includes('M15 SWEEP FOUND') && raw.includes('WAITING FOR CISD')) {
      return '⏳ បាន Sweep សាច់ប្រាក់ M15 ហើយ — កំពុងរង់ចាំការបញ្ជាក់ CISD (WAITING FOR CISD)';
    }
    if (raw.includes('CISD CONFIRMED') && (raw.includes('DISPLACEMENT') || raw.includes('OB'))) {
      return '⏳ បាន CISD ហើយ — កំពុងរង់ចាំ M1 Displacement & Order Block (WAITING FOR M1 OB)';
    }
    if (raw.includes('OB/FVG FOUND') || raw.includes('WAITING FOR RETRACEMENT') || raw.includes('RETRACEMENT')) {
      return raw.startsWith('⏳ SETUP VALID') ? raw : `🟢 EA កំពុងធ្វើការ | ⏳ Setup ត្រូវបានរកឃើញ | ⏳ កំពុងរង់ចាំ Retracement | 🔄 Analysis កំពុងបន្ត (${raw})`;
    }
    if (raw.includes('RETRACEMENT CONFIRMED') || raw.includes('READY TO EXECUTE')) {
      return '🟢 បានទាញថយក្រោយពេញលេញ — ត្រៀមបើក Trade (READY TO EXECUTE)';
    }
    if (raw.includes('INSUFFICIENT OR STALE') || raw.includes('FEED')) {
      return '🔴 ទិន្នន័យ MT5 មិនទាន់គ្រប់គ្រាន់ ឬដាច់សេវា (FEED STALE OR DISCONNECTED)';
    }
    if (raw.includes('RISK') || raw.includes('NEWS')) {
      return `🛡️ ផ្អាកដោយសារការការពារ Risk ឬព័ត៌មាន News (${raw})`;
    }
    return raw;
  }, [telemetry?.waitingReason]);

  // Translate Entry status into Khmer
  const khmerEntryStatus = useMemo(() => {
    const s = telemetry?.entryStatus || 'WAITING';
    switch (s) {
      case 'READY TO EXECUTE':
        return '🟢 ត្រៀមចូល Trade (READY)';
      case 'VALID SETUP':
        return '🟢 រកឃើញ Setup ត្រឹមត្រូវ (VALID SETUP)';
      case 'TRADE OPENED':
        return '🔵 បានចូល Trade រួច (TRADE OPENED)';
      case 'SEARCHING':
        return '🟡 កំពុងស្វែងរក (SEARCHING)';
      case 'WAITING':
      default:
        return '🟡 មិនទាន់ចូល / កំពុងរង់ចាំ (WAITING)';
    }
  }, [telemetry?.entryStatus]);

  const filteredLogs = useMemo(() => {
    const logs = telemetry?.recentLogs || [];
    return logs.filter(log => {
      const matchesSearch = filterText === '' || 
        log.message.toLowerCase().includes(filterText.toLowerCase()) ||
        log.timestamp.includes(filterText);

      if (!matchesSearch) return false;

      if (selectedTab === 'all') return true;
      if (selectedTab === 'h4') return log.message.includes('H4');
      if (selectedTab === 'm15') return log.message.includes('M15');
      if (selectedTab === 'm1') return log.message.includes('M1') || log.message.includes('OB') || log.message.includes('FVG');
      if (selectedTab === 'system') return log.message.includes('MT5') || log.message.includes('EA') || log.message.includes('BLOCK');
      return true;
    });
  }, [telemetry?.recentLogs, filterText, selectedTab]);

  const handleCopyLogs = () => {
    const text = (telemetry?.recentLogs || [])
      .map(l => `${l.timestamp} ${l.message}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopiedLogs(true);
    setTimeout(() => setCopiedLogs(false), 2000);
  };

  const statusDisplay = useMemo(() => {
    switch (telemetry?.status) {
      case 'READY':
        return {
          text: '🟢 រួចរាល់ / ត្រៀមចូល (READY)',
          color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
        };
      case 'ANALYZING':
        return {
          text: '🟢 កំពុងវិភាគ (ANALYZING)',
          color: 'bg-blue-500/20 text-blue-400 border-blue-500/40'
        };
      case 'ERROR':
        return {
          text: '🔴 មានបញ្ហា (ERROR)',
          color: 'bg-rose-500/20 text-rose-400 border-rose-500/40'
        };
      case 'WAITING':
      default:
        return {
          text: '🟡 កំពុងរង់ចាំ (WAITING)',
          color: 'bg-amber-500/20 text-amber-400 border-amber-500/40'
        };
    }
  }, [telemetry?.status]);

  return (
    <div id="live-ict-ea-monitor" className="mt-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl backdrop-blur-sm space-y-6">
      
      {/* 1. HEADER & OVERVIEW */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400">
            <Activity size={24} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-wide">
                🟢 ផ្ទាំងតាមដាន EA ICT ផ្ទាល់
              </h2>
              <span className="text-[11px] text-slate-400 font-mono">
                (LIVE ICT EA MONITOR)
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                មើលទិន្នន័យប៉ុណ្ណោះ (READ-ONLY)
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              លំហូរវិភាគជាក់ស្តែង៖ ទិសដៅ H4 ➔ បោសសាច់ប្រាក់ M15 ➔ តំបន់ចូល M1 (OB/FVG)
            </p>
          </div>
        </div>

        {/* Status Badges & Time */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className={`px-3 py-1.5 rounded-lg border font-mono text-xs font-bold flex items-center gap-2 ${statusDisplay.color}`}>
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                telemetry?.status === 'READY' ? 'bg-emerald-400' :
                telemetry?.status === 'ERROR' ? 'bg-rose-400' :
                telemetry?.status === 'ANALYZING' ? 'bg-blue-400' : 'bg-amber-400'
              }`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                telemetry?.status === 'READY' ? 'bg-emerald-500' :
                telemetry?.status === 'ERROR' ? 'bg-rose-500' :
                telemetry?.status === 'ANALYZING' ? 'bg-blue-500' : 'bg-amber-500'
              }`}></span>
            </span>
            <span>ស្ថានភាព EA: {statusDisplay.text}</span>
          </div>

          <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs flex items-center gap-2">
            <Clock size={14} className="text-cyan-400" />
            <span>⏱ វិភាគចុងក្រោយ៖ <strong className="text-white">{timeAgo}</strong></span>
          </div>

          <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 flex items-center gap-2">
            <span className="text-amber-400 font-bold">{state.activeGoldSymbol || 'XAUUSD'}</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Bid: <strong className="text-white">{state.bidPrice || state.goldPrice}</strong></span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Ask: <strong className="text-white">{state.askPrice || state.goldPrice}</strong></span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Spread: <strong className="text-cyan-400">{state.spreadPoints || 26} pts</strong></span>
          </div>
        </div>
      </div>

      {/* START CONFIRMED / EA RUNNING STATE & DISCONNECTION WARNING BANNER */}
      {startConf?.isEntriesBlocked && (
        <div className="p-4 rounded-xl border border-rose-500/60 bg-rose-950/40 text-rose-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-[0_0_20px_rgba(244,63,94,0.15)] animate-pulse">
          <div className="flex items-start gap-3">
            <ShieldAlert size={26} className="text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-black tracking-wide text-rose-300">
                🔴 EA ត្រូវបាន START រួច | ⚠️ ប៉ុន្តែការតភ្ជាប់ MT5 / Market Data បានដាច់
              </div>
              <div className="text-xs text-rose-200/90 mt-1 leading-relaxed">
                មូលហេតុ៖ <strong className="text-white underline">{startConf.blockedReason || 'Market Feed Offline or Disconnected'}</strong> — ប្រព័ន្ធនៅតែរក្សាស្ថានភាព STARTED ប៉ុន្តែបានបង្កកការបើក Trade ថ្មីដោយស្វ័យប្រវត្តិដើម្បីសុវត្ថិភាពទុន។
              </div>
            </div>
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-rose-900/60 border border-rose-400/50 text-xs font-mono font-black text-rose-200 shrink-0 uppercase">
            🛑 NEW ENTRIES = BLOCKED
          </div>
        </div>
      )}

      {/* VERIFIABLE START CONFIRMATION & EA HEARTBEAT TELEMETRY GRID */}
      <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/70 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <Cpu size={16} className="text-indigo-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              🟢 ការបញ្ជាក់ដំណើរការ EA ជាក់ស្តែង (START CONFIRMED & EA HEARTBEAT STATE)
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border flex items-center gap-1.5 ${
              startConf?.eaRunning
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : state.status === 'running'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${startConf?.eaRunning ? 'bg-emerald-400 animate-ping' : state.status === 'running' ? 'bg-amber-400' : 'bg-slate-500'}`}></span>
              EA RUNNING = {startConf?.eaRunning ? 'YES (កំពុងរត់)' : state.status === 'running' ? 'CONFIRMING...' : 'NO (បិទ)'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs font-mono">
          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">START Request Time:</span>
            <span className="text-slate-200 font-bold mt-1 truncate text-[11px]">
              {startConf?.startRequestedTime ? new Date(startConf.startRequestedTime).toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—'}
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">START Confirmed Time:</span>
            <span className="text-emerald-400 font-bold mt-1 truncate text-[11px]">
              {startConf?.startConfirmedTime ? new Date(startConf.startConfirmedTime).toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'កំពុងរង់ចាំ'}
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">EA Heartbeat:</span>
            <span className="text-cyan-400 font-bold mt-1 text-[11px] flex items-center gap-1">
              <Activity size={12} className="animate-pulse" />
              {heartbeatAgo}
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">រយៈពេលដំណើរការ (Duration):</span>
            <span className="text-indigo-300 font-bold mt-1 text-[11px]">
              {durationStr}
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">ស្ថានភាពតភ្ជាប់ (Connection):</span>
            <span className={`font-bold mt-1 text-[11px] ${
              startConf?.connectionState === 'HEALTHY' ? 'text-emerald-400' :
              startConf?.connectionState === 'DISCONNECTED' ? 'text-rose-400' :
              startConf?.connectionState === 'BLOCKED_FEED' ? 'text-amber-400' : 'text-slate-400'
            }`}>
              {startConf?.connectionState === 'HEALTHY' ? '🟢 ល្អប្រពៃ (HEALTHY)' :
               startConf?.connectionState === 'DISCONNECTED' ? '🔴 ដាច់ការតភ្ជាប់' :
               startConf?.connectionState === 'BLOCKED_FEED' ? '🟡 ដាច់ Feed តម្លៃ' : '⚪ ទំនេរ (IDLE)'}
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800/80 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">Last Backend Sync:</span>
            <span className="text-slate-300 font-bold mt-1 text-[11px] flex items-center gap-1">
              <RefreshCw size={11} className="text-slate-500" />
              {startConf?.lastBackendSyncTime ? new Date(startConf.lastBackendSyncTime).toLocaleTimeString('km-KH') : 'Live'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. PROMINENT WAITING REASON BANNER */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        telemetry?.status === 'READY'
          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
          : telemetry?.status === 'ERROR'
          ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
          : 'bg-amber-950/30 border-amber-500/30 text-amber-300'
      }`}>
        <div className="flex items-start sm:items-center gap-3">
          {telemetry?.status === 'READY' ? (
            <CheckCircle2 size={20} className="text-emerald-400 shrink-0 mt-0.5 sm:mt-0" />
          ) : telemetry?.status === 'ERROR' ? (
            <AlertCircle size={20} className="text-rose-400 shrink-0 mt-0.5 sm:mt-0" />
          ) : (
            <Clock size={20} className="text-amber-400 shrink-0 mt-0.5 sm:mt-0 animate-spin" />
          )}
          <div>
            <div className="text-xs font-bold tracking-wider uppercase opacity-80">
              📌 មូលហេតុដែលកំពុងរង់ចាំ & ដំណាក់កាលវិភាគ
            </div>
            <div className="text-sm sm:text-base font-extrabold mt-0.5">
              {khmerWaitingReason}
            </div>
          </div>
        </div>
        <div className="text-xs font-mono px-3 py-1 bg-slate-900/80 rounded-lg border border-slate-700/60 self-start sm:self-auto text-slate-300">
          ស្ថានភាពចូល Trade: <strong className="text-white">{khmerEntryStatus}</strong>
        </div>
      </div>

      <IctPipelineFlow telemetry={telemetry} state={state} />


      {/* 4. VALID SETUP DETAILS (IF DETECTED) */}
      {telemetry?.validSetup && (
        <div className="bg-emerald-950/30 border border-emerald-500/40 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase text-emerald-400 tracking-wider flex items-center gap-1.5">
              <CheckCircle2 size={16} />
              🟢 រកឃើញ SETUP ត្រឹមត្រូវ — ត្រៀមចូល TRADE ពេល RETRACEMENT (VALID SETUP FORMED)
            </span>
            <span className="text-[10px] font-mono bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded">
              {telemetry.validSetup.setupId}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase">ទិសដៅ (DIRECTION)</span>
              <div className={`font-black text-sm mt-0.5 ${
                telemetry.validSetup.direction === 'BUY' ? 'text-blue-400' : 'text-rose-400'
              }`}>
                {telemetry.validSetup.direction === 'BUY' ? 'BUY (ទិញ)' : 'SELL (លក់)'}
              </div>
            </div>
            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase">តម្លៃចូល (EST. ENTRY)</span>
              <div className="font-bold text-sm text-white mt-0.5">
                {telemetry.validSetup.entry}
              </div>
            </div>
            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase">កាត់ខាត (STOP LOSS)</span>
              <div className="font-bold text-sm text-rose-400 mt-0.5">
                {telemetry.validSetup.sl}
              </div>
            </div>
            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase">យកចំណេញ (TAKE PROFIT)</span>
              <div className="font-bold text-sm text-emerald-400 mt-0.5">
                {telemetry.validSetup.tp}
              </div>
            </div>
            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800 col-span-2 sm:col-span-1">
              <span className="text-[10px] text-slate-400 uppercase">សមាមាត្រហានិភ័យ (R : R)</span>
              <div className="font-black text-sm text-cyan-400 mt-0.5">
                1 : {telemetry.validSetup.rr}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. SYSTEM HEALTH MATRIX */}
      <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Server size={14} className="text-indigo-400" />
            🛡️ សុខភាពប្រព័ន្ធ & ការគ្រប់គ្រងហានិភ័យ (SYSTEM HEALTH MATRIX)
          </span>
          <span className="text-[10px] font-mono text-slate-500">
            Exness VPS • Port 3000
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs font-mono">
          
          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <Wifi size={10} /> MT5
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.mt5Connection ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.mt5Connection ? '🟢 ភ្ជាប់ (CONNECTED)' : '🔴 ដាច់ (OFFLINE)'}
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <Radio size={10} /> EA BRIDGE
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.eaBridge ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.eaBridge ? '🟢 ដំណើរការ (ACTIVE)' : '🔴 ដាច់ (OFFLINE)'}
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <Server size={10} /> VPS
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.vps ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.vps ? '🟢 អនឡាញ (ONLINE)' : '🔴 ដាច់ (OFFLINE)'}
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <Activity size={10} /> តម្លៃផ្សារ
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.liveMarketData ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.liveMarketData ? '🟢 ផ្ទាល់ (LIVE)' : '🔴 គ្មានទិន្នន័យ'}
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <Zap size={10} /> ភាពយឺតយ៉ាវ
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.dataFreshness ? 'text-cyan-400' : 'text-amber-400'}`}>
              {telemetry?.latency?.latencyMs || state.account?.pingMs || 15} ms (ស្រស់)
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <ShieldCheck size={10} /> ព័ត៌មាន NEWS
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.newsFilter ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.newsFilter ? '🟢 សុវត្ថិភាព (SAFE)' : '🔴 ជាប់ហាមឃាត់'}
            </span>
          </div>

          <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800 flex flex-col justify-between col-span-2 sm:col-span-2 lg:col-span-1">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <ShieldCheck size={10} /> RISK GUARD
            </span>
            <span className={`font-bold mt-1 text-[11px] ${fallbackHealth.riskGuard ? 'text-emerald-400' : 'text-rose-400'}`}>
              {fallbackHealth.riskGuard ? '🟢 កំពុងការពារ (ACTIVE)' : '🔴 ដល់ដែនកំណត់'}
            </span>
          </div>

        </div>

        {/* Real-time Data Latency Timing Breakdown */}
        <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-xs font-mono">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
            <span className="text-slate-300 font-bold flex items-center gap-1.5">
              <Zap size={12} className="text-cyan-400" />
              ⚡ លម្អិតពេលវេលា & ភាពយឺតយ៉ាវនៃទិន្នន័យ (REAL-TIME DATA LATENCY BREAKDOWN)
            </span>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              ផ្សាយផ្ទាល់ពី MT5 (LIVE MT5 FEED)
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 text-[11px]">
            <div className="flex flex-col justify-between p-2 bg-slate-950/60 rounded border border-slate-800/80">
              <span className="text-slate-400 text-[10px]">ម៉ោង Tick MT5:</span>
              <span className="text-slate-200 font-bold mt-0.5 truncate">
                {telemetry?.latency?.mt5TickTime || new Date(state.lastTickTime || Date.now()).toISOString().replace('T', ' ').substring(0, 19) + ' UTC'}
              </span>
            </div>
            <div className="flex flex-col justify-between p-2 bg-slate-950/60 rounded border border-slate-800/80">
              <span className="text-slate-400 text-[10px]">ម៉ោង Backend ទទួលបាន:</span>
              <span className="text-slate-200 font-bold mt-0.5 truncate">
                {telemetry?.latency?.backendReceiveTime || new Date(state.lastTickTime || Date.now()).toISOString().replace('T', ' ').substring(0, 19) + ' UTC'}
              </span>
            </div>
            <div className="flex flex-col justify-between p-2 bg-slate-950/60 rounded border border-slate-800/80">
              <span className="text-slate-400 text-[10px]">ម៉ោងវិភាគ ICT:</span>
              <span className="text-slate-200 font-bold mt-0.5 truncate">
                {telemetry?.latency?.ictAnalysisTime || new Date(telemetry?.lastAnalysisTime || Date.now()).toISOString().replace('T', ' ').substring(0, 19) + ' UTC'}
              </span>
            </div>
            <div className="flex flex-col justify-between p-2 bg-slate-950/60 rounded border border-slate-800/80">
              <span className="text-slate-400 text-[10px]">អាយុកាល Tick ចុងក្រោយ:</span>
              <span className="text-emerald-400 font-bold mt-0.5">
                {telemetry?.latency?.lastTickAgeSeconds !== undefined ? `${telemetry.latency.lastTickAgeSeconds}s` : '0.4s'}
              </span>
            </div>
            <div className="flex flex-col justify-between p-2 bg-slate-950/60 rounded border border-slate-800/80">
              <span className="text-slate-400 text-[10px]">ភាពយឺតយ៉ាវសរុប:</span>
              <span className="text-cyan-400 font-bold mt-0.5">
                {telemetry?.latency?.latencyMs || state.account?.pingMs || 15} ms
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 6. LIVE ANALYSIS LOGS CONSOLE (TERMINAL VIEW - 100+ EVENTS) */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-inner">
        {/* Terminal Header */}
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Terminal size={16} className="text-emerald-400" />
            <span className="text-xs font-bold text-slate-200 font-mono">
              📜 កំណត់ត្រាការវិភាគជាក់ស្តែង (ANALYSIS AUDIT TRAIL — {filteredLogs.length} ព្រឹត្តិការណ៍)
            </span>
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1 text-[11px] font-mono">
            {[
              { id: 'all', label: 'ទាំងអស់ (All)' },
              { id: 'h4', label: 'កម្រិត H4' },
              { id: 'm15', label: 'កម្រិត M15' },
              { id: 'm1', label: 'កម្រិត M1' },
              { id: 'system', label: 'ប្រព័ន្ធ (System)' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  selectedTab === tab.id
                    ? 'bg-slate-800 text-cyan-400 font-bold border border-slate-700'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search & Copy */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search size={12} className="absolute left-2 top-2 text-slate-500" />
              <input
                type="text"
                placeholder="ស្វែងរក Logs..."
                value={filterText}
                onChange={e => setFilterText(e.target.value)}
                className="pl-6 pr-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[11px] text-slate-300 font-mono placeholder:text-slate-600 focus:outline-none focus:border-slate-700"
              />
            </div>
            <button
              onClick={handleCopyLogs}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 font-mono transition-colors"
              title="ចម្លង Logs ទាំងអស់ (Copy Logs)"
            >
              {copiedLogs ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
              <span>{copiedLogs ? 'បានចម្លង' : 'ចម្លង'}</span>
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div className="p-3 font-mono text-xs max-h-60 sm:max-h-72 overflow-y-auto space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
          {filteredLogs.length === 0 ? (
            <div className="text-slate-600 text-center py-6">
              មិនទាន់មានកំណត់ត្រាការវិភាគនៅក្នុង Buffer ឡើយ។
            </div>
          ) : (
            filteredLogs.map((log, idx) => (
              <div 
                key={idx} 
                className={`flex items-start gap-2 py-0.5 px-1 rounded transition-colors ${
                  idx === 0 ? 'bg-slate-900/60 font-semibold' : 'hover:bg-slate-900/30'
                }`}
              >
                <span className="text-slate-500 shrink-0 select-none text-[11px]">
                  {log.timestamp}
                </span>
                <span className={`break-all ${
                  log.level === 'success' ? 'text-emerald-400' :
                  log.level === 'warn' ? 'text-amber-300' :
                  log.level === 'error' ? 'text-rose-400 font-bold' :
                  'text-slate-300'
                }`}>
                  {log.message}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
};

