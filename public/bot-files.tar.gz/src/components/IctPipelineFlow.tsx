import React from 'react';
import { ICTTelemetry } from '../MASTER_ICT_EA';
import { CheckCircle2, Clock, Crosshair, AlertCircle, ArrowRight, Layers, Zap, Terminal, Activity, ArrowDown } from 'lucide-react';

interface Props {
  telemetry: ICTTelemetry | null;
  state: any;
}

export const IctPipelineFlow: React.FC<Props> = ({ telemetry, state }) => {
  const currentPrice = telemetry?.livePrice?.ask || 0;
  const setup = telemetry?.validSetup;
  const h4 = telemetry?.h4;
  const m15 = telemetry?.m15;
  const m1 = telemetry?.m1;

  // Derive steps
  const h4Confirmed = h4?.structure === 'CONFIRMED';
  
  const m15Sweep = m15?.liquiditySweep === 'FOUND';
  const m15Cisd = m15?.cisd === 'CONFIRMED';
  const m15Confirmed = m15Sweep && m15Cisd;

  const m1Disp = m1?.displacement === 'FOUND';
  const m1Fvg = m1?.fvg === 'FOUND';
  const m1Ob = m1?.orderBlock === 'FOUND';
  const m1Confirmed = m1Disp && m1Fvg && m1Ob;

  const fullSetupConfirmed = !!setup || (h4Confirmed && m15Confirmed && m1Confirmed);

  const signal = state?.signalDetails;
  
  // Stages
  const actualExecutionState = signal?.executionState || setup?.executionState;
  const isRejectedBeforeTrigger = actualExecutionState === 'REJECTED: PRICE_BROKE_OB' || actualExecutionState === 'REJECTED: SETUP_EXPIRED_TIMEOUT' || actualExecutionState === 'REJECTED: TP_REACHED_BEFORE_ENTRY';
  const isTriggered = setup?.stage === 'TRIGGERED' || (actualExecutionState && !actualExecutionState.includes('WAITING') && !isRejectedBeforeTrigger);
  const isExecutionBlocked = actualExecutionState && (actualExecutionState.includes('REJECTED') || actualExecutionState.includes('BLOCKED'));
  const isOrderSent = actualExecutionState === 'ORDER_SENT' || actualExecutionState === 'POSITION_OPENED';
  const isPositionOpened = actualExecutionState === 'POSITION_OPENED';

  // Entry calculations - Single source of truth from locked ICT setup
  const actualEntry = setup?.actualEntry || setup?.entry || signal?.actualEntry || signal?.entry || (setup?.direction === 'BUY' ? setup?.obHigh : setup?.obLow);
  const actualSl = setup?.sl !== undefined && setup?.sl !== null ? setup.sl : signal?.sl;
  const actualTp = setup?.tp !== undefined && setup?.tp !== null ? setup.tp : signal?.tp;
  
  const distPts = actualEntry ? Math.abs(currentPrice - actualEntry).toFixed(1) : '—';
  
  const Box = ({ title, active, subtitle, icon: Icon, error = false, highlight = false, value = null, children }: any) => {
    let bg = 'bg-slate-900/50 border-slate-700/50 opacity-60';
    let text = 'text-slate-400';
    let titleText = 'text-slate-400';
    
    if (active) {
      bg = highlight ? 'bg-amber-500/20 border-amber-500/50' : 'bg-emerald-950/40 border-emerald-500/30';
      text = highlight ? 'text-amber-300' : 'text-emerald-300';
      titleText = highlight ? 'text-amber-400' : 'text-emerald-400';
    }
    if (error) {
      bg = 'bg-rose-950/40 border-rose-500/30';
      text = 'text-rose-300';
      titleText = 'text-rose-400';
    }

    return (
      <div className={`flex flex-col p-3 rounded-xl border transition-all ${bg}`}>
        <div className="flex items-center gap-2 mb-2">
          {active ? <CheckCircle2 size={14} className={titleText} /> : error ? <AlertCircle size={14} className={titleText} /> : <Clock size={14} className={titleText} />}
          <span className={`text-xs font-bold uppercase ${titleText}`}>{title}</span>
        </div>
        {children ? (
            <div className={`text-[11px] mt-auto font-mono ${text}`}>{children}</div>
        ) : (subtitle || value) && (
          <div className={`text-[11px] mt-auto font-mono ${text}`}>
            {value && <div className="font-black text-xs mb-0.5">{value}</div>}
            {subtitle && <div>{subtitle}</div>}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="mt-6 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Activity size={16} className="text-blue-400" />
        <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
          លំហូរតាមដាន ICT (ICT SETUP FLOW)
        </h3>
      </div>
      
      <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 shadow-xl">
        
        {/* ROW 1: DETECTION */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Box 
            title="H4 / H4" 
            active={h4Confirmed} 
          >
            {h4Confirmed ? (
              <>
                <div className="font-bold text-emerald-400">
                  {h4?.bias === 'BEARISH' ? 'BEARISH / ចុះ' : h4?.bias === 'BULLISH' ? 'BULLISH / ឡើង' : 'CONFIRMED'}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">បានបញ្ជាក់</div>
              </>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="M15 / M15" 
            active={m15Confirmed} 
          >
            {m15Confirmed ? (
              <>
                <div>Confirmed</div>
                <div className="text-[11px] text-slate-400">បានបញ្ជាក់</div>
              </>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="M1 / M1" 
            active={m1Confirmed} 
          >
            {m1Confirmed ? (
              <>
                <div>Confirmed</div>
                <div className="text-[11px] text-slate-400">បានបញ្ជាក់</div>
              </>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="FULL SETUP" 
            active={fullSetupConfirmed} 
          >
            <div className="text-[11px] text-slate-400 mb-1">Setup ពេញលេញ</div>
            {fullSetupConfirmed ? (
              <>
                <div>CONFIRMED</div>
                <div className="text-[11px] text-emerald-400/80">បានបញ្ជាក់</div>
              </>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
        </div>

        {/* ARROW DOWN */}
        <div className="flex justify-center my-3 opacity-30">
          <ArrowDown size={16} className="text-slate-400" />
        </div>

        {/* ROW 2: ENTRY */}
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Box 
            title="ENTRY ZONE" 
            active={fullSetupConfirmed} 
          >
            <div className="text-[11px] text-slate-400 mb-1">តំបន់ចូល (Area)</div>
            {fullSetupConfirmed && (setup?.obLow !== undefined || setup?.obHigh !== undefined) ? (
              <div className="font-mono font-bold text-sm text-amber-300">
                [{setup?.obLow !== undefined ? setup.obLow.toFixed(3) : '—'} – {setup?.obHigh !== undefined ? setup.obHigh.toFixed(3) : '—'}]
              </div>
            ) : (
              <>
                <div className="font-mono font-bold">WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="RETRACEMENT" 
            active={isTriggered || isRejectedBeforeTrigger} 
            error={isRejectedBeforeTrigger}
          >
            <div className="text-[11px] text-slate-400 mb-1">បកត្រឡប់ចូលតំបន់</div>
            {isTriggered ? (
              <>
                <div className="text-emerald-400 font-bold">ENTERED ZONE</div>
                <div className="text-[11px] text-emerald-400/80">តម្លៃបានចូលតំបន់ OB</div>
              </>
            ) : isRejectedBeforeTrigger ? (
              <>
                <div className="text-rose-400 font-bold">FAILED</div>
                <div className="text-[11px] text-rose-400/80">តម្លៃបានបំបែកតំបន់ OB</div>
              </>
            ) : fullSetupConfirmed ? (
              <>
                <div className="font-mono font-bold text-amber-400">WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            ) : (
              <>
                <div className="font-mono font-bold">WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="🎯 ACTUAL ENTRY" 
            active={isTriggered || fullSetupConfirmed} 
            highlight={fullSetupConfirmed && !isTriggered && !isRejectedBeforeTrigger}
            error={isExecutionBlocked && isTriggered}
          >
            <div className="text-[11px] text-slate-400 mb-1.5">ចំណុចចូលពិត (Exact Trigger Price)</div>
            <div className="space-y-1 font-mono text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-[11px]">Entry Price:</span>
                <strong className="text-white text-xs sm:text-sm font-bold tracking-wide">
                  {actualEntry !== undefined && actualEntry !== null && Number(actualEntry) > 0 
                    ? Number(actualEntry).toFixed(3) 
                    : 'XXXX.XXX'}
                </strong>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-[11px]">Trigger Status:</span>
                {isTriggered ? (
                  <strong className="text-emerald-400 font-bold text-[11px]">ENTRY TRIGGERED</strong>
                ) : isRejectedBeforeTrigger ? (
                  <strong className="text-rose-400 font-bold text-[11px]">CANCELED</strong>
                ) : (
                  <strong className="text-amber-400 font-bold text-[11px]">WAITING</strong>
                )}
              </div>
            </div>
            
            {isTriggered && (
              <div className="pt-1.5 mt-1.5 border-t border-slate-800/80 space-y-0.5 font-mono text-[10px]">
                <div className="flex justify-between gap-1">
                  <span className="text-slate-500">Direction:</span>
                  <strong className={setup?.direction === 'BUY' ? 'text-blue-400' : 'text-rose-400'}>
                    {setup?.direction === 'BUY' ? 'BUY (ទិញ)' : 'SELL (លក់)'}
                  </strong>
                </div>
                <div className="flex justify-between gap-1">
                  <span className="text-slate-500">SL:</span>
                  <strong className="text-rose-400">{actualSl ? actualSl.toFixed(3) : '—'}</strong>
                </div>
                <div className="flex justify-between gap-1">
                  <span className="text-slate-500">TP:</span>
                  <strong className="text-emerald-400">{actualTp ? actualTp.toFixed(3) : '—'}</strong>
                </div>
              </div>
            )}
          </Box>
        </div>
        
        {/* ARROW DOWN */}
        <div className="flex justify-center my-3 opacity-30">
          <ArrowDown size={16} className="text-slate-400" />
        </div>
        
{/* ROW 3: EXECUTION */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Box 
            title="🛡️ RISK CHECK" 
            active={isOrderSent || isExecutionBlocked || actualExecutionState === 'ORDER_SENT' || actualExecutionState === 'SAFE_MODE_MONITORING'}
            error={isExecutionBlocked}
          >
            {!isTriggered && !isRejectedBeforeTrigger ? (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            ) : isExecutionBlocked ? (
              <>
                <strong className="text-rose-400 block text-xs">🔴 BLOCKED</strong>
                <span className="text-rose-400/80 block text-[11px] mt-0.5">{actualExecutionState}</span>
              </>
            ) : actualExecutionState === 'SAFE_MODE_MONITORING' ? (
              <>
                <strong className="text-amber-400 block text-xs mt-1">🟡 SAFE MODE PASSED</strong>
                <div className="text-[11px] text-amber-300/80">Setup ត្រៀមរួចរាល់ — រង់ចាំ LIVE TRADING</div>
              </>
            ) : isOrderSent ? (
              <strong className="text-emerald-400 block text-xs mt-1">🟢 ជោគជ័យ</strong>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="📤 ORDER SENT" 
            active={isOrderSent}
          >
            {isOrderSent && !isPositionOpened ? (
              <strong className="text-yellow-400 block text-xs mt-1">🟡 កំពុងបញ្ជូនទៅ MT5</strong>
            ) : isPositionOpened ? (
              <strong className="text-emerald-400 block text-xs mt-1">🟢 បានបញ្ជូនជោគជ័យ</strong>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
          <Box 
            title="💹 POSITION OPENED" 
            active={isPositionOpened} 
          >
            {isPositionOpened ? (
              <strong className="text-emerald-400 block text-xs mt-1">🟢 បានចូល MT5 ជោគជ័យ</strong>
            ) : (
              <>
                <div>WAITING</div>
                <div className="text-[11px] text-slate-400">កំពុងរង់ចាំ</div>
              </>
            )}
          </Box>
        </div>
        
      </div>
    </div>
  );
};
