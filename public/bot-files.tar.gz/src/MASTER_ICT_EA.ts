import { ICTMarketData, Candle } from './ICT_MarketAdapter';
export type { ICTMarketData, Candle };
import { INewsProvider } from './ICT_NewsAdapter';
import { IMT5ExecutionAdapter, MockMT5Execution } from './ICT_MT5_Integration';

export interface EAConfig {
    symbol: string;
    isRealAccount: boolean;
    isUSCAccount: boolean;
    lotSize: number;
    dailyLossLimit: number;
    maxConsecutiveSL: number;
    cooldownMinutes: number;
    maxOpenTrades: number;
    tradingSessionStart: string;
    tradingSessionEnd: string;
    newsFilterEnabled: boolean;
    minutesBeforeNewsBlock: number;
    minutesAfterNewsBlock: number;
    
    // Configurable Deterministic Order Block Parameters
    obLookbackCandles: number; // e.g. 15 candles dynamic scanning
    obMinDisplacementBodyRatio: number; // e.g., 0.6 (60% of candle range must be body)
    obMinDisplacementMultiplier: number; // e.g., 1.5x larger than average recent body
    obRecentCandlesForAverage: number; // e.g., 3 candles
    
    // Risk Management Overrides
    minSLPoints: number; // Minimum SL distance
    minTPPoints: number; // Minimum TP distance
    minRR: number; // Minimum Risk:Reward Ratio
    
    // Trailing Stop Settings
    trailingStopEnabled: boolean;
    trailingStopActivationPoints: number; // Activation distance (profit) in XAUUSD points
    trailingStopDistancePoints: number; // How far to trail behind current price in XAUUSD points

}

export type SetupStage = 'SEARCHING' | 'WAITING' | 'TRIGGERED' | 'INVALIDATED';
export type SetupBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export interface ICTSetup {
    id: string;
    stage: SetupStage;
    bias: SetupBias;
    
    h4BiasConfirmed: boolean;
    m15LiquiditySwept: boolean;
    m15CISDConfirmed: boolean;
    m1DisplacementConfirmed: boolean;
    m1OBConfirmed: boolean;
    m1FVGConfirmed: boolean;
    retracementConfirmed: boolean;
    
    obHigh: number;
    obLow: number;
    fvgHigh: number;
    fvgLow: number;

    // Structural SL & Locked TP Target
    structuralInvalidationLow?: number;
    structuralInvalidationHigh?: number;
    lockedSlTarget?: number;
    lockedTpTarget?: number;
    
    // Proportional Missed-Entry / Near-TP Protection Tracking
    highestPriceSinceSetup?: number;
    lowestPriceSinceSetup?: number;
    
    // True Event-Order Tracking
    firstTouch?: 'NONE' | 'ENTRY' | 'TP' | 'UNKNOWN';
    firstTouchPrice?: number;
    firstTouchTimestamp?: number;
    entryTouchedTimestamp?: number;
    tpTouchedTimestamp?: number;
    
    isStale?: boolean;

    creationTime: number;
    expirationTime: number;
    executionState?: string;
    actualEntryPrice?: number;
    entryAlertSent?: boolean;
    confirmationAlertSent?: boolean;
}

export interface EAPosition {
    ticket: string;
    symbol: string;
    type: 'BUY' | 'SELL';
    lot: number;
    openPrice: number;
    sl: number;
    tp: number;
    magic: number;
    setupId: string;
}

export interface ICTTelemetry {
    lastAnalysisTime: number;
    status: 'ANALYZING' | 'WAITING' | 'READY' | 'ERROR';
    symbol: string;
    livePrice: {
        bid: number;
        ask: number;
        spread: number;
    };
    h4: {
        bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
        structure: 'CONFIRMED' | 'WAITING';
        lastCandleTime?: string;
        candleCount: number;
        open?: number;
        high?: number;
        low?: number;
        close?: number;
    };
    m15: {
        liquiditySweep: 'FOUND' | 'NOT FOUND' | 'WAITING';
        cisd: 'CONFIRMED' | 'WAITING';
        swingHigh: number;
        swingLow: number;
        targetHigh: number;
        targetLow: number;
        candleCount: number;
        lastCandleTime?: string;
    };
    m1: {
        displacement: 'FOUND' | 'WAITING';
        orderBlock: 'FOUND' | 'WAITING';
        fvg: 'FOUND' | 'WAITING';
        retracement: 'FOUND' | 'WAITING';
        obZone: { high: number; low: number } | null;
        fvgZone: { high: number; low: number } | null;
        candleCount: number;
        lastCandleTime?: string;
    };
    entryStatus: 'SEARCHING' | 'WAITING' | 'VALID SETUP' | 'READY TO EXECUTE' | 'TRADE OPENED';
    waitingReason: string;
    latency?: {
        mt5TickTime: string;
        backendReceiveTime: string;
        ictAnalysisTime: string;
        lastTickAgeSeconds: number;
        latencyMs: number;
    };
    validSetup: {
        direction: 'BUY' | 'SELL';
        entry: number;
        actualEntry?: number;
        sl: number;
        tp: number;
        rr: number;
        setupId: string;
        stage: string;
        executionState?: string;
        obHigh: number;
        obLow: number;
    } | null;
    systemHealth: {
        mt5Connection: boolean;
        eaBridge: boolean;
        vps: boolean;
        liveMarketData: boolean;
        dataFreshness: boolean;
        newsFilter: boolean;
        riskGuard: boolean;
        problemReason?: string;
    };
    recentLogs: Array<{
        timestamp: string;
        message: string;
        level: 'info' | 'warn' | 'success' | 'error';
    }>;
}

export class IctXauusdEA {
    public config: EAConfig;
    private newsProvider: INewsProvider | null;
    private execution: IMT5ExecutionAdapter;
    public logs: string[] = [];
    public lastM1Candles: Candle[] = [];
    public onActualEntryTriggered?: (data: {
        setupId?: string;
        symbol: string;
        direction: 'BUY' | 'SELL';
        entry: number;
        sl?: number;
        tp?: number;
        rr?: number;
        status: string;
    }) => void;
    public onExecutionFailed?: (data: {
        setupId: string;
        reason: string;
    }) => void;
    public onSetupConfirmed?: (data: {
        symbol: string;
        direction: 'BUY' | 'SELL';
        entryZone: { low: number; high: number };
        actualEntry: number;
        sl: number;
        tp: number;
        rr: number;
        status: string;
    }) => void;
    
    public state = {
        currentSetup: null as ICTSetup | null,
        executedSetupIds: new Set<string>(),
        dailyLoss: 0,
        consecutiveSLs: 0,
        lastSLTime: 0,
        openPositions: [] as EAPosition[]
    };

    public telemetry: ICTTelemetry = {
        lastAnalysisTime: Date.now(),
        status: 'WAITING',
        symbol: 'XAUUSDc',
        livePrice: { bid: 0, ask: 0, spread: 0 },
        h4: { bias: 'NEUTRAL', structure: 'WAITING', candleCount: 0 },
        m15: { liquiditySweep: 'WAITING', cisd: 'WAITING', swingHigh: 0, swingLow: 0, targetHigh: 0, targetLow: 0, candleCount: 0 },
        m1: { displacement: 'WAITING', orderBlock: 'WAITING', fvg: 'WAITING', retracement: 'WAITING', obZone: null, fvgZone: null, candleCount: 0 },
        entryStatus: 'WAITING',
        waitingReason: '⏳ WAITING FOR M15 LIQUIDITY SWEEP',
        validSetup: null,
        systemHealth: {
            mt5Connection: true,
            eaBridge: true,
            vps: true,
            liveMarketData: true,
            dataFreshness: true,
            newsFilter: true,
            riskGuard: true
        },
        recentLogs: []
    };

    constructor(config: EAConfig, newsProvider: INewsProvider | null, execution?: IMT5ExecutionAdapter) {
        this.config = config;
        this.newsProvider = newsProvider;
        this.execution = execution || new MockMT5Execution();
        this.addAnalysisLog('NEW ICT EA Initialized in Live Monitoring Mode', 'info');
    }

    public addAnalysisLog(message: string, level: 'info' | 'warn' | 'success' | 'error' = 'info') {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-GB', { hour12: false });
        this.telemetry.recentLogs.unshift({
            timestamp: `[${timeStr}]`,
            message,
            level
        });
        if (this.telemetry.recentLogs.length > 200) {
            this.telemetry.recentLogs.pop();
        }
    }

    public getTelemetry(botState?: any): ICTTelemetry {
        if (botState) {
            const priceAgeMs = Date.now() - (botState.lastTickTime || 0);
            const isFresh = priceAgeMs < 65000;
            const isMarketLive = Boolean(botState.marketDataStatus?.includes('LIVE'));
            const isMt5Connected = Boolean(botState.account?.isConnected);
            const isEaBridgeConnected = Boolean(botState.account?.eaConnected);
            const isVpsOnline = Boolean(botState.account?.vpsOnline);
            const isNewsOk = botState.newsProviderStatus !== 'UNAVAILABLE';
            const isRiskOk = !botState.dailyLossLimitHit && (botState.consecutiveLosses || 0) < 3;

            let problemReason = '';
            if (!isMt5Connected) problemReason = 'MT5 Server Disconnected';
            else if (!isMarketLive) problemReason = 'Market Data Feed Offline';
            else if (!isFresh) problemReason = `Price Feed Stale (${Math.round(priceAgeMs / 1000)}s delay)`;
            else if (!isRiskOk) problemReason = 'Daily Loss Limit or Consecutive Loss Exceeded';

            this.telemetry.systemHealth = {
                mt5Connection: isMt5Connected,
                eaBridge: isEaBridgeConnected,
                vps: isVpsOnline,
                liveMarketData: isMarketLive,
                dataFreshness: isFresh,
                newsFilter: isNewsOk,
                riskGuard: isRiskOk,
                problemReason: problemReason || undefined
            };

            if (problemReason) {
                if (problemReason.includes('Stale') || problemReason.includes('Offline')) {
                    this.telemetry.status = 'WAITING';
                    this.telemetry.waitingReason = '⏳ ' + problemReason;
                } else {
                    this.telemetry.status = 'ERROR';
                    this.telemetry.waitingReason = '🔴 ' + problemReason;
                }
            } else if (this.state.currentSetup?.stage === 'TRIGGERED') {
                this.telemetry.status = 'READY';
            } else {
                this.telemetry.status = 'WAITING';
            }

            const serverTime = botState.lastTickTime || Date.now();
            const now = Date.now();
            const tickAge = Math.max(0, (now - (botState.lastTickTime || serverTime)) / 1000);
            const pingMs = Number(botState.account?.pingMs || 15);

            this.telemetry.latency = {
                mt5TickTime: new Date(serverTime).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                backendReceiveTime: new Date(botState.lastTickTime || now).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                ictAnalysisTime: new Date(this.telemetry.lastAnalysisTime || now).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                lastTickAgeSeconds: Number(tickAge.toFixed(1)),
                latencyMs: pingMs
            };
        }
        return this.telemetry;
    }

    private log(msg: string) {
        this.logs.push(`[ICT EA] ${msg}`);
    }

    public start() {
        this.log("EA Started in SAFE MOCK MODE (REAL DATA = ALLOWED, REAL EXECUTION = DISABLED).");
    }

    public async onTick(data: ICTMarketData) {
        this.lastM1Candles = data.m1Candles;
        this.telemetry.lastAnalysisTime = Date.now();
        this.telemetry.symbol = data.symbol || this.config.symbol;
        this.telemetry.livePrice = {
            bid: data.bid,
            ask: data.ask,
            spread: Number(data.spread.toFixed(1))
        };

        if (!data || !data.symbol || (!data.symbol.startsWith('XAUUSD') && data.symbol !== 'GOLD')) {
            this.log("BLOCKED: INVALID MT5 DATA");
            this.telemetry.status = 'ERROR';
            this.telemetry.waitingReason = '🔴 BLOCKED: INVALID MT5 DATA';
            return;
        }

        const now = data.serverTime;

        // Strict Real-Time Data Freshness Guard (Threshold: 5000ms)
        const tickLatency = Date.now() - now;
        if (tickLatency > 5000) {
            this.log(`BLOCKED: STALE DATA (TICK DELAY > 5000ms: ${tickLatency}ms)`);
            this.telemetry.status = 'ERROR';
            this.telemetry.waitingReason = `🔴 BLOCKED: STALE DATA (TICK DELAY > 5000ms: ${tickLatency}ms)`;
            return;
        }

        // Strict Candle Data Freshness Guard: latest M1 candle must be within 3 minutes (180,000ms)
        if (data.m1Candles && data.m1Candles.length > 0) {
            const latestM1 = data.m1Candles[data.m1Candles.length - 1];
            if (latestM1 && (now - latestM1.time > 180000)) {
                this.log(`BLOCKED: STALE M1 CANDLE DATA (CANDLE AGE: ${Math.round((now - latestM1.time) / 1000)}s)`);
                this.telemetry.status = 'ERROR';
                this.telemetry.waitingReason = `🔴 BLOCKED: STALE M1 CANDLE (AGE: ${Math.round((now - latestM1.time) / 1000)}s)`;
                return;
            }
        }

        if (this.state.dailyLoss >= this.config.dailyLossLimit) {
            this.log(`BLOCKED: Daily Loss Limit Reached (${this.state.dailyLoss})`);
            this.telemetry.waitingReason = `🔴 BLOCKED: Daily Loss Limit Reached (${this.state.dailyLoss})`;
            return;
        }

        const openPos = await this.execution.getOpenPositions(999);
        this.state.openPositions = openPos;

        if (this.state.consecutiveSLs >= this.config.maxConsecutiveSL) {
            if (now - this.state.lastSLTime < (this.config.cooldownMinutes * 60000)) {
                this.log("BLOCKED: COOLDOWN PERIOD ACTIVE");
                this.telemetry.waitingReason = "⏳ COOLDOWN PERIOD ACTIVE AFTER CONSECUTIVE SL";
                return;
            } else {
                this.state.consecutiveSLs = 0;
            }
        }

        if (this.config.newsFilterEnabled) {
            if (!this.newsProvider) {
                this.log("BLOCKED: NEWS DATA UNAVAILABLE");
                return;
            }
            const upcoming = await this.newsProvider.getUpcomingHighImpactEvents(data.serverTime);
            if (upcoming === null) {
                this.log("BLOCKED: NEWS DATA UNAVAILABLE");
                return;
            }
            
            for (const event of upcoming) {
                if (event.impact === 'HIGH') {
                    const msBefore = this.config.minutesBeforeNewsBlock * 60 * 1000;
                    const msAfter = this.config.minutesAfterNewsBlock * 60 * 1000;
                    
                    const blockStart = event.time - msBefore;
                    const blockEnd = event.time + msAfter;
                    
                    if (now >= blockStart && now <= blockEnd) {
                        this.log(`NEWS BLOCK ACTIVE | HIGH IMPACT USD EVENT | EVENT: ${event.title || 'Unknown Event'} | TIME: ${new Date(event.time).toISOString()} | NEW ENTRY BLOCKED`);
                        this.telemetry.waitingReason = `⏳ NEWS BLOCK ACTIVE: ${event.title || 'High Impact Event'}`;
                        return;
                    }
                }
            }
        }

        // Setups stay active while waiting for retracement until an explicit ICT invalidation occurs.
        if (this.state.currentSetup && this.state.currentSetup.stage === 'WAITING') {
            this.validateRetracement(data);
        }

        if (!this.state.currentSetup || this.state.currentSetup.stage === 'INVALIDATED') {
            this.analyzeSequence(data);
        }

        if (this.state.currentSetup && this.state.currentSetup.stage === 'TRIGGERED') {
            const s = this.state.currentSetup;
            this.log(`\n========================================\n[EXECUTION DECISION]\nexecuteTrade() CALLED: YES\nREASON: Setup stage is TRIGGERED (Setup ID: ${s.id})\n========================================`);
            if (this.state.openPositions.length >= this.config.maxOpenTrades) {
                this.log(`\n[RISK CHECK]\nRESULT: BLOCK\nREASON: MAX OPEN TRADES REACHED (${this.state.openPositions.length}/${this.config.maxOpenTrades})`);
                this.log(`executeTrade() ABORTED: MAX OPEN TRADES REACHED`);
                this.telemetry.waitingReason = `🟢 MAX OPEN TRADES REACHED (${this.state.openPositions.length}/${this.config.maxOpenTrades})`;
                return;
            }
            this.log(`\n[RISK CHECK]\nRESULT: PASS\nREASON: Max open trades within limit (${this.state.openPositions.length}/${this.config.maxOpenTrades})`);
            await this.executeTrade(data);
        }

        if (this.state.currentSetup && this.telemetry.validSetup) {
            this.telemetry.validSetup.stage = this.state.currentSetup.stage;
            this.telemetry.validSetup.executionState = this.state.currentSetup.executionState;
        }
    }

    private analyzeSequence(data: ICTMarketData) {
        let bias: SetupBias = 'NEUTRAL';
        let lastH4Candle: Candle | null = null;
        if (data.h4Candles && data.h4Candles.length >= 3) {
            const last = data.h4Candles[data.h4Candles.length-1];
            lastH4Candle = last;
            bias = last.close > last.open ? 'BULLISH' : 'BEARISH';
            this.telemetry.h4 = {
                bias: bias,
                structure: 'CONFIRMED',
                lastCandleTime: new Date(last.time).toISOString(),
                candleCount: data.h4Candles.length,
                open: last.open,
                high: last.high,
                low: last.low,
                close: last.close
            };
        } else {
            this.telemetry.h4 = {
                bias: 'NEUTRAL',
                structure: 'WAITING',
                candleCount: data.h4Candles?.length || 0
            };
        }

        if (bias === 'NEUTRAL') {
            this.telemetry.waitingReason = '⏳ WAITING FOR H4 CANDLE DATA / BIAS';
            this.telemetry.entryStatus = 'SEARCHING';
            return;
        }

        let m15Swept = false;
        let m15CISD = false;
        let m15_1: Candle | null = null;
        let m15_3: Candle | null = null;

        if (data.m15Candles && data.m15Candles.length >= 3) {
            m15_1 = data.m15Candles[data.m15Candles.length-3];
            m15_3 = data.m15Candles[data.m15Candles.length-1];
            if (bias === 'BULLISH' && m15_3.low <= m15_1.low) { m15Swept = true; m15CISD = true; }
            if (bias === 'BEARISH' && m15_3.high >= m15_1.high) { m15Swept = true; m15CISD = true; }

            this.telemetry.m15 = {
                liquiditySweep: m15Swept ? 'FOUND' : 'NOT FOUND',
                cisd: m15CISD ? 'CONFIRMED' : 'WAITING',
                swingHigh: m15_1.high,
                swingLow: m15_1.low,
                targetHigh: m15_3.high,
                targetLow: m15_3.low,
                candleCount: data.m15Candles.length,
                lastCandleTime: new Date(m15_3.time).toISOString()
            };
        } else {
            this.telemetry.m15 = {
                liquiditySweep: 'WAITING',
                cisd: 'WAITING',
                swingHigh: 0,
                swingLow: 0,
                targetHigh: 0,
                targetLow: 0,
                candleCount: data.m15Candles?.length || 0
            };
        }

        if (!m15Swept || !m15CISD) {
            this.telemetry.m1 = {
                displacement: 'WAITING',
                orderBlock: 'WAITING',
                fvg: 'WAITING',
                retracement: 'WAITING',
                obZone: null,
                fvgZone: null,
                candleCount: data.m1Candles?.length || 0,
                lastCandleTime: data.m1Candles?.length ? new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString() : undefined
            };
            this.telemetry.entryStatus = 'WAITING';
            this.telemetry.waitingReason = '⏳ WAITING FOR M15 LIQUIDITY SWEEP';
            this.telemetry.validSetup = null;

            // Add concise cycle logs
            this.addAnalysisLog(`H4 Bias = ${bias} (Close: ${lastH4Candle?.close || 0} | Open: ${lastH4Candle?.open || 0})`, 'info');
            this.addAnalysisLog(`M15 Liquidity Sweep = NOT FOUND (Current: ${bias === 'BEARISH' ? m15_3?.high : m15_3?.low} vs Swing: ${bias === 'BEARISH' ? m15_1?.high : m15_1?.low})`, 'warn');
            this.addAnalysisLog(`M15 CISD = WAITING`, 'info');
            this.addAnalysisLog(`M1 = LOCKED (Awaiting M15 Sweep Confirmation)`, 'info');
            this.addAnalysisLog(`ENTRY = WAITING (⏳ WAITING FOR M15 LIQUIDITY SWEEP)`, 'info');
            return;
        }

        // M15 Swept & CISD Confirmed
        this.addAnalysisLog(`M15 Liquidity Sweep = FOUND (${bias === 'BEARISH' ? 'Buy-Side' : 'Sell-Side'} Liquidity Swept)`, 'success');
        this.addAnalysisLog(`M15 CISD = CONFIRMED`, 'success');

        const obData = this.detectDynamicOrderBlock(data.m1Candles, bias, data.symbol || this.config.symbol);
        if (!obData) {
            this.telemetry.m1 = {
                displacement: 'WAITING',
                orderBlock: 'WAITING',
                fvg: 'WAITING',
                retracement: 'WAITING',
                obZone: null,
                fvgZone: null,
                candleCount: data.m1Candles?.length || 0,
                lastCandleTime: data.m1Candles?.length ? new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString() : undefined
            };
            this.telemetry.entryStatus = 'SEARCHING';
            this.telemetry.waitingReason = '⏳ CISD CONFIRMED — WAITING FOR M1 DISPLACEMENT & OB/FVG';
            this.telemetry.validSetup = null;
            this.addAnalysisLog(`M1 Displacement & OB/FVG = WAITING`, 'warn');
            return;
        }

        // Setup Identity
        const setupId = `${this.config.symbol}-${bias}-M15Sweep-M1OB-${obData.originTime}`;
        
        if (this.state.executedSetupIds.has(setupId)) {
            return;
        }

        // Calculate setup metrics for monitor display (Structural Invalidation SL & Locked ICT Target TP)
        const structuralLow = Math.min(obData.obLow, obData.structuralOriginLow);
        const structuralHigh = Math.max(obData.obHigh, obData.structuralOriginHigh);
        const entryEst = bias === 'BULLISH' ? obData.obHigh : obData.obLow; // The target retracement entry price
        const slEst = bias === 'BULLISH' ? (structuralLow - 0.5) : (structuralHigh + 0.5);
        const tpEst = bias === 'BULLISH' ? obData.displacementPeak : obData.displacementValley;
        const riskEst = Math.abs(entryEst - slEst);
        const rewardEst = Math.abs(tpEst - entryEst);
        const rrEst = riskEst > 0 ? rewardEst / riskEst : 0;

        this.state.currentSetup = {
            id: setupId,
            stage: 'WAITING',
            bias: bias,
            h4BiasConfirmed: true,
            m15LiquiditySwept: true,
            m15CISDConfirmed: true,
            m1DisplacementConfirmed: true,
            m1OBConfirmed: true,
            m1FVGConfirmed: true,
            retracementConfirmed: false,
            obHigh: obData.obHigh,
            obLow: obData.obLow,
            fvgHigh: obData.fvgHigh,
            fvgLow: obData.fvgLow,
            structuralInvalidationLow: structuralLow,
            structuralInvalidationHigh: structuralHigh,
            lockedSlTarget: slEst,
            lockedTpTarget: tpEst,
            firstTouch: 'NONE',
            creationTime: data.serverTime,
            expirationTime: data.serverTime + 3600000,
            confirmationAlertSent: true
        };

        if (this.onSetupConfirmed) {
            if (rrEst >= this.config.minRR) {
                this.onSetupConfirmed({
                    symbol: data.symbol || this.config.symbol,
                    direction: bias === 'BULLISH' ? 'BUY' : 'SELL',
                    entryZone: { low: obData.obLow, high: obData.obHigh },
                    actualEntry: entryEst,
                    sl: slEst,
                    tp: tpEst,
                    rr: Number(rrEst.toFixed(2)),
                    status: '⏳ WAITING FOR ENTRY'
                });
            } else {
                this.addAnalysisLog(`Setup Confirmed Notification Blocked: RR ${rrEst.toFixed(2)} < ${this.config.minRR}`, 'warn');
            }
        }

        this.telemetry.m1 = {
            displacement: 'FOUND',
            orderBlock: 'FOUND',
            fvg: 'FOUND',
            retracement: 'WAITING',
            obZone: { high: obData.obHigh, low: obData.obLow },
            fvgZone: { high: obData.fvgHigh, low: obData.fvgLow },
            candleCount: data.m1Candles.length,
            lastCandleTime: new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString()
        };
        this.telemetry.entryStatus = 'VALID SETUP';
        this.telemetry.waitingReason = '⏳ M1 OB FOUND — WAITING FOR RETRACEMENT';

        this.telemetry.validSetup = {
            direction: bias === 'BULLISH' ? 'BUY' : 'SELL',
            entry: entryEst,
            actualEntry: entryEst,
            sl: slEst,
            tp: tpEst,
            rr: Number(rrEst.toFixed(2)),
            setupId: setupId,
            stage: 'WAITING',
            executionState: undefined,
            obHigh: obData.obHigh,
            obLow: obData.obLow
        };
        
        this.log(`SEQUENCE COMPLETE: Valid ${bias} OB+FVG found. OB Zone: [${obData.obLow} - ${obData.obHigh}] | Structural SL: ${slEst} | Locked TP: ${tpEst} (RR: ${rrEst.toFixed(2)}). Stage -> WAITING`);
        this.log(`SETUP ID: ${setupId}`);
        this.log(`FVG FOUND | High: ${obData.fvgHigh} | Low: ${obData.fvgLow} | Direction: ${bias}`);

        this.addAnalysisLog(`M1 Order Block = FOUND [${obData.obLow} - ${obData.obHigh}]`, 'success');
        this.addAnalysisLog(`M1 FVG = FOUND [${obData.fvgLow} - ${obData.fvgHigh}]`, 'success');
        this.addAnalysisLog(`Structural SL = ${slEst} | Locked ICT TP = ${tpEst} (RR: ${rrEst.toFixed(2)})`, 'info');
        this.addAnalysisLog(`ENTRY = VALID SETUP (⏳ WAITING FOR RETRACEMENT)`, 'success');
    }

    private detectDynamicOrderBlock(m1: Candle[], bias: SetupBias, symbol: string) {
        if (!m1 || m1.length < this.config.obLookbackCandles) return null;
        
        const N = m1.length;
        const startIndex = Math.max(0, N - this.config.obLookbackCandles);
        const avgCandles = this.config.obRecentCandlesForAverage;

        for (let i = startIndex; i < N - 2; i++) {
            const obCandle = m1[i];
            
            // SKIP OBs that have already been executed, invalidated, or cancelled
            const potentialSetupId = `${symbol}-${bias}-M15Sweep-M1OB-${obCandle.time}`;
            if (this.state.executedSetupIds.has(potentialSetupId)) {
                continue;
            }
            
            if (bias === 'BULLISH' && obCandle.close >= obCandle.open) continue; // Must be bearish origin
            if (bias === 'BEARISH' && obCandle.close <= obCandle.open) continue; // Must be bullish origin

            // Scan forward for displacement
            for (let j = i + 1; j < N - 1; j++) {
                const dispCandle = m1[j];
                
                // Average Body before displacement
                let totalBody = 0;
                let count = 0;
                for (let a = Math.max(0, j - avgCandles); a < j; a++) {
                    totalBody += Math.abs(m1[a].close - m1[a].open);
                    count++;
                }
                const avgBody = count > 0 ? totalBody / count : 0.1;

                const dispBody = Math.abs(dispCandle.close - dispCandle.open);
                const dispRange = dispCandle.high - dispCandle.low;
                const dispRatio = dispRange === 0 ? 0 : dispBody / dispRange;

                const hasStrongRatio = dispRatio >= this.config.obMinDisplacementBodyRatio;
                const hasRelativeStr = dispBody >= (avgBody * this.config.obMinDisplacementMultiplier);

                if (bias === 'BULLISH') {
                    if (dispCandle.close < dispCandle.open) continue;
                    if (!hasStrongRatio || !hasRelativeStr) continue;
                    if (dispCandle.close <= obCandle.high) continue; // Break structure

                    // FVG is gap between j-1 high and j+1 low
                    const leftC = m1[j-1];
                    const rightC = m1[j+1];
                    if (rightC.low > leftC.high) {
                        // VERIFY OB IS NOT ALREADY BROKEN BY SUBSEQUENT CANDLES
                        let isBroken = false;
                        for (let k = j + 2; k < N; k++) {
                            if (m1[k].low < obCandle.low) {
                                isBroken = true;
                                break;
                            }
                        }
                        if (!isBroken) {
                            const structuralOriginLow = Math.min(...m1.slice(i, j + 2).map(c => c.low));
                            const displacementPeak = Math.max(...m1.slice(i, N).map(c => c.high));
                            return {
                                obHigh: obCandle.high,
                                obLow: obCandle.low,
                                fvgHigh: rightC.low,
                                fvgLow: leftC.high,
                                originTime: obCandle.time,
                                structuralOriginLow,
                                displacementPeak
                            };
                        }
                    }
                } 
                else if (bias === 'BEARISH') {
                    if (dispCandle.close > dispCandle.open) continue;
                    if (!hasStrongRatio || !hasRelativeStr) continue;
                    if (dispCandle.close >= obCandle.low) continue; // Break structure

                    const leftC = m1[j-1];
                    const rightC = m1[j+1];
                    if (leftC.low > rightC.high) {
                        // VERIFY OB IS NOT ALREADY BROKEN BY SUBSEQUENT CANDLES
                        let isBroken = false;
                        for (let k = j + 2; k < N; k++) {
                            if (m1[k].high > obCandle.high) {
                                isBroken = true;
                                break;
                            }
                        }
                        if (!isBroken) {
                            const structuralOriginHigh = Math.max(...m1.slice(i, j + 2).map(c => c.high));
                            const displacementValley = Math.min(...m1.slice(i, N).map(c => c.low));
                            return {
                                obHigh: obCandle.high,
                                obLow: obCandle.low,
                                fvgHigh: leftC.low,
                                fvgLow: rightC.high,
                                originTime: obCandle.time,
                                structuralOriginHigh,
                                displacementValley
                            };
                        }
                    }
                }
            }
        }
        return null;
    }

    private validateRetracement(data: ICTMarketData) {
        const s = this.state.currentSetup!;
        
        const latestM1 = data.m1Candles && data.m1Candles.length > 0 ? data.m1Candles[data.m1Candles.length - 1] : null;
        const spread = data.ask - data.bid;
        const latestM1AskHigh = latestM1 ? latestM1.high + spread : data.ask;

        const isBullishInvalidated = s.bias === 'BULLISH' && (data.bid < (s.obLow - 0.1) || (latestM1 && latestM1.low < (s.obLow - 0.1)));
        const isBearishInvalidated = s.bias === 'BEARISH' && (data.ask > (s.obHigh + 0.1) || (latestM1 && latestM1AskHigh > (s.obHigh + 0.1)));

        if (isBullishInvalidated) {
            this.log(`=== RETRACEMENT DIAGNOSTIC (BULLISH) ===`);
            this.log(`Setup ID: ${s.id}`);
            this.log(`Direction: ${s.bias}`);
            this.log(`OB High: ${s.obHigh}`);
            this.log(`OB Low: ${s.obLow}`);
            this.log(`Current Ask: ${data.ask}`);
            this.log(`Current Bid: ${data.bid}`);
            this.log(`Condition: data.bid < (s.obLow - 0.1) (${data.bid} < ${(s.obLow - 0.1).toFixed(3)}) => TRUE`);
            this.log(`========================================`);
            this.log(`INVALID OB/SETUP: Price broke below Bullish OB Low (${s.obLow}). Stage -> INVALIDATED`);
            this.addAnalysisLog(`Setup ${s.id} បានបរាជ័យ (Price broke below OB Low ${s.obLow} - Bid was ${data.bid}) -> INVALIDATED`, 'warn');
            s.executionState = 'REJECTED: PRICE_BROKE_OB';
            s.stage = 'INVALIDATED';
            this.state.executedSetupIds.add(s.id);
            return;
        }

        if (isBearishInvalidated) {
            this.log(`=== RETRACEMENT DIAGNOSTIC (BEARISH) ===`);
            this.log(`Setup ID: ${s.id}`);
            this.log(`Direction: ${s.bias}`);
            this.log(`OB High: ${s.obHigh}`);
            this.log(`OB Low: ${s.obLow}`);
            this.log(`Current Ask: ${data.ask}`);
            this.log(`Current Bid: ${data.bid}`);
            this.log(`Condition: data.ask > (s.obHigh + 0.1) (${data.ask} > ${(s.obHigh + 0.1).toFixed(3)}) => TRUE`);
            this.log(`========================================`);
            this.log(`INVALID OB/SETUP: Price broke above Bearish OB High (${s.obHigh}). Stage -> INVALIDATED`);
            this.addAnalysisLog(`Setup ${s.id} បានបរាជ័យ (Price broke above OB High ${s.obHigh} - Ask was ${data.ask}) -> INVALIDATED`, 'warn');
            s.executionState = 'REJECTED: PRICE_BROKE_OB';
            s.stage = 'INVALIDATED';
            this.state.executedSetupIds.add(s.id);
            return;
        }

        // =========================================================================
        // PRE-ENTRY SETUP CANCELLATION ENGINE - TRUE EVENT-ORDER TRACKING
        // =========================================================================
        const lockedEntry = s.actualEntryPrice || (s.bias === 'BULLISH' ? s.obHigh : s.obLow);
        const lockedTp = s.lockedTpTarget !== undefined ? s.lockedTpTarget : (s.bias === 'BULLISH' ? Math.max(...(data.m1Candles || []).slice(-20).map(c=>c.high)) : Math.min(...(data.m1Candles || []).slice(-20).map(c=>c.low)));
        
        if (lockedTp !== undefined && lockedTp !== null && lockedEntry !== undefined && lockedEntry !== null) {
            let entryTouched = false;
            let tpTouched = false;
            if (s.bias === 'BULLISH') {
                entryTouched = data.ask <= lockedEntry || (latestM1 && (latestM1.low + spread) <= lockedEntry) ? true : false;
                tpTouched = Math.max(data.bid, data.ask) >= lockedTp || (latestM1 && latestM1.high >= lockedTp) ? true : false;
            } else {
                entryTouched = data.bid >= lockedEntry || (latestM1 && latestM1.high >= lockedEntry) ? true : false;
                tpTouched = Math.min(data.bid, data.ask) <= lockedTp || (latestM1 && latestM1.low <= lockedTp) ? true : false;
            }

            if (s.firstTouch === 'NONE' || !s.firstTouch || s.firstTouch === 'UNKNOWN') {
                if (entryTouched && tpTouched) {
                    s.firstTouch = 'UNKNOWN';
                    s.firstTouchTimestamp = data.serverTime;
                    this.log(`\n========================================`);
                    this.log(`[SETUP EVENT ORDER]`);
                    this.log(`Setup ID: ${s.id}`);
                    this.log(`Direction: ${s.bias === 'BULLISH' ? 'BUY' : 'SELL'}`);
                    this.log(`Entry: ${lockedEntry.toFixed(3)} | Locked TP: ${lockedTp.toFixed(3)}`);
                    this.log(`Live BID: ${data.bid.toFixed(3)} | Live ASK: ${data.ask.toFixed(3)}`);
                    this.log(`Entry Touched: YES | TP Touched: YES`);
                    this.log(`First Touch: UNKNOWN (Ambiguous tick)`);
                    this.log(`Decision: KEEP_WAITING`);
                    this.log(`🟡 TOUCH_ORDER_UNKNOWN — SETUP PRESERVED`);
                    this.log(`========================================`);
                    return;
                } else if (tpTouched) {
                    s.firstTouch = 'TP';
                    s.firstTouchPrice = s.bias === 'BULLISH' ? data.bid : data.ask;
                    s.tpTouchedTimestamp = data.serverTime;
                    s.firstTouchTimestamp = data.serverTime;
                    
                    this.log(`\n========================================`);
                    this.log(`[SETUP EVENT ORDER]`);
                    this.log(`Setup ID: ${s.id}`);
                    this.log(`Direction: ${s.bias === 'BULLISH' ? 'BUY' : 'SELL'}`);
                    this.log(`Entry: ${lockedEntry.toFixed(3)} | Locked TP: ${lockedTp.toFixed(3)}`);
                    this.log(`Live BID: ${data.bid.toFixed(3)} | Live ASK: ${data.ask.toFixed(3)}`);
                    this.log(`Entry Touched: NO | TP Touched: YES`);
                    this.log(`TP Timestamp: ${data.serverTime}`);
                    this.log(`First Touch: TP`);
                    this.log(`Decision: CANCEL PERMANENTLY`);
                    this.log(`🔴 TP_REACHED_BEFORE_ENTRY`);
                    this.log(`========================================`);
                    this.addAnalysisLog(`⚠️ Setup ${s.id} ត្រូវបានលុបចោលភ្លាមៗ (TP REACHED BEFORE ENTRY): តម្លៃបានដល់ TP ${lockedTp} មុនពេលប៉ះ Entry -> Old Entry ${lockedEntry} ត្រូវបានបិទជាអចិន្ត្រៃយ៍`, 'warn');
                    s.isStale = true;
                    s.stage = 'INVALIDATED';
                    s.executionState = 'REJECTED: TP_REACHED_BEFORE_ENTRY';
                    this.state.executedSetupIds.add(s.id);
                    
                    if (this.telemetry.validSetup) {
                        this.telemetry.validSetup.stage = 'INVALIDATED';
                        this.telemetry.validSetup.executionState = 'REJECTED: TP_REACHED_BEFORE_ENTRY';
                    }
                    this.telemetry.waitingReason = `⚠️ OLD SETUP CANCELLED (TP reached before Entry) — Waiting for NEW ICT Setup`;
                    return;
                } else if (entryTouched) {
                    s.firstTouch = 'ENTRY';
                    s.firstTouchPrice = s.bias === 'BULLISH' ? data.ask : data.bid;
                    s.entryTouchedTimestamp = data.serverTime;
                    s.firstTouchTimestamp = data.serverTime;
                    this.log(`\n========================================`);
                    this.log(`[SETUP EVENT ORDER]`);
                    this.log(`Setup ID: ${s.id}`);
                    this.log(`Direction: ${s.bias === 'BULLISH' ? 'BUY' : 'SELL'}`);
                    this.log(`Entry: ${lockedEntry.toFixed(3)} | Locked TP: ${lockedTp.toFixed(3)}`);
                    this.log(`Live BID: ${data.bid.toFixed(3)} | Live ASK: ${data.ask.toFixed(3)}`);
                    this.log(`Entry Touched: YES | TP Touched: NO`);
                    this.log(`Entry Timestamp: ${data.serverTime}`);
                    this.log(`First Touch: ENTRY`);
                    this.log(`Decision: EXECUTE`);
                    this.log(`🟢 ENTRY_REACHED_BEFORE_TP`);
                    this.log(`========================================`);
                }
            } else if (s.firstTouch === 'TP') {
                return;
            }
        }

        let triggerBullish = s.bias === 'BULLISH' && data.ask <= s.obHigh && data.ask >= s.obLow;
        if (s.bias === 'BULLISH' && !triggerBullish && latestM1 && (latestM1.low + spread) <= s.obHigh && (latestM1.low + spread) >= s.obLow) {
            triggerBullish = true;
            data.ask = latestM1.low + spread; 
        }

        let triggerBearish = s.bias === 'BEARISH' && data.bid >= s.obLow && data.bid <= s.obHigh;
        if (s.bias === 'BEARISH' && !triggerBearish && latestM1 && latestM1.high >= s.obLow && latestM1.high <= s.obHigh) {
            triggerBearish = true;
            data.bid = latestM1.high;
        }

        if (triggerBullish) {
            const t0 = new Date().toISOString();
            this.log(`\n========================================\n[ENTRY TRIGGER]\n[${t0}] SIGNAL CREATED\nSetup ID: ${s.id}\nDirection: BUY\nEntry: ${data.ask}\nCurrent Price: ${data.ask}\nOB Zone: [${s.obLow} - ${s.obHigh}]\n========================================`);
            this.log("WAITING FOR RETRACEMENT fulfilled. M1 Retracement into valid OB confirmed.");
            this.addAnalysisLog(`M1 Retracement បានចូលក្នុងតំបន់ OB [${s.obLow} - ${s.obHigh}] ជោគជ័យ -> TRIGGERED`, 'success');
            
            s.actualEntryPrice = data.ask;
            s.lockedSlTarget = s.lockedSlTarget || (s.obLow - 0.5);
            s.lockedTpTarget = s.lockedTpTarget || Math.max(...(data.m1Candles||[]).slice(-20).map(c=>c.high));
            s.retracementConfirmed = true;
            s.stage = 'TRIGGERED';
            
            if (this.telemetry.validSetup) {
                this.telemetry.validSetup.stage = 'TRIGGERED';
                this.telemetry.validSetup.actualEntry = s.actualEntryPrice;
                this.telemetry.validSetup.sl = s.lockedSlTarget;
                this.telemetry.validSetup.tp = s.lockedTpTarget;
                const risk = Math.abs(s.actualEntryPrice - s.lockedSlTarget);
                const reward = Math.abs(s.lockedTpTarget - s.actualEntryPrice);
                this.telemetry.validSetup.rr = risk > 0 ? Number((reward / risk).toFixed(2)) : 0;
            }
            if (this.onActualEntryTriggered && !s.entryAlertSent) {
                s.entryAlertSent = true;
                this.onActualEntryTriggered({
                    setupId: s.id,
                    symbol: data.symbol || this.config.symbol,
                    direction: 'BUY',
                    entry: s.actualEntryPrice,
                    sl: s.lockedSlTarget,
                    tp: s.lockedTpTarget,
                    rr: this.telemetry.validSetup?.rr,
                    status: 'ENTRY TRIGGERED'
                });
            }
        }
        else if (triggerBearish) {
            const t0 = new Date().toISOString();
            this.log(`\n========================================\n[ENTRY TRIGGER]\n[${t0}] SIGNAL CREATED\nSetup ID: ${s.id}\nDirection: SELL\nEntry: ${data.bid}\nCurrent Price: ${data.bid}\nOB Zone: [${s.obLow} - ${s.obHigh}]\n========================================`);
            this.log("WAITING FOR RETRACEMENT fulfilled. M1 Retracement into valid OB confirmed.");
            this.addAnalysisLog(`M1 Retracement បានចូលក្នុងតំបន់ OB [${s.obLow} - ${s.obHigh}] ជោគជ័យ -> TRIGGERED`, 'success');
            
            s.actualEntryPrice = data.bid;
            s.lockedSlTarget = s.lockedSlTarget || (s.obHigh + 0.5);
            s.lockedTpTarget = s.lockedTpTarget || Math.min(...(data.m1Candles||[]).slice(-20).map(c=>c.low));
            s.retracementConfirmed = true;
            s.stage = 'TRIGGERED';
            
            if (this.telemetry.validSetup) {
                this.telemetry.validSetup.stage = 'TRIGGERED';
                this.telemetry.validSetup.actualEntry = s.actualEntryPrice;
                this.telemetry.validSetup.sl = s.lockedSlTarget;
                this.telemetry.validSetup.tp = s.lockedTpTarget;
                const risk = Math.abs(s.lockedSlTarget - s.actualEntryPrice);
                const reward = Math.abs(s.actualEntryPrice - s.lockedTpTarget);
                this.telemetry.validSetup.rr = risk > 0 ? Number((reward / risk).toFixed(2)) : 0;
            }
            if (this.onActualEntryTriggered && !s.entryAlertSent) {
                s.entryAlertSent = true;
                this.onActualEntryTriggered({
                    setupId: s.id,
                    symbol: data.symbol || this.config.symbol,
                    direction: 'SELL',
                    entry: s.actualEntryPrice,
                    sl: s.lockedSlTarget,
                    tp: s.lockedTpTarget,
                    rr: this.telemetry.validSetup?.rr,
                    status: 'ENTRY TRIGGERED'
                });
            }
        }
        else {
            this.telemetry.entryStatus = 'VALID SETUP';
            this.telemetry.waitingReason = `⏳ SETUP VALID — កំពុងរង់ចាំ RETRACEMENT ចូលតំបន់ OB [${s.obLow} - ${s.obHigh}]`;
            
            const currentPrice = s.bias === 'BULLISH' ? data.ask : data.bid;
            const dist = s.bias === 'BULLISH' ? (currentPrice - s.obHigh) : (s.obLow - currentPrice);
            const distStr = dist > 0 ? ` (នៅឆ្ងាយ ${dist.toFixed(1)} Pts ពី OB)` : '';
            this.addAnalysisLog(`🟢 EA កំពុងធ្វើការ | ⏳ Setup រកឃើញ | ⏳ កំពុងរង់ចាំ Retracement${distStr} | 🔄 Analysis កំពុងបន្ត`, 'info');
        }
    }
    public LIVE_TRADING_ENABLED = false;

    private async executeTrade(data: ICTMarketData) {
        const s = this.state.currentSetup!;
        
        if (this.state.executedSetupIds.has(s.id)) {
            this.log("REJECT: Duplicate Setup ID execution prevented.");
            s.executionState = 'REJECTED: DUPLICATE_SETUP';
            s.stage = 'INVALIDATED';
            this.state.executedSetupIds.add(s.id);
            return;
        }
        
        // Restart Recovery: Check if there's already an open position with this setup ID
        if (this.state.openPositions.some(p => p.setupId === s.id)) {
            this.log("REJECT: Position for this setup already exists (survived restart).");
            this.state.executedSetupIds.add(s.id); // Re-sync
            s.executionState = 'REJECTED: POSITION_EXISTS';
            s.stage = 'INVALIDATED';
            this.state.executedSetupIds.add(s.id);
            return;
        }

        let sl = 0;
        let tp = 0;
        let entry = 0;

        if (s.bias === 'BULLISH') {
            entry = s.actualEntryPrice!;
            sl = s.lockedSlTarget!; 
            tp = s.lockedTpTarget!;
            
            const risk = entry - sl;
            const reward = tp - entry;
            const rr = risk > 0 ? reward / risk : 0;

            this.log(`\n[RR CHECK]\nEntry: ${entry}\nSL: ${sl}\nTP: ${tp}\nRR: ${rr.toFixed(2)}\nMin RR: ${this.config.minRR}`);
            if (rr < this.config.minRR) {
                this.log(`RESULT: BLOCK\nREASON: BAD_RR`);
                this.log(`🔴 EXECUTION BLOCKED | Reason: REJECTED: BAD_RR (${rr.toFixed(2)} < ${this.config.minRR})`);
                s.executionState = `REJECTED: BAD_RR (${rr.toFixed(2)} < ${this.config.minRR})`;
                s.stage = 'INVALIDATED';
                this.state.executedSetupIds.add(s.id);
                return;
            }
            this.log(`RESULT: PASS`);
            
            this.log(`SETUP READY FOR EXECUTION: BUY ${this.config.symbol} | Entry: ${entry} | SL: ${sl} | TP: ${tp} | Setup: ${s.id}`);
            this.log(`DETAILS | Risk: ${risk.toFixed(2)} | Reward: ${reward.toFixed(2)} | RR: ${rr.toFixed(2)} | Lot: ${this.config.lotSize}`);
            
            this.log(`\n[LIVE TRADING STATE]\nLIVE_TRADING_ENABLED: ${this.LIVE_TRADING_ENABLED}\nDaily Loss: ${this.state.dailyLoss}\nSafe Mode State: ${s.executionState}`);

            if (this.LIVE_TRADING_ENABLED) {
                if (s.executionState === 'SAFE_MODE_MONITORING') {
                    this.log(`[LIVE TRADING ENABLED] All safety conditions passed. Checking preserved valid setup...`);
                    this.log(`[RESUMING PRESERVED SETUP] Setup ID: ${s.id} | Entry: ${entry} | SL: ${sl} | TP: ${tp} | RR: ${rr.toFixed(2)}`);
                }
                try {
                    s.executionState = 'ORDER_SENT';
                    const t0 = new Date().toISOString();
                    this.log(`\n[ORDER DISPATCH]\nORDER FUNCTION CALLED`);
                    this.log(`[${t0}] EXECUTION TRIGGERED`);
                    this.log(`[${new Date().toISOString()}] METAAPI REQUEST SENT`);
                    
                    const tStart = Date.now();
                    const ticket = await this.execution.executeBuy(this.config.symbol, this.config.lotSize, sl, tp, 999, s.actualEntryPrice);
                    const tEnd = Date.now();
                    
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED | Latency: ${tEnd - tStart}ms`);
                    this.log(`BROKER RESPONSE: SUCCESS\nPOSITION TICKET: ${ticket}`);
                    this.log(`[${new Date().toISOString()}] 🟢 POSITION OPENED`);
                    this.log(`EXECUTE: BUY ${this.config.symbol} | Ticket: ${ticket}`);
                    s.executionState = 'POSITION_OPENED';
                } catch (e: any) {
                    const tEnd = Date.now();
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED`);
                    this.log(`BROKER RESPONSE: ERROR - ${e.message}`);
                    this.log(`[${new Date().toISOString()}] 🔴 BROKER REJECTED | Error: ${e.message}`);
                    s.executionState = `REJECTED: BROKER_ERROR`;
                    if (this.onExecutionFailed) {
                        this.onExecutionFailed({ setupId: s.id, reason: e.message });
                    }
                }
            } else {
                if (s.executionState !== 'SAFE_MODE_MONITORING') {
                    this.log(`[SAFE MONITORING] Valid setup reached entry but LIVE TRADING is disabled.`);
                    this.log(`Setup preserved. No MT5 order sent.`);
                }
                s.executionState = 'SAFE_MODE_MONITORING';
                return; // Return early to preserve the setup and prevent invalidation
            }
            
            this.state.executedSetupIds.add(s.id);
            s.stage = 'INVALIDATED'; 
        }
        else if (s.bias === 'BEARISH') {
            entry = s.actualEntryPrice!;
            sl = s.lockedSlTarget!;
            tp = s.lockedTpTarget!;

            const risk = sl - entry;
            const reward = entry - tp;
            const rr = risk > 0 ? reward / risk : 0;

            this.log(`\n[RR CHECK]\nEntry: ${entry}\nSL: ${sl}\nTP: ${tp}\nRR: ${rr.toFixed(2)}\nMin RR: ${this.config.minRR}`);
            if (rr < this.config.minRR) {
                this.log(`RESULT: BLOCK\nREASON: BAD_RR`);
                this.log(`🔴 EXECUTION BLOCKED | Reason: REJECTED: BAD_RR (${rr.toFixed(2)} < ${this.config.minRR})`);
                s.executionState = `REJECTED: BAD_RR (${rr.toFixed(2)} < ${this.config.minRR})`;
                s.stage = 'INVALIDATED';
                this.state.executedSetupIds.add(s.id);
                return;
            }
            this.log(`RESULT: PASS`);
            
            this.log(`SETUP READY FOR EXECUTION: SELL ${this.config.symbol} | Entry: ${entry} | SL: ${sl} | TP: ${tp} | Setup: ${s.id}`);
            this.log(`DETAILS | Risk: ${risk.toFixed(2)} | Reward: ${reward.toFixed(2)} | RR: ${rr.toFixed(2)} | Lot: ${this.config.lotSize}`);
            
            this.log(`\n[LIVE TRADING STATE]\nLIVE_TRADING_ENABLED: ${this.LIVE_TRADING_ENABLED}\nDaily Loss: ${this.state.dailyLoss}\nSafe Mode State: ${s.executionState}`);

            if (this.LIVE_TRADING_ENABLED) {
                if (s.executionState === 'SAFE_MODE_MONITORING') {
                    this.log(`[LIVE TRADING ENABLED] All safety conditions passed. Checking preserved valid setup...`);
                    this.log(`[RESUMING PRESERVED SETUP] Setup ID: ${s.id} | Entry: ${entry} | SL: ${sl} | TP: ${tp} | RR: ${rr.toFixed(2)}`);
                }
                try {
                    s.executionState = 'ORDER_SENT';
                    const t0 = new Date().toISOString();
                    this.log(`\n[ORDER DISPATCH]\nORDER FUNCTION CALLED`);
                    this.log(`[${t0}] EXECUTION TRIGGERED`);
                    this.log(`[${new Date().toISOString()}] METAAPI REQUEST SENT`);
                    
                    const tStart = Date.now();
                    const ticket = await this.execution.executeSell(this.config.symbol, this.config.lotSize, sl, tp, 999, s.actualEntryPrice);
                    const tEnd = Date.now();
                    
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED | Latency: ${tEnd - tStart}ms`);
                    this.log(`BROKER RESPONSE: SUCCESS\nPOSITION TICKET: ${ticket}`);
                    this.log(`[${new Date().toISOString()}] 🟢 POSITION OPENED`);
                    this.log(`EXECUTE: SELL ${this.config.symbol} | Ticket: ${ticket}`);
                    s.executionState = 'POSITION_OPENED';
                } catch (e: any) {
                    const tEnd = Date.now();
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED`);
                    this.log(`BROKER RESPONSE: ERROR - ${e.message}`);
                    this.log(`[${new Date().toISOString()}] 🔴 BROKER REJECTED | Error: ${e.message}`);
                    s.executionState = `REJECTED: BROKER_ERROR`;
                    if (this.onExecutionFailed) {
                        this.onExecutionFailed({ setupId: s.id, reason: e.message });
                    }
                }
            } else {
                if (s.executionState !== 'SAFE_MODE_MONITORING') {
                    this.log(`[SAFE MONITORING] Valid setup reached entry but LIVE TRADING is disabled.`);
                    this.log(`Setup preserved. No MT5 order sent.`);
                }
                s.executionState = 'SAFE_MODE_MONITORING';
                return; // Return early to preserve the setup and prevent invalidation
            }
            
            this.state.executedSetupIds.add(s.id);
            s.stage = 'INVALIDATED';
        }
        this.log(`========================================\n`);
    }

    public tradeProfitLockState: Map<string, {
        profitLockActive: boolean;
        originalTp: number;
        peakPrice: number;
        troughPrice: number;
        lastProtectedSl: number;
        activatedAt: number;
    }> = new Map();

    public isProfitLockActive(tradeId: string): boolean {
        return this.tradeProfitLockState.get(tradeId)?.profitLockActive ?? false;
    }

    public calculateAdaptiveBuffer(
        spread: number,
        m1Candles: Candle[],
        tpDistance: number = 0
    ): { buffer: number; volatility: number; spreadPts: number } {
        let volatility = 1.0;
        if (m1Candles && m1Candles.length >= 2) {
            const lookback = Math.min(14, m1Candles.length);
            const slice = m1Candles.slice(-lookback);
            let trSum = 0;
            for (let i = 1; i < slice.length; i++) {
                const tr = Math.max(
                    slice[i].high - slice[i].low,
                    Math.abs(slice[i].high - slice[i - 1].close),
                    Math.abs(slice[i].low - slice[i - 1].close)
                );
                trSum += tr;
            }
            volatility = trSum / (slice.length - 1);
        }

        const spreadPts = spread > 0 ? spread : 0.3;
        const minStopDistance = 0.5;
        const spreadComponent = spreadPts * 2.0;
        const volComponent = volatility * 0.5;
        const rawBuffer = Math.max(minStopDistance, spreadComponent, volComponent);

        let buffer = Math.min(2.5, Math.max(0.8, rawBuffer));
        if (tpDistance > 0) {
            buffer = Math.min(buffer, tpDistance * 0.3);
        }

        buffer = Number(buffer.toFixed(3));
        volatility = Number(volatility.toFixed(3));
        const spreadRounded = Number(spreadPts.toFixed(3));

        return { buffer, volatility, spreadPts: spreadRounded };
    }

    public evaluateProfitLockTrailing(
        tradeId: string,
        side: 'BUY' | 'SELL',
        entryPrice: number,
        currentSl: number,
        currentPrice: number,
        originalTp: number,
        spread: number = 0.3,
        m1Candles: Candle[] = []
    ): { newSl: number | null; isProfitLock: boolean; buffer: number; volatility: number; spread: number } {
        const defaultRes = { newSl: null, isProfitLock: false, buffer: 0, volatility: 0, spread: spread };
        if (!originalTp || originalTp <= 0) return defaultRes;

        const tpDistance = Math.abs(originalTp - entryPrice);
        const { buffer, volatility, spreadPts } = this.calculateAdaptiveBuffer(spread, m1Candles, tpDistance);

        let pState = this.tradeProfitLockState.get(tradeId);
        const isTriggeredNow = side === 'BUY' ? (currentPrice >= originalTp) : (currentPrice <= originalTp);
        const isAlreadyActive = pState?.profitLockActive ?? false;

        if (!isTriggeredNow && !isAlreadyActive) {
            return { ...defaultRes, buffer, volatility, spread: spreadPts };
        }

        if (!pState) {
            pState = {
                profitLockActive: true,
                originalTp,
                peakPrice: currentPrice,
                troughPrice: currentPrice,
                lastProtectedSl: currentSl,
                activatedAt: Date.now()
            };
            this.tradeProfitLockState.set(tradeId, pState);
        } else {
            pState.profitLockActive = true;
            pState.originalTp = originalTp;
            if (side === 'BUY') {
                pState.peakPrice = Math.max(pState.peakPrice || currentPrice, currentPrice);
            } else {
                pState.troughPrice = Math.min(pState.troughPrice || currentPrice, currentPrice);
            }
        }

        if (side === 'BUY') {
            const initialProtectedSl = Number((originalTp - buffer).toFixed(3));
            const trailingFromPeak = Number((pState.peakPrice - buffer).toFixed(3));
            let swingLowSl = 0;
            if (m1Candles && m1Candles.length >= 5) {
                const recentLows = m1Candles.slice(-5).map(c => c.low);
                swingLowSl = Number((Math.min(...recentLows) - 0.5).toFixed(3));
            }

            const candidateSl = Math.max(initialProtectedSl, trailingFromPeak, swingLowSl);

            // Strict monotonic check: SL can only move UP, never DOWN, and must be below current price
            if (candidateSl > currentSl && candidateSl < currentPrice) {
                pState.lastProtectedSl = candidateSl;
                
                const logMsg = 
`[PROFIT LOCK]
Direction: BUY
Entry: ${entryPrice.toFixed(3)}
Original TP: ${originalTp.toFixed(3)}
Current Price: ${currentPrice.toFixed(3)}
Spread: ${spreadPts.toFixed(3)}
Volatility: ${volatility.toFixed(3)}
Buffer: ${buffer.toFixed(3)}
New Protected SL: ${candidateSl.toFixed(3)}`;

                this.log(logMsg);
                this.addAnalysisLog(`🔒 [PROFIT LOCK] BUY TP Reached (${originalTp}) -> Protected SL Locked at ${candidateSl.toFixed(3)} (Buffer: ${buffer.toFixed(3)})`, 'success');

                return {
                    newSl: candidateSl,
                    isProfitLock: true,
                    buffer,
                    volatility,
                    spread: spreadPts
                };
            }
        } else {
            const initialProtectedSl = Number((originalTp + buffer).toFixed(3));
            const trailingFromTrough = Number((pState.troughPrice + buffer).toFixed(3));
            let swingHighSl = 999999;
            if (m1Candles && m1Candles.length >= 5) {
                const recentHighs = m1Candles.slice(-5).map(c => c.high);
                swingHighSl = Number((Math.max(...recentHighs) + 0.5).toFixed(3));
            }

            const candidateSl = Math.min(initialProtectedSl, trailingFromTrough, swingHighSl);

            // Strict monotonic check: SL can only move DOWN, never UP, and must be above current price
            if ((currentSl === 0 || candidateSl < currentSl) && candidateSl > currentPrice) {
                pState.lastProtectedSl = candidateSl;

                const logMsg = 
`[PROFIT LOCK]
Direction: SELL
Entry: ${entryPrice.toFixed(3)}
Original TP: ${originalTp.toFixed(3)}
Current Price: ${currentPrice.toFixed(3)}
Spread: ${spreadPts.toFixed(3)}
Volatility: ${volatility.toFixed(3)}
Buffer: ${buffer.toFixed(3)}
New Protected SL: ${candidateSl.toFixed(3)}`;

                this.log(logMsg);
                this.addAnalysisLog(`🔒 [PROFIT LOCK] SELL TP Reached (${originalTp}) -> Protected SL Locked at ${candidateSl.toFixed(3)} (Buffer: ${buffer.toFixed(3)})`, 'success');

                return {
                    newSl: candidateSl,
                    isProfitLock: true,
                    buffer,
                    volatility,
                    spread: spreadPts
                };
            }
        }

        return { newSl: null, isProfitLock: true, buffer, volatility, spread: spreadPts };
    }

    public evaluateTrailingSL(
        tradeId: string, 
        side: 'BUY' | 'SELL', 
        entryPrice: number, 
        currentSl: number, 
        currentPrice: number,
        initialSlDistance: number,
        m1Candles: Candle[],
        originalTp?: number,
        spread: number = 0.3
    ): number | null {
        // 1. Check TP Reached -> Profit Lock / Dynamic Trailing
        if (originalTp && originalTp > 0) {
            const plResult = this.evaluateProfitLockTrailing(
                tradeId,
                side,
                entryPrice,
                currentSl,
                currentPrice,
                originalTp,
                spread,
                m1Candles
            );
            if (plResult.newSl !== null) {
                return plResult.newSl;
            }
            if (plResult.isProfitLock) {
                return null;
            }
        }

        // 2. Standard Trailing SL before TP (Swing Structure Trailing at >= 1R)
        if (!m1Candles || m1Candles.length < 15) return null;
        
        const profit = side === 'BUY' ? (currentPrice - entryPrice) : (entryPrice - currentPrice);
        
        // Wait until at least 1R profit to start trailing (Break-Even or Trail)
        if (profit < initialSlDistance) return null;

        // Find recent swing point on M1 (last 10 candles)
        const recentCandles = m1Candles.slice(-10);
        
        if (side === 'BUY') {
            // Find recent swing low
            const recentLow = Math.min(...recentCandles.map(c => c.low));
            const potentialSl = recentLow - 1.0; // 10 ticks buffer below structure
            
            // Only move UP, never DOWN. Must not increase risk.
            if (potentialSl > currentSl && potentialSl < currentPrice) {
                return potentialSl;
            }
        } else {
            // Find recent swing high
            const recentHigh = Math.max(...recentCandles.map(c => c.high));
            const potentialSl = recentHigh + 1.0; // 10 ticks buffer above structure
            
            // Only move DOWN, never UP. Must not increase risk.
            if ((currentSl === 0 || potentialSl < currentSl) && potentialSl > currentPrice) {
                return potentialSl;
            }
        }
        
        return null;
    }

}
