import { ICTMarketData, Candle } from './ICT_MarketAdapter';
export type { ICTMarketData, Candle };
import { INewsProvider } from './ICT_NewsAdapter';
import { IMT5ExecutionAdapter, MockMT5Execution } from './ICT_MT5_Integration';

export interface EAConfig {
    symbol: string;
    isRealAccount: boolean;
    isUSCAccount: boolean;
    lotSize: number;
    stopLossDistance: number;
    takeProfitDistance: number;
    dailyLossLimit: number;
    maxConsecutiveSL: number;
    cooldownMinutes: number;
    maxOpenTrades: number;
    tradingSessionStart: string;
    tradingSessionEnd: string;
    newsFilterEnabled: boolean;
    minutesBeforeNewsBlock: number;
    minutesAfterNewsBlock: number;
    
    // Configurable Deterministic Order Block Parameters
    obLookbackCandles: number; // e.g. 15 candles dynamic scanning
    obMinDisplacementBodyRatio: number; // e.g., 0.6 (60% of candle range must be body)
    obMinDisplacementMultiplier: number; // e.g., 1.5x larger than average recent body
    obRecentCandlesForAverage: number; // e.g., 3 candles
    
    // Risk Management Overrides
    minSLPoints: number; // Minimum SL distance
    minTPPoints: number; // Minimum TP distance
    minRR: number; // Minimum Risk:Reward Ratio
    
    // Trailing Stop Settings
    trailingStopEnabled: boolean;
    trailingStopActivationPoints: number; // Activation distance (profit) in XAUUSD points
    trailingStopDistancePoints: number; // How far to trail behind current price in XAUUSD points

}

export type SetupStage = 'SEARCHING' | 'WAITING' | 'TRIGGERED' | 'INVALIDATED' | 'EXECUTED' | 'REJECTED';
export type SetupBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export interface ICTSetup {
    id: string;
    stage: SetupStage;
    bias: SetupBias;
    
    h4BiasConfirmed: boolean;
    m15LiquiditySwept: boolean;
    m15CISDConfirmed: boolean;
    m1DisplacementConfirmed: boolean;
    m1OBConfirmed: boolean;
    m1FVGConfirmed: boolean;
    retracementConfirmed: boolean;
    
    obHigh: number;
    obLow: number;
    fvgHigh: number;
    fvgLow: number;

    // Structural SL & Locked TP Target
    structuralInvalidationLow?: number;
    structuralInvalidationHigh?: number;
    lockedSlTarget?: number;
    lockedTpTarget?: number;
    
    // Proportional Missed-Entry / Near-TP Protection Tracking
    highestPriceSinceSetup?: number;
    lowestPriceSinceSetup?: number;
    
    // True Event-Order Tracking
    firstTouch?: 'NONE' | 'ENTRY' | 'TP' | 'UNKNOWN';
    firstTouchPrice?: number;
    firstTouchTimestamp?: number;
    entryTouchedTimestamp?: number;
    tpTouchedTimestamp?: number;
    
    isStale?: boolean;

    creationTime: number;
    expirationTime: number;
    executionState?: string;
    executionTicket?: string;
    lockedEntryPrice?: number;
    triggerTickPrice?: number;
    actualEntryPrice?: number;
    entryAlertSent?: boolean;
    confirmationAlertSent?: boolean;
}

export interface EAPosition {
    ticket: string;
    symbol: string;
    type: 'BUY' | 'SELL';
    lot: number;
    openPrice: number;
    sl: number;
    tp: number;
    magic: number;
    setupId: string;
    commission?: number;
    swap?: number;
}

export interface ICTTelemetry {
    lastAnalysisTime: number;
    status: 'ANALYZING' | 'WAITING' | 'READY' | 'ERROR';
    symbol: string;
    livePrice: {
        bid: number;
        ask: number;
        spread: number;
    };
    h4: {
        bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
        structure: 'CONFIRMED' | 'WAITING';
        lastCandleTime?: string;
        candleCount: number;
        open?: number;
        high?: number;
        low?: number;
        close?: number;
        protectedLevel?: number;
    };
    m15: {
        liquiditySweep: 'FOUND' | 'NOT FOUND' | 'WAITING';
        cisd: 'CONFIRMED' | 'WAITING';
        swingHigh: number;
        swingLow: number;
        targetHigh: number;
        targetLow: number;
        candleCount: number;
        lastCandleTime?: string;
    };
    m1: {
        displacement: 'FOUND' | 'WAITING' | 'CONFIRMED';
        orderBlock: 'FOUND' | 'WAITING' | 'CONFIRMED';
        fvg: 'FOUND' | 'WAITING' | 'CONFIRMED';
        retracement: 'FOUND' | 'WAITING' | 'CONFIRMED';
        obZone: { high: number; low: number } | null;
        fvgZone: { high: number; low: number } | null;
        candleCount: number;
        lastCandleTime?: string;
    };
    entryStatus: 'SEARCHING' | 'WAITING' | 'VALID SETUP' | 'READY TO EXECUTE' | 'TRADE OPENED';
    waitingReason: string;
    latency?: {
        mt5TickTime: string;
        backendReceiveTime: string;
        ictAnalysisTime: string;
        lastTickAgeSeconds: number;
        latencyMs: number;
    };
    validSetup: {
        direction: 'BUY' | 'SELL';
        entry: number;
        actualEntry?: number;
        sl: number;
        tp: number;
        rr: number;
        setupId: string;
    commission?: number;
    swap?: number;
        stage: string;
        executionState?: string;
        obHigh: number;
        obLow: number;
    } | null;
    systemHealth: {
        mt5Connection: boolean;
        eaBridge: boolean;
        vps: boolean;
        liveMarketData: boolean;
        dataFreshness: boolean;
        newsFilter: boolean;
        riskGuard: boolean;
        problemReason?: string;
    };
    recentLogs: Array<{
        timestamp: string;
        message: string;
        level: 'info' | 'warn' | 'success' | 'error';
    }>;
}

export class IctXauusdEA {
    public config: EAConfig;
    private newsProvider: INewsProvider | null;
    private execution: IMT5ExecutionAdapter;
    public logs: string[] = [];
    public lastM1Candles: Candle[] = [];
    public onActualEntryTriggered?: (data: {
        setupId?: string;
        symbol: string;
        direction: 'BUY' | 'SELL';
        entry: number;
        sl?: number;
        tp?: number;
        rr?: number;
        status: string;
    }) => void;
    public onExecutionSuccess?: (data: {
        setupId: string;
    commission?: number;
    swap?: number;
        symbol: string;
        direction: 'BUY' | 'SELL';
        entry: number;
        sl: number;
        tp: number;
        lot: number;
        ticket: string;
    }) => void;
    public onExecutionFailed?: (data: {
        setupId: string;
    commission?: number;
    swap?: number;
        reason: string;
    }) => void;
    public onSetupConfirmed?: (data: {
        symbol: string;
        direction: 'BUY' | 'SELL';
        entryZone: { low: number; high: number };
        actualEntry: number;
        sl: number;
        tp: number;
        rr: number;
        status: string;
    }) => void;
    
    public state = {
        currentSetup: null as ICTSetup | null,
        executedSetupIds: new Set<string>(),
        dailyLoss: 0,
        consecutiveSLs: 0,
        lastSLTime: 0,
        openPositions: [] as EAPosition[],
        h4State: {
            bias: 'NEUTRAL' as SetupBias,
            protectedStructureLevel: 0,
            lastConfirmedHigh: 0,
            lastConfirmedLow: 0,
            lastEvaluatedCandleTime: 0
        },
        m15State: {
            stage: 'WAITING_FOR_SWEEP' as 'WAITING_FOR_SWEEP' | 'WAITING_FOR_CISD' | 'CISD_CONFIRMED',
            bias: 'NEUTRAL' as SetupBias,
            swingHigh: 0,
            swingLow: 0,
            sweepTime: 0,
            sweptLiquidityLevel: 0,
            cisdReferenceLevel: 0
        }
    };

    public telemetry: ICTTelemetry = {
        lastAnalysisTime: Date.now(),
        status: 'WAITING',
        symbol: 'XAUUSDc',
        livePrice: { bid: 0, ask: 0, spread: 0 },
        h4: { bias: 'NEUTRAL', structure: 'WAITING', candleCount: 0 },
        m15: { liquiditySweep: 'WAITING', cisd: 'WAITING', swingHigh: 0, swingLow: 0, targetHigh: 0, targetLow: 0, candleCount: 0 },
        m1: { displacement: 'WAITING', orderBlock: 'WAITING', fvg: 'WAITING', retracement: 'WAITING', obZone: null, fvgZone: null, candleCount: 0 },
        entryStatus: 'WAITING',
        waitingReason: '⏳ WAITING FOR M15 LIQUIDITY SWEEP',
        validSetup: null,
        systemHealth: {
            mt5Connection: true,
            eaBridge: true,
            vps: true,
            liveMarketData: true,
            dataFreshness: true,
            newsFilter: true,
            riskGuard: true
        },
        recentLogs: []
    };

    public LIVE_TRADING_ENABLED: boolean = false;
    public liveTradingBlockReason: string = '';

    constructor(config: EAConfig, newsProvider: INewsProvider | null = null, execution?: IMT5ExecutionAdapter) {
        this.config = config;
        this.newsProvider = newsProvider;
        this.execution = execution || new MockMT5Execution();
        this.addAnalysisLog('NEW ICT EA Initialized in Live Monitoring Mode', 'info');
    }

    public addAnalysisLog(message: string, level: 'info' | 'warn' | 'success' | 'error' = 'info') {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-GB', { hour12: false });
        this.telemetry.recentLogs.unshift({
            timestamp: `[${timeStr}]`,
            message,
            level
        });
        if (this.telemetry.recentLogs.length > 200) {
            this.telemetry.recentLogs.pop();
        }
    }

    public getTelemetry(botState?: any): ICTTelemetry {
        if (botState) {
            const priceAgeMs = Date.now() - (botState.lastTickTime || 0);
            const isFresh = priceAgeMs < 65000;
            const isMarketLive = Boolean(botState.marketDataStatus?.includes('LIVE'));
            const isMt5Connected = Boolean(botState.account?.isConnected);
            const isEaBridgeConnected = Boolean(botState.account?.eaConnected);
            const isVpsOnline = Boolean(botState.account?.vpsOnline);
            const isNewsOk = botState.newsProviderStatus !== 'UNAVAILABLE';
            const isRiskOk = !botState.dailyLossLimitHit && (botState.consecutiveLosses || 0) < (botState.riskConfig?.maxConsecutiveLosses || 3);

            let problemReason = '';
            if (!isMt5Connected) problemReason = 'MT5 Server Disconnected';
            else if (!isMarketLive) problemReason = 'Market Data Feed Offline';
            else if (!isFresh) problemReason = `Price Feed Stale (${Math.round(priceAgeMs / 1000)}s delay)`;
            else if (!isRiskOk) problemReason = 'Daily Loss Limit or Consecutive Loss Exceeded';

            this.telemetry.systemHealth = {
                mt5Connection: isMt5Connected,
                eaBridge: isEaBridgeConnected,
                vps: isVpsOnline,
                liveMarketData: isMarketLive,
                dataFreshness: isFresh,
                newsFilter: isNewsOk,
                riskGuard: isRiskOk,
                problemReason: problemReason || undefined
            };

            if (problemReason) {
                if (problemReason.includes('Stale') || problemReason.includes('Offline')) {
                    this.telemetry.status = 'WAITING';
                    this.telemetry.waitingReason = '⏳ ' + problemReason;
                } else {
                    this.telemetry.status = 'ERROR';
                    this.telemetry.waitingReason = '🔴 ' + problemReason;
                }
            } else if (this.state.currentSetup?.stage === 'TRIGGERED') {
                this.telemetry.status = 'READY';
            } else {
                this.telemetry.status = 'WAITING';
            }

            const serverTime = botState.lastTickTime || Date.now();
            const now = Date.now();
            const tickAge = Math.max(0, (now - (botState.lastTickTime || serverTime)) / 1000);
            const pingMs = Number(botState.account?.pingMs || 15);

            this.telemetry.latency = {
                mt5TickTime: new Date(serverTime).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                backendReceiveTime: new Date(botState.lastTickTime || now).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                ictAnalysisTime: new Date(this.telemetry.lastAnalysisTime || now).toISOString().replace('T', ' ').substring(0, 23) + ' UTC',
                lastTickAgeSeconds: Number(tickAge.toFixed(1)),
                latencyMs: pingMs
            };
        }
        return this.telemetry;
    }

    private log(msg: string) {
        this.logs.push(`[ICT EA] ${msg}`);
    }

    public start() {
        this.log("EA Started in SAFE MOCK MODE (REAL DATA = ALLOWED, REAL EXECUTION = DISABLED).");
    }

    public async onTick(data: ICTMarketData) {
        this.lastM1Candles = data.m1Candles;
        this.telemetry.lastAnalysisTime = Date.now();
        this.telemetry.symbol = data.symbol || this.config.symbol;
        this.telemetry.livePrice = {
            bid: data.bid,
            ask: data.ask,
            spread: Number(data.spread.toFixed(1))
        };

        if (!data || !data.symbol || (!data.symbol.startsWith('XAUUSD') && data.symbol !== 'GOLD')) {
            this.log("BLOCKED: INVALID MT5 DATA");
            this.telemetry.status = 'ERROR';
            this.telemetry.waitingReason = '🔴 BLOCKED: INVALID MT5 DATA';
            return;
        }

        const now = data.serverTime;

        // Strict Real-Time Data Freshness Guard (Threshold: 5000ms)
        const tickLatency = Date.now() - now;
        if (tickLatency > 5000) {
            this.log(`BLOCKED: STALE DATA (TICK DELAY > 5000ms: ${tickLatency}ms)`);
            this.telemetry.status = 'ERROR';
            this.telemetry.waitingReason = `🔴 BLOCKED: STALE DATA (TICK DELAY > 5000ms: ${tickLatency}ms)`;
            return;
        }

        // Strict Candle Data Freshness Guard: latest M1 candle must be within 3 minutes (180,000ms)
        if (data.m1Candles && data.m1Candles.length > 0) {
            const latestM1 = data.m1Candles[data.m1Candles.length - 1];
            if (latestM1 && (now - latestM1.time > 180000)) {
                this.log(`BLOCKED: STALE M1 CANDLE DATA (CANDLE AGE: ${Math.round((now - latestM1.time) / 1000)}s)`);
                this.telemetry.status = 'ERROR';
                this.telemetry.waitingReason = `🔴 BLOCKED: STALE M1 CANDLE (AGE: ${Math.round((now - latestM1.time) / 1000)}s)`;
                return;
            }
        }

        if (this.state.dailyLoss >= this.config.dailyLossLimit) {
            this.log(`BLOCKED: Daily Loss Limit Reached (${this.state.dailyLoss})`);
            this.telemetry.waitingReason = `🔴 BLOCKED: Daily Loss Limit Reached (${this.state.dailyLoss})`;
            return;
        }

        const openPos = await this.execution.getOpenPositions(999);
        this.state.openPositions = openPos;

        if (this.state.consecutiveSLs >= this.config.maxConsecutiveSL) {
            if (now - this.state.lastSLTime < (this.config.cooldownMinutes * 60000)) {
                this.log("BLOCKED: COOLDOWN PERIOD ACTIVE");
                this.telemetry.waitingReason = "⏳ COOLDOWN PERIOD ACTIVE AFTER CONSECUTIVE SL";
                return;
            } else {
                this.state.consecutiveSLs = 0;
            }
        }

        if (this.config.newsFilterEnabled) {
            if (!this.newsProvider) {
                this.log("BLOCKED: NEWS DATA UNAVAILABLE");
                return;
            }
            const upcoming = await this.newsProvider.getUpcomingHighImpactEvents(data.serverTime);
            if (upcoming === null) {
                this.log("BLOCKED: NEWS DATA UNAVAILABLE");
                return;
            }
            
            for (const event of upcoming) {
                if (event.impact === 'HIGH') {
                    const msBefore = this.config.minutesBeforeNewsBlock * 60 * 1000;
                    const msAfter = this.config.minutesAfterNewsBlock * 60 * 1000;
                    
                    const blockStart = event.time - msBefore;
                    const blockEnd = event.time + msAfter;
                    
                    if (now >= blockStart && now <= blockEnd) {
                        this.log(`NEWS BLOCK ACTIVE | HIGH IMPACT USD EVENT | EVENT: ${event.title || 'Unknown Event'} | TIME: ${new Date(event.time).toISOString()} | NEW ENTRY BLOCKED`);
                        this.telemetry.waitingReason = `⏳ NEWS BLOCK ACTIVE: ${event.title || 'High Impact Event'}`;
                        return;
                    }
                }
            }
        }

        // Setups stay active while waiting for retracement until an explicit ICT invalidation occurs.
        // Trigger execution when price touches the locked entry
        if (this.state.currentSetup && this.state.currentSetup.stage === 'WAITING') {
            // Check Pre-Entry Virtual Setup TP / SL cancellation before entry
            const isCancelled = this.checkPendingSetupCancellation(data);
            if (isCancelled) {
                if (!this.state.currentSetup || ['INVALIDATED', 'EXECUTED', 'REJECTED'].includes(this.state.currentSetup.stage)) {
                    this.analyzeSequence(data);
                }
                return;
            }

            const s = this.state.currentSetup;
            const dynamicEntry = s.lockedEntryPrice || (s.bias === 'BULLISH' ? s.obHigh : s.obLow);
            
            let entryTouched = false;
            // Strictly use real-time ticks
            if (s.bias === 'BULLISH') {
                entryTouched = data.ask <= dynamicEntry;
            } else {
                entryTouched = data.bid >= dynamicEntry;
            }
            
            if (entryTouched) {
                const t0 = new Date().toISOString();
                this.log(`\n========================================\n[ENTRY TRIGGER]\n[${t0}] SIGNAL CREATED\nSetup ID: ${s.id}\nDirection: ${s.bias}\nLocked Entry: ${dynamicEntry}\nCurrent Price: ${s.bias === 'BULLISH' ? data.ask : data.bid}\n========================================`);
                this.log("WAITING FOR ENTRY fulfilled. Market Price reached Locked Entry.");
                this.addAnalysisLog(`តម្លៃបានប៉ះចំនុច Entry គោលដៅ 🎯 -> TRIGGERED`, 'success');
                
                s.triggerTickPrice = s.bias === 'BULLISH' ? data.ask : data.bid;
                s.stage = 'TRIGGERED';
                
                if (this.telemetry.validSetup) {
                    this.telemetry.validSetup.stage = 'TRIGGERED';
                    this.telemetry.validSetup.actualEntry = dynamicEntry;
                }
                
                if (this.onActualEntryTriggered && !s.entryAlertSent) {
                    s.entryAlertSent = true;
                    this.onActualEntryTriggered({
                        setupId: s.id,
                        symbol: data.symbol || this.config.symbol,
                        direction: s.bias === 'BULLISH' ? 'BUY' : 'SELL',
                        entry: dynamicEntry,
                        sl: s.lockedSlTarget!,
                        tp: s.lockedTpTarget!,
                        rr: this.telemetry.validSetup?.rr,
                        status: 'ENTRY TRIGGERED'
                    });
                }
            }
        }

        if (!this.state.currentSetup || ['INVALIDATED', 'EXECUTED', 'REJECTED'].includes(this.state.currentSetup.stage)) {
            this.analyzeSequence(data);
        }

        if (this.state.currentSetup && this.state.currentSetup.stage === 'TRIGGERED') {
            const s = this.state.currentSetup;
            this.log(`\n========================================\n[EXECUTION DECISION]\nexecuteTrade() CALLED: YES\nREASON: Setup stage is TRIGGERED (Setup ID: ${s.id})\n========================================`);
            if (this.state.openPositions.length >= this.config.maxOpenTrades) {
                this.log(`\n[RISK CHECK]\nRESULT: BLOCK\nREASON: MAX OPEN TRADES REACHED (${this.state.openPositions.length}/${this.config.maxOpenTrades})`);
                this.log(`executeTrade() ABORTED: MAX OPEN TRADES REACHED`);
                this.telemetry.waitingReason = `🟢 MAX OPEN TRADES REACHED (${this.state.openPositions.length}/${this.config.maxOpenTrades})`;
                return;
            }
            this.log(`\n[RISK CHECK]\nRESULT: PASS\nREASON: Max open trades within limit (${this.state.openPositions.length}/${this.config.maxOpenTrades})`);
            await this.executeTrade(data);
        }

        if (this.state.currentSetup && this.telemetry.validSetup) {
            this.telemetry.validSetup.stage = this.state.currentSetup.stage;
            this.telemetry.validSetup.executionState = this.state.currentSetup.executionState;
        }
    }

    public cancelPendingSetup(reason: string, detail: string): void {
        const s = this.state.currentSetup;
        if (!s || s.stage !== 'WAITING') return;

        // ENTRY PRIORITY: If there is an active broker position, this is an ACTIVE trade, NOT a pending setup!
        if (this.state.openPositions && this.state.openPositions.length > 0) {
            return;
        }

        const setupId = s.id;
        const bias = s.bias;
        const entry = s.lockedEntryPrice || (s.bias === 'BULLISH' ? s.obHigh : s.obLow);
        const sl = s.lockedSlTarget || 0;
        const tp = s.lockedTpTarget || 0;

        const logMsg = 
`\n========================================
[PENDING SETUP CANCELLED]
Setup ID: ${setupId}
Direction: ${bias}
Locked Entry: ${entry.toFixed(3)}
Setup SL: ${sl.toFixed(3)}
Setup TP: ${tp.toFixed(3)}
Reason: ${reason}
Detail: ${detail}
Status: NO TRADE EXECUTED | NOT A WIN/LOSS | NO COOLDOWN
========================================`;

        this.log(logMsg);
        this.addAnalysisLog(`❌ [PENDING SETUP CANCELLED] ${reason} -> ${detail} | Setup ចាស់ត្រូវបាន Cancel ចោល (មិនមាន Trade / មិនគិត Win ឬ Loss / គ្មាន Cooldown)`, 'warn');

        // 1. Invalidate old setup state
        s.stage = 'INVALIDATED';
        s.isStale = true;

        // 2. Prevent old setup from ever executing
        this.state.executedSetupIds.add(setupId);

        // 3. Clear current setup (clears locked entry, setup SL, setup TP)
        this.state.currentSetup = null;

        // 4. Clear telemetry validSetup so UI updates immediately
        this.telemetry.validSetup = null;
        this.telemetry.entryStatus = 'SEARCHING';
        this.telemetry.waitingReason = `🔍 Setup Cancelled (${reason}) — ស្វែងរក Setup ថ្មី`;
    }

    public checkPendingSetupCancellation(data: ICTMarketData): boolean {
        if (!this.state.currentSetup || this.state.currentSetup.stage !== 'WAITING') {
            return false;
        }

        // ENTRY PRIORITY: If a real position is already active, pending cancellation must NOT close/cancel active trade
        if (this.state.openPositions && this.state.openPositions.length > 0) {
            return false;
        }

        const s = this.state.currentSetup;
        const dynamicEntry = s.lockedEntryPrice || (s.bias === 'BULLISH' ? s.obHigh : s.obLow);

        if (s.bias === 'BULLISH') {
            const tpTarget = s.lockedTpTarget;
            const slTarget = s.lockedSlTarget;

            // 1. BUY Pending Setup: Market Price reaches/crosses Setup TP before Entry
            if (tpTarget && tpTarget > 0 && (data.bid >= tpTarget || data.ask >= tpTarget)) {
                this.cancelPendingSetup(
                    'BUY_TP_REACHED_BEFORE_ENTRY',
                    `Market Price (${data.bid.toFixed(3)}) reached/crossed Setup TP (${tpTarget.toFixed(3)}) before Entry (${dynamicEntry.toFixed(3)})`
                );
                return true;
            }

            // 2. BUY Pending Setup: Market Price reaches/crosses Setup SL before Entry
            if (slTarget && slTarget > 0 && (data.bid <= slTarget || data.ask <= slTarget)) {
                this.cancelPendingSetup(
                    'BUY_SL_REACHED_BEFORE_ENTRY',
                    `Market Price (${data.ask.toFixed(3)}) reached/crossed Setup SL (${slTarget.toFixed(3)}) before Entry (${dynamicEntry.toFixed(3)})`
                );
                return true;
            }
        } else if (s.bias === 'BEARISH') {
            const tpTarget = s.lockedTpTarget;
            const slTarget = s.lockedSlTarget;

            // 1. SELL Pending Setup: Market Price reaches/crosses Setup TP before Entry
            if (tpTarget && tpTarget > 0 && (data.ask <= tpTarget || data.bid <= tpTarget)) {
                this.cancelPendingSetup(
                    'SELL_TP_REACHED_BEFORE_ENTRY',
                    `Market Price (${data.ask.toFixed(3)}) reached/crossed Setup TP (${tpTarget.toFixed(3)}) before Entry (${dynamicEntry.toFixed(3)})`
                );
                return true;
            }

            // 2. SELL Pending Setup: Market Price reaches/crosses Setup SL before Entry
            if (slTarget && slTarget > 0 && (data.ask >= slTarget || data.bid >= slTarget)) {
                this.cancelPendingSetup(
                    'SELL_SL_REACHED_BEFORE_ENTRY',
                    `Market Price (${data.bid.toFixed(3)}) reached/crossed Setup SL (${slTarget.toFixed(3)}) before Entry (${dynamicEntry.toFixed(3)})`
                );
                return true;
            }
        }

        return false;
    }

    private analyzeSequence(data: ICTMarketData) {
        let bias: SetupBias = this.state.h4State.bias;
        let lastH4Candle: Candle | null = null;

        // Custom ICT-based H4 market-structure bias model (CLOSED CANDLES ONLY)
        // Ensure we have H4 candles and strictly ignore the forming/live candle (data.h4Candles.length - 1)
        if (data.h4Candles && data.h4Candles.length >= 7) {
            const closedCandles = data.h4Candles.slice(0, data.h4Candles.length - 1);
            const lastClosed = closedCandles[closedCandles.length - 1];
            lastH4Candle = lastClosed;

            // Detect 5-candle fractals on closed candles only
            // A candle i is a fractal if higher/lower than 2 before and 2 after
            const swingHighs: { price: number; time: number }[] = [];
            const swingLows: { price: number; time: number }[] = [];

            for (let i = 2; i <= closedCandles.length - 3; i++) {
                const c = closedCandles[i];
                if (c.high > closedCandles[i-1].high && c.high > closedCandles[i-2].high &&
                    c.high > closedCandles[i+1].high && c.high > closedCandles[i+2].high) {
                    swingHighs.push({ price: c.high, time: c.time });
                }
                if (c.low < closedCandles[i-1].low && c.low < closedCandles[i-2].low &&
                    c.low < closedCandles[i+1].low && c.low < closedCandles[i-2].low) {
                    swingLows.push({ price: c.low, time: c.time });
                }
            }

            const h4St = this.state.h4State;

            // 1. INITIALIZATION: If Bias is NEUTRAL, determine initial structure from historical swings
            if (h4St.bias === 'NEUTRAL') {
                if (swingHighs.length >= 2 && swingLows.length >= 2) {
                    const shPrev = swingHighs[swingHighs.length - 2];
                    const shCurr = swingHighs[swingHighs.length - 1];
                    const slPrev = swingLows[swingLows.length - 2];
                    const slCurr = swingLows[swingLows.length - 1];

                    // Bullish: Higher High (HH) and Higher Low (HL)
                    if (shCurr.price > shPrev.price && slCurr.price > slPrev.price) {
                        h4St.bias = 'BULLISH';
                        h4St.protectedStructureLevel = slCurr.price; // Protected Higher Low
                        h4St.lastConfirmedHigh = shCurr.price;
                        h4St.lastConfirmedLow = slCurr.price;
                    } 
                    // Bearish: Lower High (LH) and Lower Low (LL)
                    else if (shCurr.price < shPrev.price && slCurr.price < slPrev.price) {
                        h4St.bias = 'BEARISH';
                        h4St.protectedStructureLevel = shCurr.price; // Protected Lower High
                        h4St.lastConfirmedHigh = shCurr.price;
                        h4St.lastConfirmedLow = slCurr.price;
                    } else {
                        // Ambiguous structure
                        h4St.bias = 'NEUTRAL';
                        h4St.protectedStructureLevel = 0;
                    }
                } else {
                    h4St.bias = 'NEUTRAL';
                    h4St.protectedStructureLevel = 0;
                }
                bias = h4St.bias;
            } else {
                // 2. STRUCTURE MAINTENANCE & STRUCTURE BREAK
                if (h4St.bias === 'BULLISH') {
                    // Check for Structure Break: CLOSED candle CLOSES below the protected Higher Low
                    if (lastClosed.close < h4St.protectedStructureLevel) {
                        // BULLISH -> BEARISH flip
                        h4St.bias = 'BEARISH';
                        // The protected level flips to the highest swing high before the break
                        const priorHigh = swingHighs.length > 0 ? swingHighs[swingHighs.length - 1].price : h4St.lastConfirmedHigh;
                        h4St.protectedStructureLevel = priorHigh;
                        h4St.lastConfirmedHigh = priorHigh;
                        h4St.lastConfirmedLow = lastClosed.low;
                    } else {
                        // Bullish structure remains intact!
                        // Advance protected HL only when a new HH and new HL (above previous protected HL) are confirmed
                        if (swingHighs.length >= 2 && swingLows.length >= 2) {
                            const latestSH = swingHighs[swingHighs.length - 1];
                            const latestSL = swingLows[swingLows.length - 1];
                            if (latestSH.price > h4St.lastConfirmedHigh && latestSL.price > h4St.protectedStructureLevel) {
                                h4St.protectedStructureLevel = latestSL.price;
                                h4St.lastConfirmedHigh = latestSH.price;
                                h4St.lastConfirmedLow = latestSL.price;
                            }
                        }
                    }
                } else if (h4St.bias === 'BEARISH') {
                    // Check for Structure Break: CLOSED candle CLOSES above the protected Lower High
                    if (lastClosed.close > h4St.protectedStructureLevel) {
                        // BEARISH -> BULLISH flip
                        h4St.bias = 'BULLISH';
                        // The protected level flips to the lowest swing low before the break
                        const priorLow = swingLows.length > 0 ? swingLows[swingLows.length - 1].price : h4St.lastConfirmedLow;
                        h4St.protectedStructureLevel = priorLow;
                        h4St.lastConfirmedLow = priorLow;
                        h4St.lastConfirmedHigh = lastClosed.high;
                    } else {
                        // Bearish structure remains intact!
                        // Advance protected LH only when a new LL and new LH (below previous protected LH) are confirmed
                        if (swingHighs.length >= 2 && swingLows.length >= 2) {
                            const latestSL = swingLows[swingLows.length - 1];
                            const latestSH = swingHighs[swingHighs.length - 1];
                            if (latestSL.price < h4St.lastConfirmedLow && latestSH.price < h4St.protectedStructureLevel) {
                                h4St.protectedStructureLevel = latestSH.price;
                                h4St.lastConfirmedHigh = latestSH.price;
                                h4St.lastConfirmedLow = latestSL.price;
                            }
                        }
                    }
                }
                bias = h4St.bias;
            }

            h4St.lastEvaluatedCandleTime = lastClosed.time;

            this.telemetry.h4 = {
                bias: bias,
                structure: bias !== 'NEUTRAL' ? 'CONFIRMED' : 'WAITING',
                lastCandleTime: new Date(lastClosed.time).toISOString(),
                candleCount: data.h4Candles.length,
                open: lastClosed.open,
                high: lastClosed.high,
                low: lastClosed.low,
                close: lastClosed.close,
                protectedLevel: h4St.protectedStructureLevel
            };
        } else {
            this.state.h4State.bias = 'NEUTRAL';
            this.state.h4State.protectedStructureLevel = 0;
            bias = 'NEUTRAL';
            this.telemetry.h4 = {
                bias: 'NEUTRAL',
                structure: 'WAITING',
                candleCount: data.h4Candles?.length || 0
            };
        }

        if (bias === 'NEUTRAL') {
            this.telemetry.waitingReason = '⏳ WAITING FOR H4 CANDLE DATA / BIAS';
            this.telemetry.entryStatus = 'SEARCHING';
            return;
        }

        // H4 Bias Context Reset: If bias changes, reset M15 state machine
        if (this.state.m15State.bias !== bias) {
            this.state.m15State = {
                stage: 'WAITING_FOR_SWEEP',
                bias: bias,
                swingHigh: 0,
                swingLow: 0,
                sweepTime: 0,
                sweptLiquidityLevel: 0,
                cisdReferenceLevel: 0
            };
        }

        let m15Swept = false;
        let m15CISD = false;
        let m15_1: Candle | null = null;
        let m15_3: Candle | null = null;
        const st = this.state.m15State;

        if (data.m15Candles && data.m15Candles.length >= 5) {
            const candles = data.m15Candles;
            const currentCandle = candles[candles.length - 1]; // Currently forming
            m15_3 = currentCandle;

            // 1. Detect Swing High / Low (Fractal logic on closed candles only)
            let recentSwingHigh = 0;
            let recentSwingLow = 0;
            
            // Lookback for a 5-candle fractal where the middle candle is higher/lower than 2 before and 2 after.
            for (let i = candles.length - 3; i >= 2; i--) {
                const c = candles[i];
                if (recentSwingLow === 0 && 
                    c.low < candles[i-1].low && c.low < candles[i-2].low &&
                    c.low < candles[i+1].low && c.low < candles[i+2].low) {
                    recentSwingLow = c.low;
                }
                if (recentSwingHigh === 0 && 
                    c.high > candles[i-1].high && c.high > candles[i-2].high &&
                    c.high > candles[i+1].high && c.high > candles[i+2].high) {
                    recentSwingHigh = c.high;
                }
                if (recentSwingLow !== 0 && recentSwingHigh !== 0) break;
            }
            
            // Fallbacks if no perfect fractal found
            if (recentSwingLow === 0) recentSwingLow = Math.min(...candles.slice(Math.max(0, candles.length - 20), candles.length - 2).map(c => c.low));
            if (recentSwingHigh === 0) recentSwingHigh = Math.max(...candles.slice(Math.max(0, candles.length - 20), candles.length - 2).map(c => c.high));

            st.swingHigh = recentSwingHigh;
            st.swingLow = recentSwingLow;
            
            // For UI display reference
            m15_1 = { ...currentCandle, high: recentSwingHigh, low: recentSwingLow };

            // 2. STATE MACHINE: Sweep Detection
            if (st.stage === 'WAITING_FOR_SWEEP') {
                if (bias === 'BULLISH') {
                    // Sell-side liquidity sweep: price goes below swing low and reclaims it (closes above)
                    for (let i = candles.length - 5; i <= candles.length - 2; i++) {
                        const c = candles[i];
                        if (c && c.low < recentSwingLow && c.close > recentSwingLow) {
                            st.stage = 'WAITING_FOR_CISD';
                            st.sweepTime = c.time;
                            st.sweptLiquidityLevel = recentSwingLow;
                            // Lock the Prior Swing High that existed before this sweep as the CISD reference
                            st.cisdReferenceLevel = recentSwingHigh;
                            break;
                        }
                    }
                } else if (bias === 'BEARISH') {
                    // Buy-side liquidity sweep: price goes above swing high and reclaims it (closes below)
                    for (let i = candles.length - 5; i <= candles.length - 2; i++) {
                        const c = candles[i];
                        if (c && c.high > recentSwingHigh && c.close < recentSwingHigh) {
                            st.stage = 'WAITING_FOR_CISD';
                            st.sweepTime = c.time;
                            st.sweptLiquidityLevel = recentSwingHigh;
                            // Lock the Prior Swing Low that existed before this sweep as the CISD reference
                            st.cisdReferenceLevel = recentSwingLow;
                            break;
                        }
                    }
                }
            }

            // 3. STATE MACHINE: CISD Detection (Strictly AFTER Sweep)
            // Note: In WAITING_FOR_CISD, the cisdReferenceLevel is LOCKED and will not change even if new swings form
            if (st.stage === 'WAITING_FOR_CISD') {
                const sweepCandle = candles.find(c => c.time === st.sweepTime);
                if (sweepCandle) {
                    if (bias === 'BULLISH') {
                        // CISD confirmed when a strictly CLOSED M15 candle (after the sweep candle) closes ABOVE the LOCKED prior structure level
                        const cisdCandle = candles.find(c => c.time > st.sweepTime && c.time <= candles[candles.length - 2].time && c.close > st.cisdReferenceLevel);
                        if (cisdCandle) {
                            st.stage = 'CISD_CONFIRMED';
                        }
                    } else if (bias === 'BEARISH') {
                        // CISD confirmed when a strictly CLOSED M15 candle closes BELOW the LOCKED prior structure level
                        const cisdCandle = candles.find(c => c.time > st.sweepTime && c.time <= candles[candles.length - 2].time && c.close < st.cisdReferenceLevel);
                        if (cisdCandle) {
                            st.stage = 'CISD_CONFIRMED';
                        }
                    }
                } else {
                    // Sweep candle aged out of array, reset state
                    st.stage = 'WAITING_FOR_SWEEP';
                }
            }

            m15Swept = (st.stage === 'WAITING_FOR_CISD' || st.stage === 'CISD_CONFIRMED');
            m15CISD = (st.stage === 'CISD_CONFIRMED');

            this.telemetry.m15 = {
                liquiditySweep: m15Swept ? 'FOUND' : 'NOT FOUND',
                cisd: m15CISD ? 'CONFIRMED' : 'WAITING',
                swingHigh: recentSwingHigh,
                swingLow: recentSwingLow,
                targetHigh: currentCandle.high,
                targetLow: currentCandle.low,
                candleCount: data.m15Candles.length,
                lastCandleTime: new Date(currentCandle.time).toISOString()
            };
        } else {
            this.telemetry.m15 = {
                liquiditySweep: 'WAITING',
                cisd: 'WAITING',
                swingHigh: 0,
                swingLow: 0,
                targetHigh: 0,
                targetLow: 0,
                candleCount: data.m15Candles?.length || 0
            };
        }

        if (!m15Swept || !m15CISD) {
            this.telemetry.m1 = {
                displacement: 'WAITING',
                orderBlock: 'WAITING',
                fvg: 'WAITING',
                retracement: 'WAITING',
                obZone: null,
                fvgZone: null,
                candleCount: data.m1Candles?.length || 0,
                lastCandleTime: data.m1Candles?.length ? new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString() : undefined
            };

            this.telemetry.entryStatus = 'WAITING';
            this.telemetry.waitingReason = !m15Swept ? '⏳ WAITING FOR M15 LIQUIDITY SWEEP' : '⏳ WAITING FOR M15 CISD CONFIRMATION';
            this.telemetry.validSetup = null;

            // Add concise cycle logs
            this.addAnalysisLog(`H4 Bias (និន្នាការធំ) = ${bias} (Close: ${lastH4Candle?.close || 0} | Open: ${lastH4Candle?.open || 0})`, 'info');
            this.addAnalysisLog(`M15 Liquidity Sweep = ${m15Swept ? 'FOUND / រកឃើញហើយ' : 'WAITING / កំពុងរង់ចាំ'} (Swing ${bias === 'BEARISH' ? 'High' : 'Low'}: ${bias === 'BEARISH' ? st.swingHigh : st.swingLow})`, m15Swept ? 'success' : 'warn');
            this.addAnalysisLog(`M15 CISD = ${m15CISD ? 'CONFIRMED' : 'WAITING / កំពុងរង់ចាំ'}`, m15CISD ? 'success' : (m15Swept ? 'warn' : 'info'));
            this.addAnalysisLog(`M1 = LOCKED / ជាប់សោរ (Awaiting M15 Sweep & CISD)`, 'info');
            this.addAnalysisLog(`ENTRY = WAITING (${this.telemetry.waitingReason})`, 'info');
            return;
        }
        // M15 Swept & CISD Confirmed
        this.addAnalysisLog(`M15 Liquidity Sweep = FOUND / រកឃើញហើយ (${bias === 'BEARISH' ? 'Buy-Side' : 'Sell-Side'} Liquidity Swept)`, 'success');
        this.addAnalysisLog(`M15 CISD = CONFIRMED / ត្រូវបានបញ្ជាក់ច្បាស់លាស់`, 'success');

        // M1 Confirmation
        let m1Confirmed = false;
        if (data.m1Candles && data.m1Candles.length > 0) {
            const lastM1 = data.m1Candles[data.m1Candles.length - 1];
            if (bias === 'BULLISH' && lastM1.close > lastM1.open) m1Confirmed = true;
            if (bias === 'BEARISH' && lastM1.close < lastM1.open) m1Confirmed = true;
        }

        if (!m1Confirmed) {
            this.telemetry.m1 = {
                displacement: 'WAITING',
                orderBlock: 'WAITING',
                fvg: 'WAITING',
                retracement: 'WAITING',
                obZone: null,
                fvgZone: null,
                candleCount: data.m1Candles?.length || 0,
                lastCandleTime: data.m1Candles?.length ? new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString() : undefined
            };
            this.telemetry.entryStatus = 'WAITING';
            this.telemetry.waitingReason = '⏳ WAITING FOR M1 CONFIRMATION / រង់ចាំ M1 បញ្ជាក់ទិសដៅ';
            this.telemetry.validSetup = null;
            this.addAnalysisLog(`M1 = WAITING / កំពុងរង់ចាំបញ្ជាក់ទិសដៅ (${bias})`, 'warn');
            return;
        }
        this.addAnalysisLog(`M1 = CONFIRMED / ត្រូវបានបញ្ជាក់ទិសដៅ (${bias})`, 'success');
		this.telemetry.m1 = {
			displacement: 'FOUND',
			orderBlock: 'CONFIRMED',
			fvg: 'CONFIRMED',
			retracement: 'CONFIRMED',
			obZone: null,
			fvgZone: null,
			candleCount: data.m1Candles?.length || 0,
			lastCandleTime: data.m1Candles?.length ? new Date(data.m1Candles[data.m1Candles.length-1].time).toISOString() : undefined
		};



        const setupId = `${this.config.symbol}-${bias}-M15Sweep-${m15_3.time}`;
        
        if (this.state.executedSetupIds.has(setupId)) {
            return;
        }

        // ENTRY: LOCKED based on M15 Swing
        const entryEst = bias === 'BULLISH' ? m15_1.low : m15_1.high; 
        
        // SINGLE SOURCE OF TRUTH: User Settings distances
        let slEst = bias === 'BULLISH' ? (entryEst - this.config.stopLossDistance) : (entryEst + this.config.stopLossDistance);
        let tpEst = bias === 'BULLISH' ? (entryEst + this.config.takeProfitDistance) : (entryEst - this.config.takeProfitDistance);

        const riskEst = Math.abs(entryEst - slEst);
        const rewardEst = Math.abs(tpEst - entryEst);
        const rrEst = riskEst > 0 ? rewardEst / riskEst : 0;

        this.state.currentSetup = {
            id: setupId,
            stage: 'WAITING',
            bias: bias,
            lockedEntryPrice: entryEst,
            h4BiasConfirmed: true,
            m15LiquiditySwept: true,
            m15CISDConfirmed: true,
            lockedSlTarget: slEst,
            lockedTpTarget: tpEst,
            firstTouch: 'NONE',
            creationTime: data.serverTime,
            expirationTime: data.serverTime + (4 * 3600000), // 4 hours
            confirmationAlertSent: true,
            obHigh: entryEst,
            obLow: entryEst,
            fvgHigh: entryEst,
            fvgLow: entryEst,
            m1DisplacementConfirmed: true,
            m1OBConfirmed: true,
            m1FVGConfirmed: true,
            retracementConfirmed: true
        };

        if (this.onSetupConfirmed) {
            this.onSetupConfirmed({
                symbol: data.symbol || this.config.symbol,
                direction: bias === 'BULLISH' ? 'BUY' : 'SELL',
                entryZone: { low: entryEst, high: entryEst },
                actualEntry: entryEst,
                sl: slEst,
                tp: tpEst,
                rr: Number(rrEst.toFixed(2)),
                status: '⏳ FULL SETUP READY - WAITING FOR ENTRY'
            });
        }

        this.telemetry.entryStatus = 'VALID SETUP';
        this.telemetry.waitingReason = '⏳ FULL SETUP READY — WAITING FOR ENTRY / រង់ចាំតម្លៃមកដល់ Entry';
        
        this.telemetry.validSetup = {
            direction: bias === 'BULLISH' ? 'BUY' : 'SELL',
            entry: entryEst,
            actualEntry: entryEst,
            sl: slEst,
            tp: tpEst,
            rr: Number(rrEst.toFixed(2)),
            setupId: setupId,
            stage: 'WAITING',
            executionState: undefined,
            obHigh: entryEst,
            obLow: entryEst
        };
        
        this.log(`SEQUENCE COMPLETE: Valid ${bias} Setup. Locked Entry: ${entryEst} | SL: ${slEst} | TP: ${tpEst} (RR: ${rrEst.toFixed(2)}). Stage -> WAITING`);
        this.addAnalysisLog(`FULL SETUP READY | Locked Entry = ${entryEst}`, 'success');
        this.addAnalysisLog(`Structural SL = ${slEst} | Locked ICT TP = ${tpEst} (RR: ${rrEst.toFixed(2)})`, 'info');
        this.addAnalysisLog(`ENTRY = VALID SETUP / រកឃើញកន្លែងចូល (⏳ WAITING FOR ENTRY TOUCH / រង់ចាំតម្លៃប៉ះ Entry)`, 'success');
    }

    private async executeTrade(data: ICTMarketData) {
        const s = this.state.currentSetup!;
        
        if (this.state.executedSetupIds.has(s.id)) {
            this.log("REJECT: Duplicate Setup ID execution prevented.");
            s.executionState = 'REJECTED: DUPLICATE_SETUP';
            s.stage = 'REJECTED';
            this.state.executedSetupIds.add(s.id);
            return;
        }
        
        // Restart Recovery: Check if there's already an open position with this setup ID
        if (this.state.openPositions.some(p => p.setupId === s.id)) {
            this.log("REJECT: Position for this setup already exists (survived restart).");
            this.state.executedSetupIds.add(s.id); // Re-sync
            s.executionState = 'REJECTED: POSITION_EXISTS';
            s.stage = 'REJECTED';
            this.state.executedSetupIds.add(s.id);
            return;
        }

        let sl = 0;
        let tp = 0;
        let entry = 0;

        if (s.bias === 'BULLISH') {
            entry = s.lockedEntryPrice || data.ask;
            sl = s.lockedSlTarget || (entry - this.config.stopLossDistance);
            tp = s.lockedTpTarget || (entry + this.config.takeProfitDistance);
            
            this.log(`SETUP READY FOR EXECUTION: BUY ${this.config.symbol} | Locked Entry: ${entry} | Locked SL: ${sl} | Locked TP: ${tp} | Setup: ${s.id}`);
            
            if (this.LIVE_TRADING_ENABLED) {
                try {
                    const t0 = new Date().toISOString();
                    this.log(`\n[ORDER DISPATCH]\nORDER FUNCTION CALLED`);
                    this.log(`[${t0}] EXECUTION TRIGGERED`);
                    this.log(`[${new Date().toISOString()}] METAAPI REQUEST SENT`);
                    
                    const tStart = Date.now();
                    const ticket = await this.execution.executeBuy(this.config.symbol, this.config.lotSize, sl, tp, 999, entry);
                    const tEnd = Date.now();
                    
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED | Latency: ${tEnd - tStart}ms`);
                    this.log(`BROKER RESPONSE: SUCCESS\nPOSITION TICKET: ${ticket}`);
                    this.log(`[${new Date().toISOString()}] 🟢 POSITION OPENED`);
                    s.stage = 'EXECUTED';
                    s.executionTicket = ticket;
                    if (this.onExecutionSuccess) {
                        this.onExecutionSuccess({
                            setupId: s.id,
                            symbol: this.config.symbol,
                            direction: 'BUY',
                            entry: entry,
                            sl: sl,
                            tp: tp,
                            lot: this.config.lotSize,
                            ticket: ticket
                        });
                    }
                } catch (e: any) {
                    const tEnd = Date.now();
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED`);
                    this.log(`BROKER RESPONSE: ERROR - ${e.message}`);
                    s.stage = 'REJECTED';
                    if (this.onExecutionFailed) {
                        this.onExecutionFailed({ setupId: s.id, reason: e.message });
                    }
                }
            } else {
                const reason = this.liveTradingBlockReason || 'BLOCKED_BY_SAFETY_SYSTEM';
                this.log(`[BLOCKED] Valid setup reached entry but LIVE TRADING is disabled. Reason: ${reason}`);
                s.stage = 'REJECTED';
            }
            this.state.executedSetupIds.add(s.id);
        }
        else if (s.bias === 'BEARISH') {
            entry = s.lockedEntryPrice || data.bid;
            sl = s.lockedSlTarget || (entry + this.config.stopLossDistance);
            tp = s.lockedTpTarget || (entry - this.config.takeProfitDistance);
            
            this.log(`SETUP READY FOR EXECUTION: SELL ${this.config.symbol} | Locked Entry: ${entry} | Locked SL: ${sl} | Locked TP: ${tp} | Setup: ${s.id}`);
            
            if (this.LIVE_TRADING_ENABLED) {
                try {
                    const t0 = new Date().toISOString();
                    this.log(`\n[ORDER DISPATCH]\nORDER FUNCTION CALLED`);
                    this.log(`[${t0}] EXECUTION TRIGGERED`);
                    this.log(`[${new Date().toISOString()}] METAAPI REQUEST SENT`);
                    
                    const tStart = Date.now();
                    const ticket = await this.execution.executeSell(this.config.symbol, this.config.lotSize, sl, tp, 999, entry);
                    const tEnd = Date.now();
                    
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED | Latency: ${tEnd - tStart}ms`);
                    this.log(`BROKER RESPONSE: SUCCESS\nPOSITION TICKET: ${ticket}`);
                    this.log(`[${new Date().toISOString()}] 🟢 POSITION OPENED`);
                    s.stage = 'EXECUTED';
                    s.executionTicket = ticket;
                    if (this.onExecutionSuccess) {
                        this.onExecutionSuccess({
                            setupId: s.id,
                            symbol: this.config.symbol,
                            direction: 'SELL',
                            entry: entry,
                            sl: sl,
                            tp: tp,
                            lot: this.config.lotSize,
                            ticket: ticket
                        });
                    }
                } catch (e: any) {
                    const tEnd = Date.now();
                    this.log(`[${new Date(tEnd).toISOString()}] METAAPI RESPONSE RECEIVED`);
                    this.log(`BROKER RESPONSE: ERROR - ${e.message}`);
                    s.stage = 'REJECTED';
                    if (this.onExecutionFailed) {
                        this.onExecutionFailed({ setupId: s.id, reason: e.message });
                    }
                }
            } else {
                const reason = this.liveTradingBlockReason || 'BLOCKED_BY_SAFETY_SYSTEM';
                this.log(`[BLOCKED] Valid setup reached entry but LIVE TRADING is disabled. Reason: ${reason}`);
                s.stage = 'REJECTED';
            }
            this.state.executedSetupIds.add(s.id);
        }
        this.log(`========================================\n`);
    }

    public calculateAdaptiveBuffer(
        spread: number,
        m1Candles: Candle[],
        tpDistance: number = 0
    ): { buffer: number; volatility: number; spreadPts: number } {
        let volatility = 1.0;
        if (m1Candles && m1Candles.length >= 2) {
            const lookback = Math.min(14, m1Candles.length);
            const slice = m1Candles.slice(-lookback);
            let trSum = 0;
            for (let i = 1; i < slice.length; i++) {
                const tr = Math.max(
                    slice[i].high - slice[i].low,
                    Math.abs(slice[i].high - slice[i - 1].close),
                    Math.abs(slice[i].low - slice[i - 1].close)
                );
                trSum += tr;
            }
            volatility = trSum / (slice.length - 1);
        }

        const spreadPts = spread > 0 ? spread : 0.3;
        const minStopDistance = 0.5;
        const spreadComponent = spreadPts * 2.0;
        const volComponent = volatility * 0.5;
        const rawBuffer = Math.max(minStopDistance, spreadComponent, volComponent);

        let buffer = Math.min(2.5, Math.max(0.8, rawBuffer));
        if (tpDistance > 0) {
            buffer = Math.min(buffer, tpDistance * 0.3);
        }

        buffer = Number(buffer.toFixed(3));
        volatility = Number(volatility.toFixed(3));
        const spreadRounded = Number(spreadPts.toFixed(3));

        return { buffer, volatility, spreadPts: spreadRounded };
    }

    public evaluateTrailingSL(
        tradeId: string, 
        side: 'BUY' | 'SELL', 
        entryPrice: number, 
        currentSl: number, 
        currentPrice: number,
        initialSlDistance: number,
        m1Candles: Candle[],
        originalTp?: number,
        spread: number = 0.3
    ): number | null {
        // Standard Trailing SL before TP (Swing Structure Trailing at >= 1R)
        if (!m1Candles || m1Candles.length < 15) return null;
        
        const profit = side === 'BUY' ? (currentPrice - entryPrice) : (entryPrice - currentPrice);
        
        // Wait until at least 1R profit to start trailing (Break-Even or Trail)
        if (profit < initialSlDistance) return null;

        // Find recent swing point on M1 (last 10 candles)
        const recentCandles = m1Candles.slice(-10);
        
        if (side === 'BUY') {
            // Find recent swing low
            const recentLow = Math.min(...recentCandles.map(c => c.low));
            const potentialSl = recentLow - 1.0; // 10 ticks buffer below structure
            
            // Only move UP, never DOWN. Must not increase risk.
            if (potentialSl > currentSl && potentialSl < currentPrice) {
                return potentialSl;
            }
        } else {
            // Find recent swing high
            const recentHigh = Math.max(...recentCandles.map(c => c.high));
            const potentialSl = recentHigh + 1.0; // 10 ticks buffer above structure
            
            // Only move DOWN, never UP. Must not increase risk.
            if ((currentSl === 0 || potentialSl < currentSl) && potentialSl > currentPrice) {
                return potentialSl;
            }
        }
        
        return null;
    }

}
