import React, { useState, useEffect, useRef } from 'react';
import { X, Settings, Shield, Clock, Server, CheckCircle2, Save, AlertCircle } from 'lucide-react';
import { BotState } from '../types';
import { botApi } from '../services/api';

interface BotSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  botState: BotState;
  onSaveSuccess?: () => void;
}

export function BotSettingsModal({
  isOpen,
  onClose,
  botState,
  onSaveSuccess
}: BotSettingsModalProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);

  // Form states
  const [lotSize, setLotSize] = useState('0.05');
  const [slDist, setSlDist] = useState('100');
  const [tpDist, setTpDist] = useState('80');
  const [dailyLoss, setDailyLoss] = useState('2000');
  const [maxTrades, setMaxTrades] = useState('4');
  const [additionalEntryDistance, setAdditionalEntryDistance] = useState('4.0');
  const [maxConsSL, setMaxConsSL] = useState('6');
  const [cooldown, setCooldown] = useState('20');
  const [maxSpread, setMaxSpread] = useState('27');
  const [newsFilterEnabled, setNewsFilterEnabled] = useState(true);
  const [newsMinsBefore, setNewsMinsBefore] = useState('30');
  const [newsMinsAfter, setNewsMinsAfter] = useState('30');

  const hasInitialized = useRef(false);

  // Load initial from botState
  useEffect(() => {
    if (isOpen) {
      if (botState?.riskConfig && !hasInitialized.current) {
        if (botState.riskConfig.lotSize !== undefined) setLotSize(String(botState.riskConfig.lotSize));
        if (botState.riskConfig.stopLossPips !== undefined) setSlDist(String(botState.riskConfig.stopLossPips));
        if (botState.riskConfig.takeProfitPips !== undefined) setTpDist(String(botState.riskConfig.takeProfitPips));
        if (botState.riskConfig.maxDailyLossAmount !== undefined) setDailyLoss(String(botState.riskConfig.maxDailyLossAmount));
        if (botState.riskConfig.maxOpenTrades !== undefined) setMaxTrades(String(botState.riskConfig.maxOpenTrades));
        if ((botState.riskConfig as any).additionalEntryDistance !== undefined) setAdditionalEntryDistance(String((botState.riskConfig as any).additionalEntryDistance));
        if (botState.riskConfig.maxConsecutiveLosses !== undefined) setMaxConsSL(String(botState.riskConfig.maxConsecutiveLosses));
        if (botState.riskConfig.cooldownMinutes !== undefined) setCooldown(String(botState.riskConfig.cooldownMinutes));
        if (botState.riskConfig.maxSpreadPoints !== undefined) setMaxSpread(String(botState.riskConfig.maxSpreadPoints));
        if (botState.riskConfig.newsFilterEnabled !== undefined) setNewsFilterEnabled(Boolean(botState.riskConfig.newsFilterEnabled));
        if (botState.riskConfig.minutesBeforeNewsBlock !== undefined) setNewsMinsBefore(String(botState.riskConfig.minutesBeforeNewsBlock));
        if (botState.riskConfig.minutesAfterNewsBlock !== undefined) setNewsMinsAfter(String(botState.riskConfig.minutesAfterNewsBlock));
        setSuccessMsg(false);
        setErrorMsg('');
        hasInitialized.current = true;
      }
    } else {
      hasInitialized.current = false;
    }
  }, [isOpen, botState]);

  if (!isOpen) return null;

  const handleSave = async () => {
    setIsSaving(true);
    setErrorMsg('');
    setSuccessMsg(false);

    try {
      const parsedLot = Number(lotSize);
      const parsedSl = Number(slDist);
      const parsedTp = Number(tpDist);
      const parsedDailyLoss = Number(dailyLoss);
      const parsedTrades = Number(maxTrades);
      const parsedConsSl = Number(maxConsSL);
      const parsedCooldown = Number(cooldown);
      const parsedSpread = Number(maxSpread);
      const parsedNewsBefore = Number(newsMinsBefore);
      const parsedNewsAfter = Number(newsMinsAfter);

      if (isNaN(parsedLot) || parsedLot <= 0) throw new Error('Lot size មិនត្រឹមត្រូវ (ត្រូវធំជាង 0)');
      if (isNaN(parsedSl) || parsedSl <= 0) throw new Error('Stop Loss (Points) មិនត្រឹមត្រូវ (ត្រូវធំជាង 0)');
      if (isNaN(parsedTp) || parsedTp <= 0) throw new Error('Take Profit (Points) មិនត្រឹមត្រូវ (ត្រូវធំជាង 0)');

      await botApi.updateRiskConfig({
        lotSize: parsedLot,
        stopLossPips: parsedSl,
        takeProfitPips: parsedTp,
        maxDailyLossAmount: parsedDailyLoss,
        maxOpenTrades: parsedTrades,
        additionalEntryDistance: Number(additionalEntryDistance) || 4.0,
        maxConsecutiveLosses: parsedConsSl,
        cooldownMinutes: parsedCooldown,
        maxSpreadPoints: parsedSpread,
        trailingStopEnabled: true, // DaRa Auto Trailing strictly preserved and active
        newsFilterEnabled: Boolean(newsFilterEnabled),
        minutesBeforeNewsBlock: parsedNewsBefore,
        minutesAfterNewsBlock: parsedNewsAfter,
      });
      setSuccessMsg(true);
      if (onSaveSuccess) onSaveSuccess();
      setTimeout(() => setSuccessMsg(false), 3000);
    } catch (e: any) {
      setErrorMsg(e.message || 'Save failed');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/60 bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
              <Settings size={20} className="text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">USER TRADING SETTINGS</h2>
              <p className="text-xs text-slate-400">អ្នកជាអ្នកកំណត់ការគ្រប់គ្រងទាំងស្រុង (Single Source of Truth)</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex items-start gap-3">
            <Shield className="text-amber-400 shrink-0 mt-0.5" size={18} />
            <div className="text-sm text-amber-200/90 leading-relaxed">
              <strong>User Controlled Configuration:</strong> រាល់តម្លៃដែលអ្នកបញ្ចូលទីនេះ នឹងត្រូវបាន Save និងប្រើប្រាស់ដោយផ្ទាល់ពី EA ។ EA នឹងមិនមានការ Override ដោយ Backend ឡើយ។
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* LOT SIZE */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Lot Size / ទំហំ Lot</label>
              <input 
                type="number" step="0.01" min="0.01" max="200.00"
                value={lotSize} onChange={(e) => setLotSize(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* MAX OPEN TRADES */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Max Open Trades / ចំនួន Trade អតិបរមា</label>
              <input 
                type="number" step="1" min="1"
                value={maxTrades} onChange={(e) => setMaxTrades(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* ADDITIONAL ENTRY DISTANCE */}
            <div className="bg-slate-800/30 border border-blue-900/40 bg-blue-950/10 rounded-xl p-4">
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs text-blue-300 font-semibold">Additional Entry (Raw Price) / ចម្ងាយថែម Trade</label>
                <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">Scale-in</span>
              </div>
              <input 
                type="number" step="0.1" min="0.1"
                value={additionalEntryDistance} onChange={(e) => setAdditionalEntryDistance(e.target.value)}
                placeholder="4.0"
                className="w-full bg-slate-900 border border-blue-600/50 focus:border-blue-400 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
              <p className="text-[10px] text-slate-400 mt-1">បើក Trade បន្ថែមនៅពេលតម្លៃដើរខុស 4.0$ (Max Trades ត្រូវ ≥ 2)</p>
            </div>

            {/* SL DISTANCE */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Stop Loss (Price Distance) / ចម្ងាយកាត់ខាតតម្លៃផ្ទាល់</label>
              <input 
                type="number" step="any" min="0.01"
                value={slDist} onChange={(e) => setSlDist(e.target.value)}
                placeholder="10"
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* TP DISTANCE */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Take Profit (Price Distance) / ចម្ងាយយកចំណេញតម្លៃផ្ទាល់</label>
              <input 
                type="number" step="any" min="0.01"
                value={tpDist} onChange={(e) => setTpDist(e.target.value)}
                placeholder="10"
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* DAILY LOSS LIMIT */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Daily Loss Limit (USC) / ដែនកំណត់ខាតប្រចាំថ្ងៃ</label>
              <input 
                type="number" step="10" min="0"
                value={dailyLoss} onChange={(e) => setDailyLoss(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* MAX CONSECUTIVE SL */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Max Consecutive SL / ខាតជាប់គ្នាអតិបរមា</label>
              <input 
                type="number" step="1" min="1"
                value={maxConsSL} onChange={(e) => setMaxConsSL(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* MAX SPREAD */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4">
              <label className="block text-xs text-slate-400 mb-1">Max Spread (Points) / គម្លាតទីផ្សារអតិបរមា</label>
              <input 
                type="number" step="1" min="1"
                value={maxSpread} onChange={(e) => setMaxSpread(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

            {/* COOLDOWN */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-xl p-4 md:col-span-2">
              <label className="block text-xs text-slate-400 mb-1">Cooldown After SL (Minutes) / ផ្អាកបន្ទាប់ពីខាត (20 នាទី)</label>
              <input 
                type="number" step="1" min="0"
                value={cooldown} onChange={(e) => setCooldown(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
              />
            </div>

          </div>

          {/* NEWS FILTER SETTINGS SECTION */}
          <div className="bg-slate-800/20 border border-slate-800 rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">News Filter Settings (ការកំណត់តម្រងព័ត៌មាន)</h3>
                <p className="text-xs text-slate-400">ផ្អាកបើក Trade ស្វ័យប្រវត្តិកំឡុងពេលព័ត៌មានធំ (High-Impact USD/Gold News)</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={newsFilterEnabled} 
                  onChange={(e) => setNewsFilterEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {newsFilterEnabled && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-800/60">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Minutes Before News / នាទីផ្អាកមុនព័ត៌មានចេញ</label>
                  <input 
                    type="number" step="1" min="0"
                    value={newsMinsBefore} onChange={(e) => setNewsMinsBefore(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Minutes After News / នាទីផ្អាកក្រោយព័ត៌មានចេញ</label>
                  <input 
                    type="number" step="1" min="0"
                    value={newsMinsAfter} onChange={(e) => setNewsMinsAfter(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 focus:border-blue-500 text-white rounded-lg px-3 py-2 text-sm font-mono focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400 flex items-center gap-2">
              <AlertCircle size={14} /> {errorMsg}
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
              <CheckCircle2 size={14} /> Settings Saved Successfully!
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/60 bg-slate-900 flex justify-between items-center">
          <button 
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition-colors"
          >
            Cancel / បោះបង់
          </button>
          
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Save size={16} />
            )}
            Save Configuration / រក្សាទុក
          </button>
        </div>
      </div>
    </div>
  );
}
