/**
 * ============================================================================
 * 🔥 DaRa M1 EA v1.0 — PRIMARY ENGINE (DaRaM1Engine)
 * 100% INDEPENDENT PRIMARY M1 ENGINE
 * 
 * Flow:
 * M1 MARKET -> SWEEP -> DISPLACEMENT -> MSS -> FULL SETUP READY -> LOCK ENTRY ->
 * WAIT FOR LOCKED ENTRY -> ENTRY REACHED -> EXECUTE ORDER -> BROKER CONFIRMATION ->
 * TRADE ACTIVE -> PROFIT TRAILING -> TP / SL / TRAILING STOP -> TRADE CLOSED ->
 * SCAN NEW SETUP 24/7
 * 
 * Rules:
 * - Timeframe: M1 ONLY
 * - User Settings = Single Source of Truth
 * - Fast Entry Mode: No unnecessary secondary timeframes
 * - Pending Setup Cancellation (Virtual TP/SL reached before entry = CANCEL & SCAN NEW)
 * - Strict Monotonic Profit Trailing (Up only for BUY, Down only for SELL)
 * - Safe 24/7 START / STOP (STOP never kills open trades or removes SL/TP)
 * ============================================================================
 */

import {
  DaRaBrokerInterface,
  DaRaMarketFeed,
  DaRaPosition,
  DaRaSafetyStatus,
  DaRaSetup,
  DaRaState,
  DaRaTelegramInterface,
  DaRaUserSettings,
  DaRaAnalysisDetails,
  DaRaTelemetry,
  DaRaClosedTrade,
  DaRaExitReason
} from './types';
import { DaRaM1Strategy } from './DaRaM1Strategy';
import { DaRaM1StateMachine } from './DaRaM1StateMachine';
import { DaRaOrderExecution } from './DaRaOrderExecution';
import { DaRaProfitTrailing } from './DaRaProfitTrailing';

export class DaRaM1Engine {
  public readonly name = 'DaRa M1 EA v1.0';

  private strategy: DaRaM1Strategy;
  private stateMachine: DaRaM1StateMachine;
  private execution: DaRaOrderExecution;
  private trailing: DaRaProfitTrailing;
  private broker: DaRaBrokerInterface;
  private telegram?: DaRaTelegramInterface;

  private userSettings: DaRaUserSettings;
  private isRunning: boolean = false;

  // Real Risk & Tracking Counters
  private dailyLossAccumulated: number = 0;
  private consecutiveLossCount: number = 0;
  private lastLossTime: number = 0;
  private isNewsBlockedNow: boolean = false;
  private isMt5ConnectedNow: boolean = true;
  private cachedPointSize: number = 0;
  private lastAnalysis: DaRaAnalysisDetails | null = null;
  private closedTicketsSet: Set<string> = new Set<string>();

  constructor(
    broker: DaRaBrokerInterface,
    initialSettings: DaRaUserSettings,
    telegram?: DaRaTelegramInterface
  ) {
    this.broker = broker;
    this.userSettings = { liveTradingEnabled: false, ...initialSettings };
    this.telegram = telegram;

    this.strategy = new DaRaM1Strategy();
    this.stateMachine = new DaRaM1StateMachine();
    this.execution = new DaRaOrderExecution(broker, telegram);
    this.trailing = new DaRaProfitTrailing();

    console.log(`[DaRa M1 EA v1.0] 🔥 Engine initialized successfully. (Status: IDLE)`);
  }

  // ==========================================
  // USER CONTROL & SETTINGS (24/7 START / STOP)
  // ==========================================

  public updateUserSettings(newSettings: Partial<DaRaUserSettings>): void {
    const oldMax = this.userSettings?.maxOpenTrades;
    this.userSettings = { ...this.userSettings, ...newSettings };
    console.log(`[DaRa M1 EA v1.0] ⚙️ User Settings updated. [DARA CONFIG TRACE] oldMaxOpenTrades=${oldMax} newMaxOpenTrades=${this.userSettings.maxOpenTrades}`, this.userSettings);
  }

  public getUserSettings(): DaRaUserSettings {
    return { ...this.userSettings };
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.stateMachine.onUserStart();
    console.log(`[DaRa M1 EA v1.0] 🟢 START initiated by User. 24/7 M1 Market Scanning ACTIVE.`);
    if (this.telegram) {
      this.telegram.notify(
        `🔥 DaRa M1 EA v1.0 — STARTED`,
        `DaRa M1 EA ត្រូវបាន START ដោយជោគជ័យ! ប្រព័ន្ធកំពុងស្កេនរក M1 Setup 24/7...`
      ).catch(() => {});
    }
  }

  public stop(): void {
    if (!this.isRunning) return;
    this.isRunning = false;
    this.stateMachine.onUserStop();
    console.log(`[DaRa M1 EA v1.0] 🔴 STOP initiated by User. New scanning and pending entries halted.`);
    console.log(`[DaRa M1 EA v1.0] 🛡️ Note: Any active broker trade continues to be protected by Hard SL/TP and Profit Trailing.`);
    if (this.telegram) {
      this.telegram.notify(
        `🔥 DaRa M1 EA v1.0 — STOPPED`,
        `DaRa M1 EA ត្រូវបាន STOP — ការស្កេន និងបើក Order ថ្មីត្រូវបានផ្អាក។ Trade ដែលកំពុងបើកនៅតែមាន SL/TP ការពារដដែល។`
      ).catch(() => {});
    }
  }

  public forceCloseAllAndStop(): void {
    this.isRunning = false;
    this.stateMachine.reset();
    console.log(`[DaRa M1 EA v1.0] 🛑 CLOSE ALL executed. All setups cancelled, positions cleared, engine STOPPED.`);
    if (this.telegram) {
      this.telegram.notify(
        `🛑 DaRa M1 EA v1.0 — CLOSE ALL TRADES`,
        `បានបិទរាល់ Position ទាំងអស់របស់ Bot, Cancel Pending Setup និងបញ្ឈប់ Bot ដោយជោគជ័យ។ Bot នឹងមិនដំណើរការឡើងវិញដោយខ្លួនឯងទេរហូតដល់ចុច START BOT។`
      ).catch(() => {});
    }
  }

  public getIsRunning(): boolean {
    return this.isRunning;
  }

  public getState(): DaRaState {
    return this.stateMachine.getState();
  }

  public getCurrentSetup(): DaRaSetup | null {
    return this.stateMachine.getSetup();
  }

  public getActivePosition(): DaRaPosition | null {
    return this.stateMachine.getActivePosition();
  }


  public getTelemetry(currentSpreadPoints: number = 0, currentOpenTradesCount: number = 0): DaRaTelemetry {
    const safety = this.evaluateSafety(currentSpreadPoints, currentOpenTradesCount);
    return {
      isRunning: this.isRunning,
      state: this.stateMachine.getState(),
      setup: this.stateMachine.getSetup(),
      activePosition: this.stateMachine.getActivePosition(),
      lastClosedTrade: this.stateMachine.getLastClosedTrade(),
      safety,
      analysis: this.lastAnalysis,
      settings: { ...this.userSettings },
      cachedPointSize: this.cachedPointSize,
      dailyLossAccumulated: this.dailyLossAccumulated,
      consecutiveLossCount: this.consecutiveLossCount,
      lastLossTime: this.lastLossTime,
    };
  }

  // ==========================================
  // SAFETY EVALUATION PIPELINE
  // ==========================================

  public evaluateSafety(currentSpreadPoints: number, currentOpenTradesCount: number): DaRaSafetyStatus {
    const s = this.userSettings;
    const now = Date.now();

    const isDailyLossHit = this.dailyLossAccumulated >= s.dailyLossLimit;
    const isMaxConsecutiveSLHit = this.consecutiveLossCount >= s.maxConsecutiveSL;
    
    // Cooldown check
    const cooldownMs = s.cooldownMinutes * 60 * 1000;
    const isInCooldown = this.lastLossTime > 0 && (now - this.lastLossTime) < cooldownMs;

    const isSpreadTooHigh = currentSpreadPoints > s.maxSpreadPoints;
    const isNewsBlocked = s.newsFilterEnabled && this.isNewsBlockedNow;
    const rawMax = Number(s.maxOpenTrades);
    const maxPositions = isNaN(rawMax) ? 5 : Math.max(1, Math.min(5, Math.floor(rawMax)));
    const isMaxTradesReached = currentOpenTradesCount >= maxPositions;
    const isMt5Disconnected = !this.isMt5ConnectedNow;

    let blockedReason: string | undefined;
    if (isMt5Disconnected) blockedReason = 'MT5 Server or MetaApi Disconnected';
    else if (isDailyLossHit) blockedReason = `Daily Loss Limit reached (${this.dailyLossAccumulated.toFixed(2)} >= ${s.dailyLossLimit})`;
    else if (isMaxConsecutiveSLHit) blockedReason = `Max Consecutive SL hit (${this.consecutiveLossCount} >= ${s.maxConsecutiveSL})`;
    else if (isInCooldown) blockedReason = `Loss Cooldown Active (${Math.ceil((cooldownMs - (now - this.lastLossTime)) / 60000)}m remaining)`;
    else if (isSpreadTooHigh) blockedReason = `Spread too high (${currentSpreadPoints} > ${s.maxSpreadPoints})`;
    else if (isNewsBlocked) blockedReason = `High Impact News Filter Active`;
    else if (isMaxTradesReached) blockedReason = `Max Positions reached (${currentOpenTradesCount} >= ${maxPositions})`;

    const isSafeToTrade = !blockedReason;

    return {
      isSafeToTrade,
      blockedReason,
      isDailyLossHit,
      isMaxConsecutiveSLHit,
      isInCooldown,
      isSpreadTooHigh,
      isNewsBlocked,
      isMaxTradesReached,
      isMt5Disconnected
    };
  }

  public setNewsBlockedStatus(isBlocked: boolean): void {
    this.isNewsBlockedNow = isBlocked;
  }

  public setMt5ConnectionStatus(isConnected: boolean): void {
    this.isMt5ConnectedNow = isConnected;
  }

  public recordRealTradeResult(profitOrLoss: number): void {
    if (profitOrLoss < 0) {
      const loss = Math.abs(profitOrLoss);
      this.dailyLossAccumulated += loss;
      this.consecutiveLossCount += 1;
      this.lastLossTime = Date.now();
      console.log(`[DaRa M1 EA v1.0] ⚠️ Real Loss Recorded: -${loss.toFixed(2)} USC | Daily Loss Total: ${this.dailyLossAccumulated.toFixed(2)} USC | Consecutive Losses: ${this.consecutiveLossCount}`);
    } else {
      this.consecutiveLossCount = 0; // Reset consecutive loss streak on win
      console.log(`[DaRa M1 EA v1.0] 🎉 Real Win Recorded: +${profitOrLoss.toFixed(2)} USC | Consecutive Losses Reset to 0`);
    }
  }

  public resetDailyLoss(): void {
    this.dailyLossAccumulated = 0;
    this.consecutiveLossCount = 0;
    this.lastLossTime = 0;
    console.log(`[DaRa M1 EA v1.0] 🔄 Daily Loss and Consecutive Loss counters reset.`);
  }

  public clearCooldown(): void {
    this.lastLossTime = 0;
    console.log(`[DaRa M1 EA v1.0] 🔄 Cooldown reset by user/admin.`);
  }

  public clearConsecutiveSL(): void {
    this.consecutiveLossCount = 0;
    console.log(`[DaRa M1 EA v1.0] 🔄 Consecutive SL counter reset to 0 by user/admin.`);
  }

  public clearDailyLossLimit(): void {
    this.dailyLossAccumulated = 0;
    console.log(`[DaRa M1 EA v1.0] 🔄 Daily loss accumulated reset to 0 by user/admin.`);
  }

  // ==========================================
  // CORE MARKET CYCLE (CALLED ON EACH TICK / M1 BAR)
  // ==========================================

  public async onMarketUpdate(feed: DaRaMarketFeed): Promise<void> {
    if (this.cachedPointSize === 0) {
      try {
        const symbolInfo = await this.broker.getSymbolInfo(feed.symbol);
        if (symbolInfo && symbolInfo.pointSize > 0) {
          this.cachedPointSize = symbolInfo.pointSize;
          console.log(`[DaRa M1 EA] Obtained Point Size for ${feed.symbol}: ${this.cachedPointSize}`);
        }
      } catch (err) {
        console.warn(`[DaRa M1 EA] Failed to fetch symbol info for ${feed.symbol}, will retry next tick.`, err);
        return; // wait until we have a valid point size
      }
    }

    const currentPrice = feed.bid; // Mid/Bid reference
    const currentAsk = feed.ask;
    const currentBid = feed.bid;

    // Continuously update live analysis details for transparency
    if (feed.m1Candles && feed.m1Candles.length >= 10) {
      this.lastAnalysis = this.strategy.getAnalysisDetails(feed.m1Candles, this.userSettings, this.cachedPointSize || 0.01);
    }

    // 1. Manage Profit Trailing & Monitor Protection for all active positions
    const activePositions = this.stateMachine.getActivePositions();
    const setupForTrailing = this.stateMachine.getSetup();
    if (activePositions.length > 0 && setupForTrailing) {
      // 1.a. Update position authoritative data from broker if available
      try {
        const brokerPositions = await this.broker.getOpenPositions(feed.symbol);
        for (const pos of activePositions) {
          const bp = brokerPositions.find(p => String(p.ticket) === String(pos.ticket));
          if (bp) {
            if (bp.unrealizedProfit !== undefined) pos.unrealizedProfit = bp.unrealizedProfit;
            if (bp.commission !== undefined) pos.commission = bp.commission;
            if (bp.swap !== undefined) pos.swap = bp.swap;
          }
        }
      } catch (_) {}

      // 1.b. Calculate TRUE TOTAL NET BASKET PROFIT (Profit + Commission + Swap)
      let basketNetProfit = 0;
      for (const pos of activePositions) {
        let posGross: number;
        if (pos.unrealizedProfit !== undefined) {
          posGross = pos.unrealizedProfit;
        } else {
          const pDiff = pos.type === 'BUY' ? (currentBid - pos.openPrice) : (pos.openPrice - currentAsk);
          posGross = pDiff * pos.lot * 100;
        }
        const posNet = posGross + (pos.commission || 0) + (pos.swap || 0);
        basketNetProfit += posNet;
      }
      basketNetProfit = Number(basketNetProfit.toFixed(2));

      if (!setupForTrailing.trailingState) {
        setupForTrailing.trailingState = { activated: false };
      }

      const PROFIT_LOCK_THRESHOLD = 50; // +50 USC

      // Phase 1: Activate Profit Lock when TRUE Net Profit reaches >= +50 USC
      if (!setupForTrailing.trailingState.profitLockActivated && basketNetProfit >= PROFIT_LOCK_THRESHOLD) {
        setupForTrailing.trailingState.profitLockActivated = true;
        setupForTrailing.trailingState.highestBasketNetProfit = basketNetProfit;
        console.log(`[DaRa M1 EA v1.0] 🔒 BASKET PROFIT LOCK ACTIVATED at +${basketNetProfit.toFixed(2)} USC (Threshold: +${PROFIT_LOCK_THRESHOLD} USC)`);
        if (this.telegram) {
          const title = `🔒 DaRa M1 - PROFIT LOCK ACTIVATED`;
          const msg = [
            `${setupForTrailing.direction} Basket | ${feed.symbol}`,
            `Locked Profit: +${PROFIT_LOCK_THRESHOLD} USC`,
            `Current Net Profit: +${basketNetProfit.toFixed(2)} USC`,
            `Active Positions: ${activePositions.length}`
          ].join('\n');
          this.telegram.notify(title, msg, `PROFIT_LOCK_${setupForTrailing.id}`).catch(() => {});
        }
      }

      // Track highest profit achieved after activation
      if (setupForTrailing.trailingState.profitLockActivated) {
        setupForTrailing.trailingState.highestBasketNetProfit = Math.max(
          setupForTrailing.trailingState.highestBasketNetProfit || basketNetProfit,
          basketNetProfit
        );

        // Phase 2: If profit was running above threshold and returns to <= +50 USC, close the ENTIRE Basket
        if (basketNetProfit <= PROFIT_LOCK_THRESHOLD) {
          console.log(`[DaRa M1 EA v1.0] 🛡️ BASKET PROFIT LOCK HIT! Net profit returned to +${basketNetProfit.toFixed(2)} USC (Peak: +${(setupForTrailing.trailingState.highestBasketNetProfit || PROFIT_LOCK_THRESHOLD).toFixed(2)} USC, Locked at +${PROFIT_LOCK_THRESHOLD} USC). Closing entire Basket!`);
          await this.closeBasket('PROFIT_LOCK_HIT', `Basket Net Profit returned to +${basketNetProfit.toFixed(2)} USC`, currentBid, currentAsk);
          return;
        }
      }

      // 1.c. Evaluate standard setup trailing
      const trailingResult = this.trailing.evaluateSetupTrailing(
        setupForTrailing,
        activePositions,
        currentBid,
        currentAsk,
        this.userSettings
      );
      if (trailingResult.shouldCloseBasket) {
        await this.closeBasket('TRAILING_SL_HIT', trailingResult.reason || 'Trailing SL Hit', currentBid, currentAsk);
        return;
      }
      if (trailingResult.activatedThisTick) {
        if (this.telegram) {
          const msg = `Initial Hidden SL: ${trailingResult.newHiddenSL?.toFixed(3)}`;
          this.telegram.notify(`🛡️ DaRa M1 - TRAILING ACTIVATED`, msg).catch(() => {});
        }
        for (const pos of activePositions) {
          if (pos.tp !== 0) {
            await this.broker.modifyPosition(pos.ticket, pos.sl, 0);
            pos.tp = 0;
          }
        }
      }
    }

    for (const pos of this.stateMachine.getActivePositions()) {
      await this.manageActivePosition(pos, currentBid, currentAsk);
    }

    // If EA is STOPPED, stay idle
    if (!this.isRunning) {
      return;
    }

    const state = this.stateMachine.getState();
    const currentSetup = this.stateMachine.getSetup();

    // 2. State: SCANNING — Scan for Liquidity Sweep -> Displacement -> MSS
    if (state === 'SCANNING' && !this.stateMachine.hasOpenPositions()) {
      const initialSafety = this.evaluateSafety(feed.spreadPoints, feed.openTradesCount);
      if (!initialSafety.isSafeToTrade) {
        return;
      }

      if (!feed.m1Candles || feed.m1Candles.length < 10) {
        return;
      }

      const detectedSetup = this.strategy.scanForSetup(feed.m1Candles, this.userSettings, this.cachedPointSize);
      if (detectedSetup) {
        // Confirmed Signal!
        const sigPrice = detectedSetup.signalPrice ?? detectedSetup.lockedEntryPrice ?? (detectedSetup.direction === 'BUY' ? currentAsk : currentBid);
        detectedSetup.signalPrice = sigPrice;
        
        console.log(`[DaRa M1 EA v1.0] 🎯 CONFIRMED SIGNAL: ${detectedSetup.direction} | Sweep=${detectedSetup.sweepLevel} | MSS=${detectedSetup.mssLevel} | Signal Price=${sigPrice}`);
        console.log(`[DaRa M1 EA v1.0] ⏳ Waiting for price pullback... calculating 5 entry levels based on lockedEntryPrice.`);
        
        this.stateMachine.onSetupDetected(detectedSetup, this.userSettings);
      }
      return;
    }

    // 3. Check for Entry Levels if we have a setup
    if ((state === 'WAIT_FOR_LOCKED_ENTRY' || state === 'TRADE_ACTIVE') && currentSetup) {
      // Step A: Check Pending Setup Cancellation (Virtual TP or SL touched before any entry)
      if (!this.stateMachine.hasOpenPositions()) {
        const wasCanceled = this.stateMachine.checkPendingSetupCancellation(currentPrice);
        if (wasCanceled) {
          console.log(`[DaRa M1 EA v1.0] 🚫 Pending Setup was Canceled (Virtual Target hit before Entry). Zero loss. Scanning for new setup.`);
          if (this.telegram) {
            this.telegram.notify('🚫 DaRa M1 EA - SETUP CANCELLED', 'Price hit Virtual SL/TP before reaching Entry Target.\nSetup discarded with Zero Loss. Resume Scanning.').catch(() => {});
          }
          return;
        }
      }

      // Step B: Check if Price hit the next Pending Level
      const rawUserMax = Number(this.userSettings.maxOpenTrades);
      const maxAllowedPositions = isNaN(rawUserMax) ? 5 : Math.max(1, Math.min(5, Math.floor(rawUserMax)));
      const nextLevel = this.stateMachine.getNextPendingLevel(maxAllowedPositions);
      const latestCandle = feed.m1Candles && feed.m1Candles.length > 0 ? feed.m1Candles[feed.m1Candles.length - 1] : undefined;
      
      if (nextLevel && this.stateMachine.isEntryPriceReached(currentPrice, latestCandle?.low, latestCandle?.high, maxAllowedPositions)) {
        const positionNumber = nextLevel.levelIndex + 1;
        
        // Safety verification immediately before sending broker order
        const safety = this.evaluateSafety(feed.spreadPoints, feed.openTradesCount);
        if (!safety.isSafeToTrade) {
          console.warn(`[DaRa M1 EA v1.0] ⚠️ Entry hit but Safety Guard blocked execution: ${safety.blockedReason}`);
          if (this.telegram) {
            this.telegram.notify('⚠️ DaRa M1 EA - ENTRY BLOCKED BY SAFETY GUARD', `Reason: ${safety.blockedReason}`).catch(() => {});
          }
          return; // Do not execute, but don't cancel setup either (can try again next tick)
        }

        if (state === 'WAIT_FOR_LOCKED_ENTRY') {
          this.stateMachine.onEntryTriggered();
        }

        console.log(`[DaRa M1 EA v1.0] ⚡ Level ${positionNumber} Target reached (${currentPrice} - target: ${nextLevel.targetPrice}). Executing Position #${positionNumber} ${currentSetup.direction}...`);
        if (this.telegram) {
          this.telegram.notify(`⚡ DaRa M1 EA - POS #${positionNumber} TARGET REACHED`, `Price reached Level ${positionNumber} target (${currentPrice}).\nExecuting Position #${positionNumber} ${currentSetup.direction}...`).catch(() => {});
        }

        const execResult = await this.execution.executeOrder(
          currentSetup,
          feed.symbol,
          currentAsk,
          currentBid,
          this.userSettings,
          nextLevel.levelIndex,
          this.isRunning
        );

        if (execResult.success && execResult.position) {
          this.stateMachine.onPositionOpened(execResult.position, nextLevel.levelIndex);
          console.log(`[DaRa M1 EA v1.0] 🚀 Position #${positionNumber} Filled! Ticket #${execResult.position.ticket}.`);
          
          if (positionNumber >= maxAllowedPositions) {
             console.log(`[DaRa M1 EA v1.0] ${positionNumber}/${maxAllowedPositions} POSITIONS OPENED. Max Positions Per Setup (${maxAllowedPositions}) reached. STOPPING further entries.`);
          }
        } else {
          console.error(`[DaRa M1 EA v1.0] Execution rejected: ${execResult.error}`);
          if (positionNumber === 1) {
             this.stateMachine.cancelSetup('EXPIRED', `Execution error: ${execResult.error}`);
          }
          if (this.telegram) {
            this.telegram.notify('🔴 DaRa M1 EA - ORDER REJECTED', `Broker execution failed for Level ${positionNumber}:\n${execResult.error}`).catch(() => {});
          }
        }
      }
    }
  }

  /**
   * Closes all active positions in the current basket simultaneously.
   */
  public async closeBasket(
    exitReason: DaRaExitReason,
    reasonText: string,
    currentBid: number,
    currentAsk: number
  ): Promise<void> {
    const activePositions = [...this.stateMachine.getActivePositions()];
    if (activePositions.length === 0) {
      return;
    }

    console.log(`[DaRa M1 EA v1.0] 🛑 Closing entire Basket (${activePositions.length} positions) - Reason: ${exitReason} (${reasonText})`);

    // 1. Close all active positions via broker
    for (const pos of activePositions) {
      if (this.broker.closePosition) {
        try {
          await this.broker.closePosition(pos.ticket);
        } catch (err) {
          console.error(`[DaRa M1 EA] Failed to close position #${pos.ticket} via broker:`, err);
        }
      }
    }

    // 2. Finalize and record each closed trade
    for (const pos of activePositions) {
      const closePrice = pos.type === 'BUY' ? currentBid : currentAsk;
      let finalPnl: number;
      if (pos.unrealizedProfit !== undefined) {
        finalPnl = Number((pos.unrealizedProfit + (pos.commission || 0) + (pos.swap || 0)).toFixed(2));
      } else {
        const pDiff = pos.type === 'BUY' ? (closePrice - pos.openPrice) : (pos.openPrice - closePrice);
        finalPnl = Number(((pDiff * pos.lot * 100) + (pos.commission || 0) + (pos.swap || 0)).toFixed(2));
      }

      const closedTrade: DaRaClosedTrade = {
        ticket: pos.ticket,
        symbol: pos.symbol,
        type: pos.type,
        lot: pos.lot,
        openPrice: pos.openPrice,
        closePrice,
        sl: pos.sl,
        tp: pos.tp,
        originalTp: pos.originalTp,
        trailingActivated: pos.trailingActivated,
        pnl: finalPnl,
        exitReason,
        closedAt: Date.now()
      };

      this.stateMachine.clearPosition(closedTrade.ticket);
      await this.finalizeTradeClose(closedTrade);
    }

    // 3. Clear setup and return state machine to SCANNING
    if (this.isRunning) {
      this.stateMachine.resetToScanning('Basket closed. Returned to SCANNING.');
    } else {
      this.stateMachine.reset();
    }
    console.log(`[DaRa M1 EA v1.0] 🔄 Entire Basket closed. Setup cleared. Returned to SCANNING.`);
  }

  /**
   * Manages Profit Trailing on active position and detects Real Broker Position Closure.
   * Monotonicity guaranteed: SL only moves upward for BUY, downward for SELL.
   */
  private async manageActivePosition(
    position: DaRaPosition,
    currentBid: number,
    currentAsk: number
  ): Promise<void> {
    const ticketKey = String(position.ticket);
    if (this.closedTicketsSet.has(ticketKey)) {
      return;
    }

    // 1. Update position's live price and tracking metrics
    const currentPrice = position.type === 'BUY' ? currentBid : currentAsk;
    position.currentPrice = currentPrice;
    if (position.type === 'BUY') {
      position.highestPriceSinceOpen = Math.max(position.highestPriceSinceOpen || position.openPrice, currentPrice);
    } else {
      position.lowestPriceSinceOpen = Math.min(position.lowestPriceSinceOpen || position.openPrice, currentPrice);
    }

    const priceDiff = position.type === 'BUY' ? (currentBid - position.openPrice) : (position.openPrice - currentAsk);
    position.unrealizedProfit = Number((priceDiff * position.lot * 100).toFixed(2));

    // 2. Verify if position is still open on Broker
    let stillOpen = true;
    let closedDealInfo: { found: boolean; profit?: number; price?: number; reason?: string; comment?: string } | null = null;

    try {
      const openPositions = await this.broker.getOpenPositions(position.symbol);
      const brokerPos = openPositions.find(p => String(p.ticket) === ticketKey);
      stillOpen = !!brokerPos;

      if (brokerPos) {
        if (brokerPos.unrealizedProfit !== undefined) {
          position.unrealizedProfit = brokerPos.unrealizedProfit;
        }
        if (brokerPos.commission !== undefined) {
          position.commission = brokerPos.commission;
        }
        if (brokerPos.swap !== undefined) {
          position.swap = brokerPos.swap;
        }
      }

      if (!stillOpen && this.broker.getClosedDeal) {
        try {
          const dealRes = await this.broker.getClosedDeal(position.ticket);
          if (dealRes && dealRes.found) {
            closedDealInfo = dealRes;
          }
        } catch (_) {}
      }
    } catch (e) {
      // Broker poll error, keep local tracking
    }

    // Grace period check: if position opened within last 3000ms, don't declare closed yet unless deal confirmed
    const positionAge = Date.now() - position.openTime;
    if (!stillOpen && positionAge < 3000 && !closedDealInfo?.found) {
      return;
    }

    if (!stillOpen) {
      await this.processClosedPosition(position, currentBid, currentAsk, closedDealInfo);
      return;
    }

    // 3. Monotonic Trailing SL
    const trailingCheck = this.trailing.calculateTrailingSL(
      position,
      currentBid,
      currentAsk,
      this.userSettings,
      this.cachedPointSize
    );

    if (trailingCheck.shouldModify && trailingCheck.newSl) {
      console.log(`[DaRa M1 EA v1.0] 🛡️ Advancing Trailing SL for #${position.ticket}: New SL = ${trailingCheck.newSl} (${trailingCheck.reason})`);
      if (this.telegram) {
        // Calculate floating P/L in USC
        const currentPrice = position.type === 'BUY' ? currentBid : currentAsk;
        const pDiff = position.type === 'BUY' ? (currentPrice - position.openPrice) : (position.openPrice - currentPrice);
        const floatingUsc = Number((pDiff * position.lot * 100).toFixed(2));
        const pnlStr = floatingUsc >= 0 ? `+${floatingUsc.toFixed(2)}` : `-${Math.abs(floatingUsc).toFixed(2)}`;

        const title = `🔵 Trailing SL`;
        const msg = [
          `${position.type} | ${position.symbol}`,
          `SL ថ្មី: ${trailingCheck.newSl.toFixed(3)}`,
          `P/L: ${pnlStr} USC`
        ].join('\n');

        this.telegram.notify(title, msg, `TRAILING_SL_${position.ticket}_${trailingCheck.newSl}`).catch(() => {});
      }
      const targetTp = trailingCheck.newTp !== undefined ? trailingCheck.newTp : position.tp;
      const modResult = await this.broker.modifyPosition(position.ticket, trailingCheck.newSl, targetTp);
      if (modResult.success) {
        position.sl = trailingCheck.newSl;
        position.lastTrailingSl = trailingCheck.newSl;
        if (trailingCheck.newTp !== undefined) {
          position.tp = trailingCheck.newTp;
        }
      }
    }
  }

  /**
   * Internal processor for broker-closed positions.
   */
  private async processClosedPosition(
    position: DaRaPosition,
    currentBid: number,
    currentAsk: number,
    closedDealInfo: { found: boolean; profit?: number; price?: number; reason?: string; comment?: string } | null
  ): Promise<void> {
    const ticketKey = String(position.ticket);
    if (this.closedTicketsSet.has(ticketKey)) {
      return;
    }

    // Determine Exit Reason with 100% mathematical and broker integrity:
    let exitReason: DaRaExitReason = 'SL_HIT';
    const brokerReason = closedDealInfo?.reason || '';
    const brokerComment = (closedDealInfo?.comment || '').toLowerCase();

    if (brokerReason === 'DEAL_REASON_TP' || brokerComment.includes('[tp')) {
      exitReason = 'TP_HIT';
    } else if (brokerReason === 'DEAL_REASON_SL' || brokerComment.includes('[sl')) {
      exitReason = position.trailingActivated ? 'TRAILING_SL_HIT' : 'SL_HIT';
    } else if (brokerReason === 'DEAL_REASON_CLIENT' || brokerReason === 'DEAL_REASON_EXPERT' || brokerComment.includes('close by') || brokerComment.includes('close all')) {
      exitReason = brokerComment.includes('close all') ? 'CLOSE_ALL' : 'MANUAL_CLOSE';
    } else if (position.trailingActivated) {
      exitReason = 'TRAILING_SL_HIT';
    } else if (position.type === 'BUY') {
      const reachedTp = position.tp > 0 && (currentBid >= position.tp || (closedDealInfo?.price !== undefined && closedDealInfo.price >= position.tp));
      exitReason = reachedTp ? 'TP_HIT' : 'SL_HIT';
    } else { // SELL
      const reachedTp = position.tp > 0 && (currentAsk <= position.tp || (closedDealInfo?.price !== undefined && closedDealInfo.price <= position.tp));
      exitReason = reachedTp ? 'TP_HIT' : 'SL_HIT';
    }

    // Determine exit price strictly from broker deal if available
    let closePrice = position.type === 'BUY' ? currentBid : currentAsk;
    if (closedDealInfo?.price && closedDealInfo.price > 0) {
      closePrice = closedDealInfo.price;
    } else if (exitReason === 'TP_HIT') {
      closePrice = position.tp;
    } else if (exitReason === 'SL_HIT' || exitReason === 'TRAILING_SL_HIT') {
      closePrice = position.sl;
    }

    // Determine realized P/L
    let finalPnl = 0;
    if (closedDealInfo?.profit !== undefined) {
      finalPnl = Number(closedDealInfo.profit.toFixed(2));
    } else {
      const pDiff = position.type === 'BUY' ? (closePrice - position.openPrice) : (position.openPrice - closePrice);
      finalPnl = Number(((pDiff * position.lot * 100) + (position.commission || 0) + (position.swap || 0)).toFixed(2));
    }

    const closedTrade: DaRaClosedTrade = {
      ticket: position.ticket,
      symbol: position.symbol,
      type: position.type,
      lot: position.lot,
      openPrice: position.openPrice,
      closePrice,
      sl: position.sl,
      tp: position.tp,
      originalTp: position.originalTp,
      trailingActivated: position.trailingActivated,
      pnl: finalPnl,
      exitReason,
      closedAt: Date.now()
    };

    this.stateMachine.clearPosition(closedTrade.ticket);

    await this.finalizeTradeClose(closedTrade);
  }

  /**
   * External entry point for position closures detected by broker polling / MetaApi stream.
   */
  public async handlePositionClosed(
    ticket: string | number,
    overrideExitReason?: DaRaExitReason,
    overrideProfit?: number,
    overridePrice?: number
  ): Promise<void> {
    const ticketKey = String(ticket);
    if (this.closedTicketsSet.has(ticketKey)) {
      return;
    }

    let targetPos = this.stateMachine.getActivePositions().find(p => String(p.ticket) === ticketKey);
    
    if (!targetPos) {
      if (overrideProfit !== undefined) {
        this.recordRealTradeResult(overrideProfit);
      }
      return;
    }

    let exitReason = overrideExitReason;
    if (!exitReason) {
      if (targetPos.trailingActivated) {
        exitReason = 'TRAILING_SL_HIT';
      } else if (overridePrice !== undefined) {
        if (targetPos.type === 'BUY' && targetPos.tp > 0 && overridePrice >= targetPos.tp) {
          exitReason = 'TP_HIT';
        } else if (targetPos.type === 'SELL' && targetPos.tp > 0 && overridePrice <= targetPos.tp) {
          exitReason = 'TP_HIT';
        } else if (targetPos.type === 'BUY' && targetPos.sl > 0 && overridePrice <= targetPos.sl) {
          exitReason = 'SL_HIT';
        } else if (targetPos.type === 'SELL' && targetPos.sl > 0 && overridePrice >= targetPos.sl) {
          exitReason = 'SL_HIT';
        } else if (overrideProfit !== undefined && overrideProfit >= 0) {
          exitReason = 'MANUAL_CLOSE';
        } else {
          exitReason = 'SL_HIT';
        }
      } else if (overrideProfit !== undefined) {
        exitReason = overrideProfit >= 0 ? 'MANUAL_CLOSE' : 'SL_HIT';
      } else {
        exitReason = 'SL_HIT';
      }
    }

    const closePrice = overridePrice || (exitReason === 'TP_HIT' ? targetPos.tp : targetPos.sl);
    let finalPnl = overrideProfit;
    if (finalPnl === undefined) {
      const pDiff = targetPos.type === 'BUY' ? (closePrice - targetPos.openPrice) : (targetPos.openPrice - closePrice);
      finalPnl = Number(((pDiff * targetPos.lot * 100) + (targetPos.commission || 0) + (targetPos.swap || 0)).toFixed(2));
    }

    const closedTrade: DaRaClosedTrade = {
      ticket: targetPos.ticket,
      symbol: targetPos.symbol,
      type: targetPos.type,
      lot: targetPos.lot,
      openPrice: targetPos.openPrice,
      closePrice,
      sl: targetPos.sl,
      tp: targetPos.tp,
      originalTp: targetPos.originalTp,
      trailingActivated: targetPos.trailingActivated,
      pnl: finalPnl,
      exitReason,
      closedAt: Date.now()
    };

    this.stateMachine.clearPosition(closedTrade.ticket);
    await this.finalizeTradeClose(closedTrade);
  }

  /**
   * Finalizes trade closure: updates telemetry, records P/L, sends Telegram alert, and resets state to SCANNING.
   */
  private async finalizeTradeClose(closedTrade: DaRaClosedTrade): Promise<void> {
    const ticketKey = String(closedTrade.ticket);
    if (this.closedTicketsSet.has(ticketKey)) {
      return;
    }
    this.closedTicketsSet.add(ticketKey);

    // 1. Record Real Trade Result (updates daily loss, consecutive loss streak, cooldown)
    this.recordRealTradeResult(closedTrade.pnl);

    // 2. Send Telegram Alert (Strictly 1 event per trade, no duplicates)
    await this.sendTradeClosedTelegramAlert(closedTrade);

    // 3. State Machine Transition: Only clear setup & return to SCANNING if no positions remain active
    if (!this.stateMachine.hasOpenPositions()) {
      this.stateMachine.onPositionClosed(closedTrade);
      console.log(`[DaRa M1 EA v1.0] 🏁 Trade #${closedTrade.ticket} finalized: ${closedTrade.exitReason} | P/L: ${closedTrade.pnl >= 0 ? '+' : ''}${closedTrade.pnl.toFixed(2)} | All positions closed. Resuming SCANNING.`);
    } else {
      console.log(`[DaRa M1 EA v1.0] 🏁 Trade #${closedTrade.ticket} finalized: ${closedTrade.exitReason} | P/L: ${closedTrade.pnl >= 0 ? '+' : ''}${closedTrade.pnl.toFixed(2)} | 1 position still active.`);
    }
  }

  /**
   * Sends dedicated Telegram alerts for TP HIT, SL HIT, and TRAILING SL HIT (Khmer language, short & concise).
   */
  private async sendTradeClosedTelegramAlert(trade: DaRaClosedTrade): Promise<void> {
    if (!this.telegram) return;

    const absPnl = Math.abs(trade.pnl).toFixed(2);

    if (trade.exitReason === 'TP_HIT') {
      const title = `✅ បិទ ${trade.type} — ប៉ះ TP`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        `TP: ${trade.tp.toFixed(3)}`,
        `ចំណេញ: +${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_TP_${trade.ticket}`).catch(() => {});
    } else if (trade.exitReason === 'SL_HIT') {
      const title = `❌ បិទ ${trade.type} — ប៉ះ SL`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        `SL: ${trade.sl.toFixed(3)}`,
        `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_SL_${trade.ticket}`).catch(() => {});
    } else if (trade.exitReason === 'TRAILING_SL_HIT') {
      const isProfit = trade.pnl >= 0;
      const title = `🔵 បិទ ${trade.type} — Trailing SL`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        `SL: ${trade.sl.toFixed(3)}`,
        isProfit ? `ចំណេញ: +${absPnl} USC` : `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_TRAILING_SL_${trade.ticket}`).catch(() => {});
    } else if (trade.exitReason === 'PROFIT_LOCK_HIT') {
      const isProfit = trade.pnl >= 0;
      const title = `🔒 បិទ ${trade.type} — Profit Lock (+50 USC)`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        isProfit ? `ចំណេញ: +${absPnl} USC` : `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_PROFIT_LOCK_${trade.ticket}`).catch(() => {});
    } else if (trade.exitReason === 'CLOSE_ALL') {
      const isProfit = trade.pnl >= 0;
      const title = `🛑 បិទ ${trade.type} — CLOSE ALL`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        isProfit ? `ចំណេញ: +${absPnl} USC` : `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_CLOSE_ALL_${trade.ticket}`).catch(() => {});
    } else if (trade.exitReason === 'MANUAL_CLOSE') {
      const isProfit = trade.pnl >= 0;
      const title = `🏁 បិទ ${trade.type} — Manual`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        isProfit ? `ចំណេញ: +${absPnl} USC` : `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_MANUAL_${trade.ticket}`).catch(() => {});
    } else {
      const isProfit = trade.pnl >= 0;
      const title = `🏁 បិទ ${trade.type}`;
      const msg = [
        `ចូល: ${trade.openPrice.toFixed(3)}`,
        `ចេញ: ${trade.closePrice.toFixed(3)}`,
        isProfit ? `ចំណេញ: +${absPnl} USC` : `ខាត: -${absPnl} USC`
      ].join('\n');
      await this.telegram.notify(title, msg, `TRADE_CLOSED_${trade.ticket}`).catch(() => {});
    }
  }
}
